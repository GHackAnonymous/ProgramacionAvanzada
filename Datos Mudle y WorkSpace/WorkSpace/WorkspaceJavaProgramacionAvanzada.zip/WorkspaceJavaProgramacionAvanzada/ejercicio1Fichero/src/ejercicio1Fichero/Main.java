package ejercicio1Fichero;

import java.io.BufferedReader;
import java.io.EOFException;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;


public class Main {
	static List<Alumno> lista = new ArrayList<>();

	public static void main(String[] args) {
		

		mostrarDatosFichero("fichero/Alumnos.txt");
		
		for (Alumno a: lista){
			System.out.println(a);
		}

	}
	
	public static void mostrarDatosFichero(String nombreFichero){
		BufferedReader in  = null;
		try {
			in = new BufferedReader(new FileReader(nombreFichero));
			String s;
			while ((s = in.readLine())!=null){
				String[] linea = s.split("[$]");
				lista.add(new Alumno(linea[0], linea[1], linea[2], linea[3]));
			}
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}catch (EOFException e){
			
		}catch (IOException e) {
			e.printStackTrace();
		}finally{
			if (in!= null){
				try { in.close(); } catch (IOException e) {}
			}
		}
	}
}
