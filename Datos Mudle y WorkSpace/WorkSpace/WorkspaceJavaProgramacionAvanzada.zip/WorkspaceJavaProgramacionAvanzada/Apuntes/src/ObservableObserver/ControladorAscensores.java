package ascensor;

import java.util.Observer;

public class ControladorAscensores {

	Ascensor lista[];
	int numAscensores;
	public ControladorAscensores(int numAscensores){
		lista = new Ascensor [numAscensores];
		
		this.numAscensores = numAscensores;
		for (int i = 0; i<this.numAscensores;i++){
			lista[i]= new Ascensor(i);
		}
	}
	
	/* como el controlador no es observer y tampoco 
	 * observa a nada tiene un metodo que pasa el 
	 * observador que el es principal a los observables
	 * que son los ascensores para que estos puedan
	 * avisar al principal de cuando han cambiado 
	 * */
	public void addOserver(Observer principal) {
		for (Ascensor ascensor: lista){
			ascensor.addObserver(principal);
		}
	}
}
