package ascensor;
import java.util.Observable;
import java.util.Observer;
import java.util.Scanner;


public class Principal implements Observer {

	final int NUMASCENSORES = 3;
	ControladorAscensores controlador;
	Scanner teclado;
	
	public Principal(){
		controlador = new ControladorAscensores(NUMASCENSORES);
		teclado = new Scanner (System.in);
		controlador.addOserver(this);
	}
	
	public void gestionarAscensores(){
		/*Aqu� ir�a el men�*/
	}

	public static void main(String[] args) {
		Principal ejercicio = new Principal();
		ejercicio.gestionarAscensores();
	}

	@Override
	public void update(Observable asc, Object objetoModificado) {
		
		if (objetoModificado instanceof Ascensor){
			Ascensor ascensor = (Ascensor) objetoModificado;
			System.out.println ("Ascensor "+ascensor.getId()+" en piso: "+ ascensor.getPisoActual());
			
		}else{
			Puerta puerta = (Puerta) objetoModificado;
			System.out.println((puerta.getEstado())?"La puerta se abre": "La puerta se cierra");
		}
		
	}

}
