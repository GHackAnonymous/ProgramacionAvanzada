import java.util.ArrayList;
import java.util.List;

// esto es lo que tendr�as en el class del objeto que no hereda

	@Override
	public String toString() {
		return "Nombre del arma: " +this.nombreArtefacto + "\n" + "Da�o: " +this.dano;
	}

//esto es lo que tendr�as en el gestor donde est� la lista de objetos
	
	@Override
	public abstract String toString();
	
	
	public ArrayList<Criatura> copiarListaPersonajes() {
		ArrayList<Criatura> copia = new ArrayList<Criatura>(listaPersonajes);
	    return copia;
	}
	
//esto es lo que tendr�as en el main
	
	private void verPersonajes() {
		List <Criatura> copia = gestor.copiarListaPersonajes();
		int posicion = 0;
		for(Criatura pl : copia){
			System.out.println("Posicion: " +posicion);
			System.out.println(pl.toString());
			posicion++;
		}
		
	}
