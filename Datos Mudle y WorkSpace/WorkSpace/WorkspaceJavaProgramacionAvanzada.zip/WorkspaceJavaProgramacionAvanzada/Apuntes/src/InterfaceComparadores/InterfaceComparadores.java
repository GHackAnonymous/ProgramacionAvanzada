package InterfaceComparadores;

public interface InterfaceComparadores<T> {
	int comparar (T a, T b);
}