package InterfaceComparadores;

public class FabricaComparadores {
	
	public static InterfaceComparadores getComparadorMayor(){
		return new ComparadorMayor();
	}
	
	public static InterfaceComparadores getComparadorMenor(){
		return new ComparadorMenor();
	}
	
	public static InterfaceComparadores getComparadorStringMayor(){
		return new ComparadorStringMayor();
	}
	
	public static InterfaceComparadores getComparadorStringMenor(){
		return new ComparadorStringMayor();
	}
	
	public static class ComparadorMayor implements InterfaceComparadores<Object> {

		@Override
		public int comparar(Object a, Object b) {
			return a.toString().compareTo(b.toString()); //usar solo con doubles o integers
		}

	}
	
	public static class ComparadorMenor implements InterfaceComparadores<Object> {

		@Override
		public int comparar(Object a, Object b) {
			return b.toString().compareTo(a.toString()); //usar solo con doubles o integers
		}

	}
	
	public static class ComparadorStringMayor implements InterfaceComparadores<String> {

		@Override
		public int comparar(String a, String b) {
			return a.compareTo(b);  // usar con strings
		}

	}
	
	public static class ComparadorStringMenor implements InterfaceComparadores<String> {

		@Override
		public int comparar(String a, String b) {
			return b.compareTo(a);  //usar con strings
		}

	}
	
	
}
