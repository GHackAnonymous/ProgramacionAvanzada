package ObserverXE;

import java.util.Observable;

public class LoObservable extends Observable{
	boolean a = true;
	private void metodoQueSeObserble(int piso){
		this.setChanged();
		this.notifyObservers(this);
	}
	public void ponerAFalse(){
		a = false;
	}
}
