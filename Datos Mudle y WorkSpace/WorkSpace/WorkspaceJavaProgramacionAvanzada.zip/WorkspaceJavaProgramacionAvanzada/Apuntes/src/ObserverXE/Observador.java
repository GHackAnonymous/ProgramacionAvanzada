package ObserverXE;

import java.util.Observable;
import java.util.Observer;

public class Observador implements Observer{

	LoObservable loObservable = new LoObservable();
	
	public Observador(){
		loObservable.addObserver(this);
		loObservable.ponerAFalse();
	}
	
	public static void main(String[] args) {
		

	}

	@Override
	public void update(Observable arg0, Object arg1) {
		// aqui hacer lo que queramos cuando el objeto de modifica
		System.out.println("se modifico");
	}

}
