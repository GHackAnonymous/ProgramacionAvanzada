package GenericMain;

import java.util.InputMismatchException;
import java.util.Random;
import java.util.Scanner;

import GenericException;

public class Main {
	
	private Random randomGenerator;
	private Scanner teclado;
  
  public Main(){
    randomGenerator = new Random();
    teclado = new Scanner(System.in);
  }
  
  private int menu(){
	    System.out.println("1.- ");
	    System.out.println("2.- ");
	    System.out.println("3.- ");
	    System.out.println("0.- Salir");
	    System.out.print("opcion � ");
	    int opcion = teclado.nextInt();
	    teclado.nextLine();
	    return opcion;
  }
  private void opcionMenu(int opcion){
	  try {
		  switch(opcion){
		    case 1:
		      
		      break;
		    case 2:
		     
		      break;
		    case 3:
		      
		      break;
		    case 0:
		      System.out.println("Saliendo....");
		      break;
		    default:
		      throw new GenericException("Opci�n no v�lida");
		  }
	  }catch(GenericException e){
	      System.out.println(e.getMessage());
	  }catch(InputMismatchException e){
	      System.out.println("Opci�n no v�lida");
	  }catch(Exception e){
	      System.out.println("No s� que ha pasado");
	  }
  }

  
  public void programa(){
    int opcion = menu();
    opcionMenu(opcion);
  }
  public static void main(String[] args){
    Main principal = new Main();
    principal.programa();

  }

}