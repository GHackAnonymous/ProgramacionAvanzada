package InterfaceMath;

import java.util.List;

public interface InterfaceMath<T> {
	List<T> Recorrer (List<T> lista);
}