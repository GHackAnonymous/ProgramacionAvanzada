package InterfaceMath;


import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import InterfaceComparadores.FabricaComparadores.ComparadorStringMayor;

public class FabricaMath {
	
	
	public static InterfaceMath getPares(){
		return new Pares();
	}
	
	public static InterfaceMath getImPares(){
		return new ImPares();
	}
	
	public static InterfaceMath getCapicuas(){
		return new Capicuas();
	}
	
	public static InterfaceMath getPrimos(){
		return new Primos();
	}
	
	public static InterfaceMath getSumaX(){
		return new SumaX();
	}
	
	public static class Pares implements InterfaceMath<Double> {

		@Override
		public List<Double> Recorrer(List<Double> lista) {
			Iterator<Double> it = lista.iterator();
			List<Double> resultados = new ArrayList<Double>();// aqu� creas el iterator para la lista de Objects
			while (it.hasNext()){
				Double numero = it.next();
				if(numero%2 == 0){
					resultados.add(numero);
				}
			}
			return resultados;
		}

	}
	
	public static class ImPares implements InterfaceMath<Double> {

		@Override
		public List<Double> Recorrer(List<Double> lista) {
			Iterator<Double> it = lista.iterator();
			List<Double> resultados = new ArrayList<Double>();// aqu� creas el iterator para la lista de Objects
			while (it.hasNext()){
				Double numero = it.next();
				if(numero%2 != 0){
					resultados.add(numero);
				}
			}
			return resultados;
		}

	}
	
	public static class Capicuas implements InterfaceMath<Double> {

		@Override
		public List<Double> Recorrer(List<Double> lista) {
			Iterator<Double> it = lista.iterator();
			List<Double> resultados = new ArrayList<Double>();// aqu� creas el iterator para la lista de Objects
			while (it.hasNext()){
				Double numero = it.next();
				
				double numeroAnalizar = numero;
				double resto = 0;
				double numeroInvertido =0;
				while(numero!=0){
					resto=numero%10;
					numeroInvertido=numeroInvertido*10+resto;
					numero=numero/10;
				}
				if(numeroAnalizar == numeroInvertido){
					resultados.add(numeroAnalizar);
				}
			}
			return resultados;
		}

	}
	
	public static class Primos implements InterfaceMath<Double> {

		@Override
		public List<Double> Recorrer(List<Double> lista) {
			Iterator<Double> it = lista.iterator();
			List<Double> resultados = new ArrayList<Double>();
			while (it.hasNext()){
				Double numero = it.next();
				for(double contador = 2; contador < (numero-1) ; contador++){
					if(numero%contador==0){
						resultados.add(numero);
					}
				}
			}
			return resultados;
		}

	}
	
	public static class SumaX implements InterfaceMath<Double> {

		@Override
		public List<Double> Recorrer(List<Double> lista) {
			Iterator<Double> it = lista.iterator();
			List<Double> resultados = new ArrayList<Double>();// aqu� creas el iterator para la lista de Objects
			while (it.hasNext()){
				Double resultado = 0.0;
				Double otroI = it.next();
				Double numeroAnalizar = otroI;
				while (otroI > 0){
					resultado = 0.0;
		            resultado += otroI % 10;
		            otroI = otroI / 10;
		        }
				if(resultado == 13/*cambiar el valor de sumaDIgitos a manija*/){
					resultados.add(numeroAnalizar);
				}	
			}
			return resultados;
		}

	}
	
}