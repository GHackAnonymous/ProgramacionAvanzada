package Iterator;

import java.util.Iterator;

public class IteratorExample {
	public void recorrer3(){
		int numero = 0;
		Iterator<Object> it = lista.iterator();  // aqu� creas el iterator para la lista de Objects
		while (it.hasNext()){
			Object objeto = it.next();
			System.out.println(objeto);  //pegar aqu� algoritmo que quieras
			/*
			 * it.remove(numero)
			 * it.get(numero)
			 * lista.add(it.get());
			 */
			numero++;
		}
	}
}

//Los iterator se usan si tienes que recorrer una lista y modificar al mismo tiempo.