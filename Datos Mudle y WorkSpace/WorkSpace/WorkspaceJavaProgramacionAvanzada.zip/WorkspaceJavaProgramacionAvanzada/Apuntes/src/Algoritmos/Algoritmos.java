package Algoritmos;

public class Algoritmos {
	
	
	public int capicua(int numero) {
		int numeroAnalizar = numero;
		int resto = 0;
		int numeroInvertido =0;
		while(numero!=0){
			resto=numero%10;
			numeroInvertido=numeroInvertido*10+resto;
			numero=numero/10;
		}
		if(numeroAnalizar == numeroInvertido){
			return numeroAnalizar;
		}
		return -1;
	}

	/*
	 * Capicua txema
	 * 
	 * if(numero.charAt(i)!=numero.charAt(numero.lenght()-1)){
	 * 		return false;
	 * }
	 */
	

	public int primo(int numero) {
		for(int contador = 2; contador < (numero-1) ; contador++){
			if(numero%contador==0){
				return numero;
			}
		}
		return -1;
	}


	public int sumaX(int numero, int sumaDigitos) {
		int resultado = 0;
		int otroI = numero;
		int numeroAnalizar = otroI;
		while (otroI > 0){
			resultado = 0;
            resultado += otroI % 10;
            otroI = otroI / 10;
        }
		if(resultado == sumaDigitos){
			return numeroAnalizar;
		}	
		return -1;
	}
	
	public int paresImpares(int numero) {
		if(numero%2 == 0){
			return numero;
		}
		return -1;
	}

	
}
