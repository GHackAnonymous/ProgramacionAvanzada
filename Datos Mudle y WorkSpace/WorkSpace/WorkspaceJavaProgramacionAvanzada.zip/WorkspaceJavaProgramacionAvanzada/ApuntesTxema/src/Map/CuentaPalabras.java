package mapas;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Scanner;
import java.util.Set;

public class CuentaPalabras {
	Map<String,Integer> indice;
	Scanner teclado;
	String texto;
	
	public CuentaPalabras(){
		//indice = new LinkedHashMap<>();
		teclado = new Scanner (System.in);
	}
	public void leerTexto(){
		System.out.print("Texto: ");
		texto = teclado.nextLine();
	}
	public void contarPalabras(){
		Scanner scanner = new Scanner (texto);
		while (scanner.hasNext()){
			String palabra = scanner.next();
			Integer valor = indice.get(palabra);
			if (valor != null){
				valor++;
			}else {
				valor =  1;
			}
			indice.put(palabra, valor);
		}
		scanner.close();
	}
	public void verIndice(){
		
		Set<Entry<String,Integer>> pares = indice.entrySet();
		for (Entry<String,Integer> par : pares){
			System.out.println(par.getKey()+"->"+par.getValue());
		}
	}
	
	public void verIndice2(){
		Set<String> claves = indice.keySet();
		for (String clave : claves){
			System.out.println(clave + "->" + indice.get(clave));
		}
	}
	public static void main (String []args){
		CuentaPalabras ejercicio = new CuentaPalabras();
		ejercicio.leerTexto();
		ejercicio.contarPalabras();
		ejercicio.verIndice();
	
	
	
	
	
	
	
		
		
		
		
		
		
		
		
		
		
	}
}
