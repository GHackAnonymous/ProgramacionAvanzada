package mapas;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Scanner;
import java.util.Set;

public class IndicePalabras {
	Map<String,List<Integer>> indice;
	Scanner teclado;
	String texto;
	
	public IndicePalabras(){
		indice = new LinkedHashMap<>();
		teclado = new Scanner (System.in);
	}
	public void leerTexto(){
		System.out.print("Texto: ");
		texto = teclado.nextLine();
	}
	public void contarPalabras(){
		int contador = 0;
		Scanner scanner = new Scanner (texto);
		while (scanner.hasNext()){
			
			String palabra = scanner.next();
			contador++;
			List<Integer> valores = indice.get(palabra);
			if (valores == null){
				valores = new ArrayList<>();
			}
			valores.add(contador);
			indice.put(palabra, valores);
		}
		scanner.close();
	}
	public void verIndice(){
		
		Set<Entry<String,List<Integer>>> pares = indice.entrySet();
		for (Entry<String,List<Integer>> par : pares){
			System.out.print(par.getKey()+"->");
			for (Integer posicion: par.getValue()){
				System.out.print(" "+posicion);
			}
			System.out.println();
		}
	}
	
	public void verIndice2(){
		Set<String> claves = indice.keySet();
		for (String clave : claves){
			System.out.println(clave + "->" + indice.get(clave));
		}
	}
	public static void main (String []args){
		IndicePalabras ejercicio = new IndicePalabras();
		ejercicio.leerTexto();
		ejercicio.contarPalabras();
		ejercicio.verIndice();
	}
}
