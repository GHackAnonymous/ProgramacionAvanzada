package collecciongenerica;



public class Pila<T> {
	
	Nodo<T> head;
	
	public Pila(){
		head = null;
	}
	public void put (T valor){
		Nodo<T> nodo = new Nodo<>();
		nodo.setValor(valor);
		nodo.setSiguiente(head);
		head = nodo;
	}
	public T get (){
		T valor = head.getValor();
		head = head.getSiguiente();
		return valor;
	}
	public boolean vacia(){
		return head==null;
	}
}
