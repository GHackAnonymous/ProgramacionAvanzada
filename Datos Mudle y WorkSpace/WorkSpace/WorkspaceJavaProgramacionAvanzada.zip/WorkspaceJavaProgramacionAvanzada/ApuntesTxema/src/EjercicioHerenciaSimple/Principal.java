package edu.mondragon.progavanzada.calcularnominas;

import java.util.InputMismatchException;
import java.util.List;
import java.util.Locale;
import java.util.Scanner;

public class Principal {
	Empresa empresa;
	Scanner teclado;
	
	public Principal(String nombre){
		teclado = new Scanner (System.in);
		teclado.useLocale(Locale.US);
		empresa = new Empresa(nombre);
	}
	public int menu() throws InputMismatchException {
		int opcion;
	
		System.out.println("1.- Dar de alta a empleado");
		System.out.println("2.- Mostrar empleados");
		System.out.println("0.- Salir");
		System.out.print("Seleccion opcion: ");
		opcion = teclado.nextInt(); teclado.nextLine();
		
		return opcion;
	}
	
	public void gestionarEmpresa(){
		int opcion = -1;
		do{
			try{
				opcion = menu();
				switch (opcion){
				case 1: darAltaEmpleado();break;
				case 2: mostrarEmpleados();break;
				case 0: break;
				default: System.out.println("Opcion no v�lida");
				}
			}catch (InputMismatchException e){
				System.out.println("Tienes que elegir un n�mero entre 0 y 2");
			}
			
		}while (opcion!=0);
	}
	private void mostrarEmpleados() {
		List<Empleado> empleados = empresa.getEmpleados();
		for (Empleado empleado:empleados){
			System.out.println(empleado);
		}
		
	}
	private void darAltaEmpleado() {
		Empleado empleado= null;
		String tipo;
		
		String nombre;
		double salario;
		int productividad;
		boolean valido = false;
		double ventas;
		do{
			try{
				System.out.print("Nombre: ");
				nombre = teclado.nextLine();
				System.out.print("Salario: ");
				salario = teclado.nextDouble();teclado.nextLine();
				
				System.out.print("TipoEmpleado: (normal, directivo,comercial)?: ");
				tipo = teclado.nextLine();
				switch(tipo){
				case "normal":
					empleado = new Empleado(nombre,salario);
					valido = true;
					break;
				case "directivo":
					System.out.print("Productividad: ");
					productividad = teclado.nextInt();
					empleado = new Directivo (nombre,salario,productividad);
					valido = true;
					break;
				case "comercial":
					System.out.print("Ventas: ");
					ventas = teclado.nextDouble();
					empleado = new Comercial (nombre,salario,ventas);
					valido = true;
					break;
				default: 
					System.out.println("Opcion de empleado no valida");
				}
			}catch (InputMismatchException e){
				System.out.println("El dato introducido no es correcto");
				System.out.println("Intentelo de nuevo");
			}
		}while (!valido);
		
		if (empleado!=null) empresa.add(empleado);
	}
	public static void main(String[] args) {
		String empresa = "Desconocida";
		if (args.length >0){
			empresa = args[0];
		}
		Principal ejercicio = new Principal(empresa);
		ejercicio.gestionarEmpresa();

	}

}
