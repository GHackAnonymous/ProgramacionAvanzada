package edu.mondragon.progavanzada.calcularnominas;

public class Empleado {
	int id;
	String nombre;
	double salario;
	static int numEmpleado = 0;
	
	public Empleado ( String nombre, double salario){
		this.id = ++numEmpleado;
		this.nombre = nombre;
		this.salario = salario;
	}
	
	

	public int getId() {
		return id;
	}



	public String getNombre() {
		return nombre;
	}



	public double getSalario() {
		return salario;
	}



	@Override
	public String toString() {
		
		return "Id: "+id+ " Nombre "+ nombre + "\n"+
				"Salario: "+ String.format("%6.2f",this.getSalario());
	}
	
	
}
