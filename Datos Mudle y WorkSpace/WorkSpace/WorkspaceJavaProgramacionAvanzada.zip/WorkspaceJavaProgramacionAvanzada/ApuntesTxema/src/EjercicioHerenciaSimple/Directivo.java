package edu.mondragon.progavanzada.calcularnominas;

public class Directivo extends Empleado {
	
	int productividad;
	
	public Directivo( String nombre, double salario,int productividad) {
		super(nombre, salario);
		this.productividad = productividad;
	}

	@Override
	public double getSalario() {
		
		return super.getSalario()*(1+(((double)productividad)/100));
	}
	
}
