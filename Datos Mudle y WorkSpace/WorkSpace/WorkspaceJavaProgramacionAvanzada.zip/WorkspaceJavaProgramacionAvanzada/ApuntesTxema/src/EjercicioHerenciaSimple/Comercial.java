package edu.mondragon.progavanzada.calcularnominas;

public class Comercial extends Empleado {
	static final int PORCENTAJEVENTAS= 10;
	double ventas;
	public Comercial( String nombre, double salario, double ventas) {
		super( nombre, salario);
		this.ventas = ventas;
	}
	@Override
	public double getSalario() {
		
		return super.getSalario()+(ventas*PORCENTAJEVENTAS/100);
	}
	
}
