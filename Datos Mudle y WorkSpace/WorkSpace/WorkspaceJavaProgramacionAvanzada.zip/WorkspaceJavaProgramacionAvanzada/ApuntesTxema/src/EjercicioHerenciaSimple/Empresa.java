package edu.mondragon.progavanzada.calcularnominas;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class Empresa {
	String nombre;
	
	List<Empleado> empleados;
	
	public Empresa (String nombre){
		empleados = new ArrayList<>();
		this.nombre = nombre;
	}
	public void add(Empleado e){
		empleados.add(e);
	}
	public List<Empleado> getEmpleados(){
		List<Empleado> copia = new ArrayList(empleados);
		Collections.copy(copia, empleados);
		return copia;
	}
	public void mostrar(){
		System.out.println("Empleados de la empresa: " + this.nombre);
		for (Empleado e : empleados){
			System.out.println(e);
			System.out.println();
		}
	}
}
