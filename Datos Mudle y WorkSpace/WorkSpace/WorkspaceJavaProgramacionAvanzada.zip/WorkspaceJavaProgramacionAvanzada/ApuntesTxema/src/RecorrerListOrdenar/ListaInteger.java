package RecorrerListOrdenar;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
import java.util.Random;

public class ListaInteger {
	final int NUMNUMEROS = 10;
	List<Integer> lista;
	Random generador;
	
	public ListaInteger(){
		lista = new ArrayList<>();
		generador = new Random();
	}
	public void inicializar(){
		for (int i = 0; i<NUMNUMEROS; i++){
			lista.add(generador.nextInt(100));
		}
	}
	public void recorrer1(){
		for (int valor : lista){
			System.out.println(valor);
		}
	}
	public void recorrer2(){
		for (int i = 0; i< lista.size(); i++){
			System.out.println(lista.get(i));
		}
	}
	
	public void recorrer3(){
		Iterator<Integer> it = lista.iterator();
		while (it.hasNext()){
			System.out.println(it.next());
		}
	}
	public void eliminarPares(){
		Iterator<Integer> it = lista.iterator();
		while (it.hasNext()){
			if ((it.next() %2) == 0){
				it.remove();
			}
		}
		
	}
	public void ordenar(){
		Collections.sort(lista);
	}
	public void ordenarAlReves(){
		Collections.sort(lista, new Comparator<Integer>(){

			@Override
			public int compare(Integer num1, Integer num2) {
				
				return num2 - num1;
			}
			
		});
	}
	
	public static void main (String [] args){
		ListaInteger programa = new ListaInteger();
		programa.inicializar();
		programa.recorrer1();
		System.out.println();
		programa.ordenarAlReves();
		programa.recorrer1();
	}
	
	
	
	
	
	
	
	
	
}
