
package RecorrerListOrdenar;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Random;
import java.util.Set;

public class ListAlumnos {
	final int NUMNUMEROS = 10;
	List<Alumno> lista;
	Random generador;
	
	public ListAlumnos(){
		lista = new ArrayList<>();
		generador = new Random();
	}
	public void inicializar(){
		lista.add(new Alumno (1,"Txema","Perez"));
		lista.add(new Alumno (2,"Miren","Illarramendi"));
		lista.add(new Alumno (3,"Xabi","Elkoro"));
		lista.add(new Alumno (4,"Xabier","Sagarna"));
		lista.add(new Alumno (5,"Felix","Larrinaga"));
		lista.add(new Alumno (6,"Leire","Etxeberria"));
		lista.add(new Alumno (7,"Txema","Albistegi"));
		lista.add(new Alumno (1,"Txema","Perez"));
		lista.add(new Alumno (1,"Txema","Perez"));
		
	}
	public void recorrer1(){
		for (Alumno alumno : lista){
			System.out.println(alumno);
		}
	}
	public void recorrer2(){
		for (int i = 0; i< lista.size(); i++){
			System.out.println(lista.get(i));
		}
	}
	
	public void recorrer3(){
		Iterator<Alumno> it = lista.iterator();
		while (it.hasNext()){
			System.out.println(it.next());
		}
	}

	public void ordenar(){
		Collections.sort(lista);
	}
	
	/*	public void ordenarAlReves(){
		Collections.sort(lista, new Comparator<Integer>(){

			@Override
			public int compare(Integer num1, Integer num2) {
				
				return num2 - num1;
			}
			
		});
	}*/
	
	
	public void verSinRepetidos(){
		Set<Alumno> alumnos = new HashSet<>();
		for (Alumno a: lista){
			alumnos.add(a);
		}
		for (Alumno a: alumnos){
			System.out.println(a);
		}
	}
	
	public static void main (String [] args){
		ListAlumnos programa = new ListAlumnos();
		
		programa.inicializar();
		programa.recorrer1();
		System.out.println();
		programa.verSinRepetidos();
		
	}
	
	
}
