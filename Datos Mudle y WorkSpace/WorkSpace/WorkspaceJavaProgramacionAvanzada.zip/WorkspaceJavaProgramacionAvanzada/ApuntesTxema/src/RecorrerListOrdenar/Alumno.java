package RecorrerListOrdenar;

public class Alumno implements Comparable<Alumno>{
	int idal;
	String nombre;
	String apellido;
	double nota;
	
	

	
	public Alumno(int idal, String nombre, String apellido){
		this.idal = idal;
		this.nombre = nombre;
		this.apellido = apellido;
		this.nota = 0.0;
		
		
	}
	
	@Override
	public boolean equals(Object obj) {
		if (obj == null) return false;
		if (obj.getClass() != this.getClass()) return false;
		Alumno a = (Alumno) obj;
		return (a.idal != this.idal)? false :
			(!a.nombre.equals(this.nombre))? false:
			(a.apellido.equals (this.apellido));
	}

	@Override
	public int hashCode() {
		
		return idal + nombre.hashCode()+apellido.hashCode();
	}
	@Override
	public String toString() {
		return "Idal: "+ this.idal +"\n" +
		        "Nombre: " + this.nombre+" "+ this.apellido+"\n"+
				"Nota: " + this.nota;
	}
	public double getNota() {
		return nota;
	}

	public void setNota(double nota) {
		this.nota = nota;
	}

	public int getIdal() {
		return idal;
	}

	public String getNombre() {
		return nombre;
	}

	public String getApellido() {
		return apellido;
	}
	
	@Override
	public int compareTo(Alumno o) {
		
		return (this.nombre.compareTo(o.nombre)!=0)?this.nombre.compareTo(o.nombre):
			this.apellido.compareTo(o.apellido);
	}
	
}
