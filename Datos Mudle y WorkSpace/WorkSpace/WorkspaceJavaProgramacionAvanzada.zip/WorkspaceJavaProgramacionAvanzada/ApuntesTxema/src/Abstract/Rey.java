

public class Rey extends Pieza {

	public Rey(Posicion posicion, String denominacion){
		super (posicion,denominacion);
	}

	public boolean mover(Posicion nuevaPosicion){
		if (posicionValida (nuevaPosicion)){
			posicion.mover(nuevaPosicion);
			return true;
		}
		return false;
	}

	private boolean posicionValida(Posicion nuevaPosicion) {
		int desplazamientoHorizontal = Math.abs(nuevaPosicion.getHorizontal() - posicion.getHorizontal());
		int desplazamientoVertical = Math.abs(nuevaPosicion.getVertical()-posicion.getVertical());
		if ((desplazamientoHorizontal != 1 ) || (desplazamientoVertical != 1)){
			return false;
		}
		return true;
	}

}
