

import java.util.Scanner;

public class Juego {
	static final int NUMPIEZAS = 16;
	static final int NUMPEONES = 8;
	
	Pieza piezas [];
	Scanner teclado;
	
	public Juego(){
		inicializarJuego();
		teclado = new Scanner (System.in);
	}
	

	private void inicializarJuego() {
		int contador= 0;
		piezas = new Pieza [NUMPIEZAS];
				
		for (int i = 0; i<NUMPEONES; i++){
			piezas[contador++] = new Peon(new Posicion(i+1,2), "Peon "+(i+1));
		}
		piezas[contador++]= new Torre(new Posicion(1,1),"Torre reina");
		piezas[contador++]= new Caballo(new Posicion(2,1),"Caballo reina");
		piezas[contador++]= new Alfil(new Posicion(3,1),"Alfil reina");
		piezas[contador++]= new Reina(new Posicion(4,1),"Reina");
		piezas[contador++]= new Rey(new Posicion(5,1),"Rey");
		piezas[contador++]= new Alfil(new Posicion(6,1),"Alfil rey");
		piezas[contador++]= new Caballo(new Posicion(7,1),"Caballo rey");
		piezas[contador++]= new Torre(new Posicion(8,1),"Torre rey");
	}


	private void moverPieza(int indicePieza) {
		Posicion nuevaPosicion;
		boolean valido= false;
		
		nuevaPosicion = leerPosicionAMover();
		valido = piezas[indicePieza].mover(nuevaPosicion);
		
		if (valido){
			System.out.println("movimiento realizado");
		}else{
			System.out.println("movimiento no valido");
		}
	}


	private Posicion leerPosicionAMover() {
		int horizontal, vertical;
		Posicion nuevaPosicion;
		System.out.print("Posicion a mover (h v)?: ");
		horizontal = teclado.nextInt();
		vertical = teclado.nextInt();
		nuevaPosicion = new Posicion(horizontal,vertical);
		return nuevaPosicion;
	}


	private int seleccionarPiezaAMover() {
		int indicePiezaSeleccionada;
				
		for (int i = 0; i<NUMPIEZAS; i++){
			System.out.println((i+1+".- "+piezas[i]));
		}
		
		System.out.println("0  Salir de la aplicaci�n");
		
		System.out.print("Seleccione opci�n: ");
		indicePiezaSeleccionada = teclado.nextInt(); teclado.nextLine();
	
		return indicePiezaSeleccionada-1;
	}

	public static void main(String[] args) {
		int indicePieza;
		Juego juego = new Juego();
		do{
			indicePieza = juego.seleccionarPiezaAMover();
			if (indicePieza != 0){
				juego.moverPieza(indicePieza);
			}
		}while (indicePieza != 0);
		
		
	}


	

}
