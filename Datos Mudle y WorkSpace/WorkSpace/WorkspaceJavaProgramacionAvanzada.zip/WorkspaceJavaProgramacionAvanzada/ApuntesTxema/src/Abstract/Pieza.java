
public  class Pieza {
	Posicion posicion;
	String denominacion;
	
	public Pieza(Posicion posicion, String denominacion){
		this.posicion = posicion;
		this.denominacion = denominacion;
	}
	
	public Posicion getPosicion() {
		return posicion;
	}

	public String getDenominacion() {
		return denominacion;
	}

	
	@Override
	public String toString() {
		return denominacion + " "+ posicion.toString();
	}
	
}
