

public class Posicion {
	int horizontal;
	int vertical;
	
	public Posicion(int h,int v){
		this.horizontal = h;
		this.vertical = v;
	}
	
	public int getHorizontal() {
		return horizontal;
	}

	public int getVertical() {
		return vertical;
	}

	public void mover (Posicion nuevaPosicion){
		this.horizontal = nuevaPosicion.horizontal;
		this.vertical = nuevaPosicion.vertical;
	}

	@Override
	public String toString() {
		
		return "("+horizontal+","+vertical+")";
	}
	
}
