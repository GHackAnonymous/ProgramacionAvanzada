

public class Torre extends Pieza{
	
	
	public Torre(Posicion posicion, String denominacion){
		super(posicion,denominacion);
	}
	public boolean mover(Posicion nuevaPosicion){
		if (posicionValida (nuevaPosicion)){
			posicion.mover(nuevaPosicion);
			return true;
		}
		return false;
	}

	private boolean posicionValida(Posicion nuevaPosicion) {
		if ((nuevaPosicion.getHorizontal()!=posicion.getHorizontal())){
			return (nuevaPosicion.getVertical()==posicion.getVertical());
		}else{
			return (nuevaPosicion.getVertical()!= posicion.getVertical());
		}
	}
	
}
