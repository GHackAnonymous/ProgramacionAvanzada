

public class Peon extends Pieza{
	boolean primerMovimiento;
	
	
	public Peon(Posicion posicion, String denominacion){
		super (posicion,denominacion);
		this.primerMovimiento = true;
		
	}
	
	public boolean mover(Posicion nuevaPosicion){
		if (posicionValida (nuevaPosicion)){
			posicion.mover(nuevaPosicion);
			primerMovimiento = false;
			return true;
		}
		return false;
	}

	private boolean posicionValida(Posicion nuevaPosicion) {
		if (posicion.getHorizontal()!= nuevaPosicion.getHorizontal()){
			return false;
		}
		int desplazamiento = nuevaPosicion.getVertical() - posicion.getVertical();
		if (desplazamiento > ((primerMovimiento)?2:1)){
			return false;
		}
		return true;
	}

}
