
public class Fecha  {
	int dia;
	int mes;
	int a�o;
	
	public Fecha(){
		this.dia = 1;
		this.mes = 1;
		this.a�o = 0;
	}
	
	public Fecha (int d, int m, int a) throws Exception   {
		checkA�o(a);
		this.a�o = a;
		checkMes(m);
		this.mes = m;
		checkDia(d,m,a);
		this.dia = d;
		
	}
	private void checkMes(int m)throws Exception{
		if (m>12 || m<1)
			throw new Exception("Mes erroneo " + m);
			
	}
	private void checkA�o(int a) throws Exception{
		if (a<0 )
			throw new Exception("A�o erroneo "+ a);
			
	}
	private void checkDia (int d, int m, int a)throws Exception{
		int numdias = 31; 
		switch (mes){
		case	4:
		case	6:
		case	9:
		case   11: numdias = 30; break;
		case	2: numdias= (a%4==0)?29:28;
		}
		if (d>numdias || d<1)
			throw new Exception ("D�a erroneo " + d);
		if ((d==19)&&(m==6))
		throw new TXEMAException();
	}
	
	
}
