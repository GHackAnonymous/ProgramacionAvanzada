
import java.io.*;
import java.util.*;
public class LecturaFecha {
	
	
	public static void main(String[] args) {
	
		Fecha f= null;
		
		int d,m,a;
		boolean valida = false;
		boolean fiesta = false;
		
		
		Scanner teclado = new Scanner (System.in);
		
		
		while (!valida){
			
			
			try {
				System.out.println ("Introduzca una fecha(dd mm aaaa):");
				
				d = teclado.nextInt();
				m = teclado.nextInt();
				a = teclado.nextInt();
				teclado.nextLine();
				f = new Fecha (d,m,a);
				
				valida = true;
					
			}catch (IOException e){
				System.out.println ("Error en la entrada");
				
			}catch (InputMismatchException e){
				
				System.out.println ("El formato es dd mm aaaa");
				teclado.nextLine();
			} 	catch (TXEMAException e){
					valida = true;
					fiesta = true;
					System.out.println (e.getMessage());
			}catch  (Exception e){
				
				System.out.println (e.getMessage());
				
			}finally{
				System.out.println("Esto siempre");
			}
		
		}
		
			
		
		if (fiesta)
			
		
			System.out.println("ZORIONAK hoy es tu d�a");
		else
			System.out.println("Fecha valida");
	}
	
}
