
public class TXEMAException extends Exception {
	public TXEMAException (){
		super ("Cumplea�os de Txema ");
	}
}