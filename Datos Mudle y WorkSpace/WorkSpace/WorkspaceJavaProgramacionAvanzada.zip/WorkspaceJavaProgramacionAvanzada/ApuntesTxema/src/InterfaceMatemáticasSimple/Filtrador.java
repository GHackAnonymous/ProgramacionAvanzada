package edu.mondragon.progavanzada.generadornumeros;

public interface Filtrador {
	boolean validar(int valor);
}
