package edu.mondragon.progavanzada.generadornumeros;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class Generador {
	
	Random generador;
	ArrayList<Integer> lista;
	
	public Generador() {
		
		generador = new Random();
		lista = new ArrayList<>();
	}
	
	//pasa el numero por el filtro seleccionado e a�ade si eso
	public List<Integer> generarNumeros (int num,int limite,Filtrador filtro){
		for (int i = 0; i<num; ){
			int valor = generador.nextInt(limite);
			if (filtro.validar(valor)){
				lista.add(valor);
				i++;
			}
		}
		return lista;
	}
}
