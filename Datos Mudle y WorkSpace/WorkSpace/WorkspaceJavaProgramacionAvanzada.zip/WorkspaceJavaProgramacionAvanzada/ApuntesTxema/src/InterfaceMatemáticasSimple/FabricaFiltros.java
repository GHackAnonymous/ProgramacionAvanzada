package edu.mondragon.progavanzada.generadornumeros;

public class FabricaFiltros {
	
	public static Filtrador getFiltroPrimos(){
		return new FiltroPrimos();
	}
	public static Filtrador getFiltroCapicua(){
		return new FiltroCapicua();
	}
	
	public static Filtrador getFiltroTrece(){
		return new FiltroTrece();
	}
	
	public static class FiltroPrimos implements Filtrador {

		
		@Override
		public boolean validar(int valor) {
			if (valor <=2) return false;
			for (int i = 2; i<= (Math.sqrt(valor)+1); i++){
				if (valor%i==0) return false;
			}
			return true;
		}

	}
	public static class FiltroCapicua implements Filtrador{

		@Override
		public boolean validar(int valor) {
			
			
			String numero = String.valueOf(valor);
			if (numero.length()<=1 ) return false;
			for (int i = 0; i<numero.length()/2; i++){
				if (numero.charAt(i)!=numero.charAt(numero.length()-i-1)){
					return false;
				}
			}
			return true;
	
		}

	}
	public static class FiltroTrece implements Filtrador {

		
		@Override
		public boolean validar(int valor) {
			int suma = 0;
			while (valor>0){
				suma += valor%10;
				valor /= 10;
			}
			return suma == 13;
		}

	}
}
