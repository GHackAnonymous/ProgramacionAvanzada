package edu.mondragon.progavanzada.generadornumeros;

import java.util.List;

public class Principal {
	final int NUMNUMEROS = 10;
	final int LIMITE = 1000;
	Filtrador filtro;
	Generador generador;
	List<Integer> valores;
	
	public Principal(String opcion){
		filtro = seleccionarFiltro (opcion);
		generador = new Generador ();
	}
	private Filtrador seleccionarFiltro(String opcion) {
		switch (opcion){
		case "primos": return FabricaFiltros.getFiltroPrimos(); 
		case "capicuas": return FabricaFiltros.getFiltroCapicua(); 
		case "suma13": return FabricaFiltros.getFiltroTrece(); 
		}
		return null;
	}
	private void generarNumeros() {
		valores = generador.generarNumeros (NUMNUMEROS,LIMITE,filtro);
		
	}
	private void mostrarNumeros() {
		for (Integer i : valores){
			System.out.println(i);
		}
		
	}
	public static void main(String[] args) {
		if (args.length<1){
			System.out.println("Debes indicar el filtro a utilizar: primos-capicuas-suma13");
			return;
		}
		Principal ejercicio = new Principal (args[0]);
		ejercicio.generarNumeros();
		ejercicio.mostrarNumeros();
	}
	

	

}
