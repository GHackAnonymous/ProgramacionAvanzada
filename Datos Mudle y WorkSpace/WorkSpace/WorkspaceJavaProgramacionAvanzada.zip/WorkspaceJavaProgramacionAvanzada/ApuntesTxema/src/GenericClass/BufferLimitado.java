package edu.mondragon.progravanzada.bufferlimitado;

import java.util.ArrayList;
import java.util.List;

public class BufferLimitado <T>{
	
	List<T> buffer;
	int maxValores;
	
	
	public BufferLimitado(int numElementos){
		this.maxValores = numElementos;
		buffer = new ArrayList<>();
		
	}

	public void put (T valor ) throws BufferException {
		if (buffer.size() == maxValores){
			throw new BufferException("Buffer lleno");
		}
		buffer.add(valor);
	}
	public T get () throws BufferException{
		if (buffer.size() == 0){
			throw new BufferException("Buffer vacio");
		}
		return buffer.remove(0);
	}
}

