package edu.mondragon.progravanzada.bufferlimitado;

import java.util.Random;

public class Principal {
	
	private static final int CAPACIDAD = 4;
	private final int NUMVECES = 25;
	
	BufferLimitado<Integer> buffer;
	Random generador;
	
	public Principal(){
		buffer = new BufferLimitado<>(CAPACIDAD);
		generador = new Random();
	}

	public void generarValores(){
		int valor = 0;
		for (int i= 0; i<NUMVECES; i++){
			if (generador.nextBoolean()){
				valor = generador.nextInt(100);
				try {
					buffer.put (valor);
					System.out.println("Guardado valor "+ valor);
				} catch (BufferException e) {
					System.out.println("No se ha podido guardar "+ valor+ " porque "+e.getMessage());
					
				}
				
			}else{
				try {
					valor = buffer.get();
					System.out.println(valor +" se ha sacado");
				} catch (BufferException e) {
					System.out.println("No se ha podido sacar valor porque "+ e.getMessage());
				}
				
			}
		}
	}
	public static void main(String[] args) {
		Principal ejercicio = new Principal();
		ejercicio.generarValores();
	}

}
