package edu.mondragon.progravanzada.bufferlimitado;

public class BufferException extends Exception {
	public BufferException(String msg){
		super(msg);
	}
}
