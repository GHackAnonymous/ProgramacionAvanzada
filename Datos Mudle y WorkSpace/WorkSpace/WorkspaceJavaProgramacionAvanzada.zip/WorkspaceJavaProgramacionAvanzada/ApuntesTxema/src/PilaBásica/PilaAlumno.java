package coleccion;

public class PilaAlumno {
	NodoAlumno head;
	
	public PilaAlumno(){
		head = null;
	}
	public void put (Alumno valor){
		NodoAlumno nodo = new NodoAlumno();
		nodo.setValor(valor);
		nodo.setSiguiente(head);
		head = nodo;
	}
	public Alumno get (){
		Alumno valor = head.getValor();
		head = head.getSiguiente();
		return valor;
	}
	public boolean vacia(){
		return head==null;
	}
}
