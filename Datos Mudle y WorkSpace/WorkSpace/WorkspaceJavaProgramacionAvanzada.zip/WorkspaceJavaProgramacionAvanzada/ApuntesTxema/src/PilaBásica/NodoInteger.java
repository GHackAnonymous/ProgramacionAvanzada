package coleccion;

public class NodoInteger {
	
	int valor;
	NodoInteger siguiente;
	public int getValor() {
		return valor;
	}
	public void setValor(int valor) {
		this.valor = valor;
	}
	public NodoInteger getSiguiente() {
		return siguiente;
	}
	public void setSiguiente(NodoInteger siguiente) {
		this.siguiente = siguiente;
	}
	
	
}
