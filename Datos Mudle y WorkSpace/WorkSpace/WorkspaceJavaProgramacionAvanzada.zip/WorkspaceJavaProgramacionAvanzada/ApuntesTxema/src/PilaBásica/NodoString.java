package coleccion;

public class NodoString {
	String valor;
	NodoString siguiente;
	
	public String getValor() {
		return valor;
	}
	public void setValor(String valor) {
		this.valor = valor;
	}
	public NodoString getSiguiente() {
		return siguiente;
	}
	public void setSiguiente(NodoString siguiente) {
		this.siguiente = siguiente;
	}
	
}
