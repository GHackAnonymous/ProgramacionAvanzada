package coleccion;

public class PilaString {
	NodoString head;
	
	public PilaString(){
		head = null;
	}
	public void put (String valor){
		NodoString nodo = new NodoString();
		nodo.setValor(valor);
		nodo.setSiguiente(head);
		head = nodo;
	}
	public String get (){
		String valor = head.getValor();
		head = head.getSiguiente();
		return valor;
	}
	public boolean vacia(){
		return head==null;
	}
}
