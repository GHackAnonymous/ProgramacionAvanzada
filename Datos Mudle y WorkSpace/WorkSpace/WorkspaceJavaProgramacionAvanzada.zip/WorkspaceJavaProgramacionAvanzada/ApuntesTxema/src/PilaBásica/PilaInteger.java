package coleccion;

public class PilaInteger {
	NodoInteger head;
	
	public PilaInteger(){
		head = null;
	}
	public void put (int valor){
		NodoInteger nodo = new NodoInteger();
		nodo.setValor(valor);
		nodo.setSiguiente(head);
		head = nodo;
	}
	public int get (){
		int valor = head.getValor();
		head = head.getSiguiente();
		return valor;
	}
	public boolean vacia(){
		return head==null;
	}
}
