package coleccion;

public class NodoAlumno {
	Alumno valor;
	NodoAlumno siguiente;
	
	public Alumno getValor() {
		return valor;
	}
	public void setValor(Alumno valor) {
		this.valor = valor;
	}
	public NodoAlumno getSiguiente() {
		return siguiente;
	}
	public void setSiguiente(NodoAlumno siguiente) {
		this.siguiente = siguiente;
	}
}
