
public interface Comparator {
	int comparar (Alumno a, Alumno b);
}
