

public class FabricaComparadores {
	
	public static Comparator getComparadorNombre(){
		return new ComparadorNombre();
	}
	public static Comparator getComparadorApellido(){
		return new ComparadorApellido();
	}

	public static Comparator getComparadorNota(){
		return new ComparadorNota();
	}
	public static class ComparadorApellido implements Comparator {

		@Override
		public int comparar(Alumno a, Alumno b) {
			
			return a.getApellido().compareTo(b.getApellido());
		}

	}
	public static class ComparadorNombre implements Comparator {

		@Override
		public int comparar(Alumno a, Alumno b) {
			
			return a.getNombre().compareTo(b.getNombre());
		}

	}
	public static class ComparadorNota implements Comparator {

		@Override
		public int comparar(Alumno a, Alumno b) {
			if (a.getNota()>b.getNota()) return 1;
			if (a.getNota()<b.getNota()) return -1; 
			return 0;
		}

	}
}
