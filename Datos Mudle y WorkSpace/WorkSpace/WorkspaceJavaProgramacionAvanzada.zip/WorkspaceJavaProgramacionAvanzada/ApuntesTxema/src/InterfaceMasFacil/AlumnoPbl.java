

public class AlumnoPbl extends Alumno {
	double notaPbl;
	
	public AlumnoPbl (int idal, String nombre, String apellido){
		super(idal,nombre,apellido);
		this.notaPbl = 0.0;
	}

	public double getNotaPbl() {
		return notaPbl;
	}

	public void setNotaPbl(double notaPbl) {
		this.notaPbl = notaPbl;
	}

	@Override
	public String toString() {
		String resultado = super.toString()+"\n"+
						   "Nota Pbl: " + this.notaPbl;
		return resultado;
	}

	
}
