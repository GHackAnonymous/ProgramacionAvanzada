

public class Clase {
	String nombre;
	Alumno [] listaAlumnos;
	int numAlumnos;
	int maxAlumnos;
	int cursor;
	
	public Clase (String nombre, int maxAlumnos){
		this.nombre = nombre;
		this.maxAlumnos = maxAlumnos;
		listaAlumnos = new Alumno [maxAlumnos];
		numAlumnos = 0;
	}
	
	public boolean a�adir (Alumno alumno){
		if ( numAlumnos == maxAlumnos){
			return false;
		}
		listaAlumnos [numAlumnos++] = alumno;
		return true;
	}
	public boolean vacia (){
		return numAlumnos == 0;
	}
	public void irPrimero(){
		cursor = 0;
	}
	public void irSS(){
		cursor++;
	}
	public boolean fin(){
		return cursor == numAlumnos;
	}
	public Alumno getAlumno(){
		return listaAlumnos [cursor];
	}
	public Alumno [] getAlumnos(){
		Alumno alumnos [] = new Alumno [numAlumnos];
		System.arraycopy(listaAlumnos, 0, alumnos, 0, numAlumnos);
		return alumnos;
	}
	
	//esta es la funcion que pide un comparador,
	//vamos, el que interactua con la f�brica
	public void ordenar(Comparator comparador) {
		int minimo;
		for (int i=0; i<(numAlumnos -1); i++){
			minimo = i;
			for (int j=i+1;j<numAlumnos; j++){
				if (comparador.comparar(listaAlumnos[minimo], listaAlumnos[j])>0){
					minimo = j;
				}
			
			}
			Alumno temporal;
			temporal = listaAlumnos[i];
			listaAlumnos[i]=listaAlumnos[minimo];
			listaAlumnos[minimo]=temporal;
			
		}
		
		
		
	}
}
