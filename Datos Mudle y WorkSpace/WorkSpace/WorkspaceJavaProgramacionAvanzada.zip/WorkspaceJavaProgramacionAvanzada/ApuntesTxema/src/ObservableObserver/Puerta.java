package ascensor;

import java.util.Observable;

public class Puerta extends Observable {

	boolean estado; //true abierta --- false cerrada
	
	public Puerta (){
		estado = false;
	}
	public boolean getEstado() {
		return estado;
	}
	public void cerrar() {
		if (estado == true){
			//System.out.println("Se cierra la pueta");
			estado = false;
			this.setChanged();
			this.notifyObservers(this);
		}
		
	}

	public void abrir() {
		if (estado == false){
			//System.out.println("Se abre la puerta");
			estado = true;
			this.setChanged();
			this.notifyObservers(this);
		}
		
	}

}
