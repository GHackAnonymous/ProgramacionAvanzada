package ascensor;

import java.util.Observable;
import java.util.Observer;

public class Ascensor extends Observable implements Observer{

	int pisoActual;
	Puerta puerta;
	int id;
	public Ascensor (int id){
		this.id = id;
		pisoActual = 0;
		puerta = new Puerta();
		puerta.addObserver(this);
	}
	
	public int getId() {
		return id;
	}

	public void mover (int piso){
		if (piso>pisoActual){
			subir (piso);
		}else{
			bajar (piso);
		}
	}
	private void subir(int piso){
		puerta.cerrar();
		
		for ( ; pisoActual<=piso; pisoActual++){
			
			//pisoActual = i;
			this.setChanged();
			this.notifyObservers(this);
			//System.out.println ("Ascensor "+id+" en piso: "+ i);
		}
		puerta.abrir();
		pisoActual = piso;
	}
	private void bajar(int piso){
		puerta.cerrar();
		
		for (int i = pisoActual; i>=piso; i--){
			pisoActual = i;
			this.setChanged();
			this.notifyObservers(this);
			//System.out.println ("Ascensor "+id+" en piso: "+ i);
		}
		puerta.abrir();
		pisoActual = piso;
	}

	public int getPisoActual() {
		return pisoActual;
	}

	@Override
	public void update(Observable o, Object puerta) {
		this.setChanged();
		this.notifyObservers(puerta);
	}

	
}
