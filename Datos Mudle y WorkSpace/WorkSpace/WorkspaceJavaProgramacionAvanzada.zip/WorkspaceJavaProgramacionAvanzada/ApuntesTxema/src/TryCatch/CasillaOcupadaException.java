package edu.mondragon.pa.buscaminas;

public class CasillaOcupadaException extends Exception {
	public CasillaOcupadaException (String msg){
		super(msg);
	}
}
