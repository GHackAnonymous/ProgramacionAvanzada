package edu.mondragon.pa.buscaminas;

public class Buscaminas {

	int dimension = 10;
	Casilla panel [][];
	
	public Buscaminas (int dimension){
		this.dimension = dimension;
		panel = new Casilla [dimension][dimension];
		for (int i= 0;i<dimension; i++){
			for (int j=0;j<dimension;j++){
				panel [i][j]= new Casilla(0);
			}
		}
	}
	public void setMina(int i,int j) throws CasillaOcupadaException{
		
		panel[i][j].setMina();
		recalcularCasillas(i,j);
	}
	private void recalcularCasillas(int i, int j) {
		int inicx = (i==0)? 0: i-1;
		int finx = (i==dimension-1)? i:i+1;
		int inicy = (j==0)? j: j-1;
		int finy = (j==dimension-1)? j: j+1;
		for (int k = inicx; k<=finx; k++){
			for (int l = inicy; l<=finy; l++){
				panel[k][l].inc();
			}
		}
		
	}
	public int mostrarCasilla(int i,int j) throws ErrorJugadaException{
		if (panel[i][j].contieneMina() )
			throw new ErrorJugadaException ("Error en la jugada");
		return panel[i][j].getValor();
	}
	public void desactivarMina ( int i, int j) throws ErrorJugadaException{
		if (!panel[i][j].contieneMina()){
			throw new ErrorJugadaException ("Error en la jugada");
		}
		panel[i][j].desactivarMina();
	}
	public void mostrar() {
		for (int i=0; i<dimension; i++){
			for (int j= 0; j<dimension; j++){
				System.out.format("%4d", panel[i][j].getValor());
			}
			System.out.println();
		}
		
	}
}
