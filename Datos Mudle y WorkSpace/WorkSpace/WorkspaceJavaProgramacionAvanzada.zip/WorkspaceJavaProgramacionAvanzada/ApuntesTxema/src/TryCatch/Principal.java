package edu.mondragon.pa.buscaminas;

import java.util.InputMismatchException;
import java.util.Random;
import java.util.Scanner;

public class Principal {

	private static final int MAXMINAS = 20;
	private static final int DIMENSION = 10;
	Buscaminas buscaminas;
	Scanner teclado;
	Random generador;
	int numMinasDesactivadas;
	public Principal(){
		
		buscaminas = new Buscaminas(DIMENSION);
		teclado = new Scanner (System.in);
		generador = new Random();
		numMinasDesactivadas = 0;
	}
	
	public void colocarMinas(){
		for (int i = 0; i<MAXMINAS; ){
			
			try {
				int x = generador.nextInt(DIMENSION);
				int y = generador.nextInt(DIMENSION);
				buscaminas.setMina(x, y);
				
				i++;
			} catch (CasillaOcupadaException e) {
				
			}
		}
	}
	public void imprimirTablero(){
		buscaminas.mostrar();
	}
	public void jugar(){
		String opcionMina, opcionContinuar= "s";
		int i,j;
		try{
			do{
				try{
					System.out.print("Introduce casilla (x y (m/n):");
					i = teclado.nextInt();
					j = teclado.nextInt();
					opcionMina = teclado.nextLine();
					if (opcionMina.contains("m")){
						buscaminas.desactivarMina(i, j);
						numMinasDesactivadas++;
						System.out.println("Mina casilla ("+i+","+j+") desactivada");
					}else {
						System.out.println("Valor casilla ("+i+","+j+"): "+buscaminas.mostrarCasilla(i,j));
					}
					
				}catch (InputMismatchException e){
					System.out.println("Error al introducir los datos. Prueba de nuevo ");
					teclado.nextLine();
					continue;	
				}catch (IndexOutOfBoundsException e){
					System.out.println ("la casilla tiene que estar entre 0 y "+(DIMENSION-1));
					continue;
				}
				System.out.print("continuar (s/n)?:");
				opcionContinuar = teclado.nextLine();
			}while (opcionContinuar.toLowerCase().equals("s")||(numMinasDesactivadas == MAXMINAS));
		}catch (ErrorJugadaException e){
			System.out.println("Has perdido la partida");
		}
	}
	public static void main(String[] args) {
		Principal ejercicio = new Principal();
		ejercicio.colocarMinas();
		ejercicio.imprimirTablero();
		ejercicio.jugar();

	}

}
