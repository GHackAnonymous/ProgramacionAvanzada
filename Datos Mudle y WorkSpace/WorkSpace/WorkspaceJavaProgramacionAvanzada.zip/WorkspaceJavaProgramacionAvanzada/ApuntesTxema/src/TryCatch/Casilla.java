package edu.mondragon.pa.buscaminas;

public class Casilla {
	
	int valor; // -1 mina;
			   // -2 desactivada
			   // 0..n n�mero de minas que la rodean.
	
	public Casilla (int valor){
		this.valor = valor;
	}

	public int getValor() {
		return valor;
	}
	
	public void setMina() throws CasillaOcupadaException {
		if (valor == -1 )
			throw  new CasillaOcupadaException("casilla  ocupada");
			
		this.valor = -1;
	}
	public void inc(){
		if (this.valor>=0){
			valor++;
		}
	}
	public boolean contieneMina(){
		return valor==-1;
	}
	public void desactivarMina(){
		this.valor = -2;
	}
}
