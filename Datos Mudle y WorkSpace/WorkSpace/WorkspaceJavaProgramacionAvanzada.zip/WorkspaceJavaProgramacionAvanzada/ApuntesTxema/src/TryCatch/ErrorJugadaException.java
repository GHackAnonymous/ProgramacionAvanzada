package edu.mondragon.pa.buscaminas;

public class ErrorJugadaException extends Exception {
	public ErrorJugadaException(String msg){
		super(msg);
	}
}
