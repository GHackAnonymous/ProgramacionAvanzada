package edu.mondragon.pa.figuras;

import java.util.List;

public class Cuadrado extends Figura {
	
	final String [] PARAMETROS = {"lado"};
	
	int lado;
	
	public Cuadrado(Punto p) {
		super(p);
		
	}


	@Override
	public void setValores(List<Integer> datos) {
		lado = datos.get(0);
		
	}


	@Override
	public String[] getListaDatos() {
		return PARAMETROS;
	}


	@Override
	public double area() {
		
		return (double) lado*lado;
	}


	@Override
	public String toString() {
		
		return "Cuadrado, posicion: "+punto + " lado: "+ lado + " area: "+ area();
	}

	
}
