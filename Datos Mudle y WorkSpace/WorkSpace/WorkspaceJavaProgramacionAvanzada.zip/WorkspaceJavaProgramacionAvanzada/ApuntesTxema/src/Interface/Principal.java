package edu.mondragon.pa.figuras;

import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.List;
import java.util.Scanner;

public class Principal {

	ListaFiguras listaFiguras;
	Scanner teclado;
	
	public Principal(){
		listaFiguras = new ListaFiguras();
		teclado = new Scanner ( System.in);
	}
	public Punto leerPunto(){
		Punto p= null;
		int x, y;
		do{
			try{
				
				System.out.print("Punto (x,y) : ");
				x = teclado.nextInt();
				y = teclado.nextInt();
				teclado.nextLine();
				p = new Punto (x,y);
				
			}catch (InputMismatchException e){
				System.out.println("formato no valido. Prueba de nuevo");
				teclado.nextLine();
			}
		}while (p == null);
		return p;
	}
	public Figura leerTipoFigura(Punto p){
		Figura figura = null;
		String tipoFigura;
		do{
			System.out.print("c- cuadradado/r- rectangulo/t- triangulo/o- circulo:  ");
			tipoFigura = teclado.nextLine();
		
			switch(tipoFigura){
			case "c": figura = new Cuadrado(p);break;
			case "r": figura = new Rectangulo (p); break;
			case "t": figura = new Triangulo(p); break;
			case "o": figura = new Circulo(p); break;
			default: System.out.println("tipo figura no v�lida");
			}
		}while (figura==null);
		return figura;
	}
	public void crearFigura(){
		
		Figura figura= null;
		Punto p;
		List<Integer> datos = new ArrayList<>();
		
		p =leerPunto();
		figura = leerTipoFigura(p);
		datos = leerDatosFigura(figura);
		figura.setValores (datos);
		listaFiguras.add(figura);
		
	}
	private List<Integer> leerDatosFigura(Figura figura) {
		String [] tipoDatosFigura;
		tipoDatosFigura = figura.getListaDatos();
		int valor;
		List<Integer> datos = new ArrayList<>();
			for (int i=0; i<tipoDatosFigura.length; ){
				try{
					System.out.print(tipoDatosFigura[i]+": ");
					valor = teclado.nextInt();teclado.nextLine();
					if (valor <=0) throw new DimensionErroneaException("Las dimensiones no pueden ser negativas");
					datos.add(valor);
					i++;
				}catch(InputMismatchException e){
					System.out.println("Formato no correcto. Intentelo de nuevo");
					teclado.nextLine();
				} catch (DimensionErroneaException e) {
					System.out.println(e.getMessage());
				}
				
			}
		return datos;		
	}
	public void menu(){
		int opcion= -1;
		do{
			try{
				
			
				System.out.println("1. Crear Figura");
				System.out.println("2. Ver figuras ordenadas por �rea");
				System.out.println("3. Ver figuras ordenadas por posicion");
				System.out.println("0. Salir");
				System.out.print("  Seleccione opcion: ");
				opcion = teclado.nextInt();
				switch (opcion){
				case 1: this.crearFigura();break;
				case 2: this.verPorArea(); break;
				case 3: this.verPorPosicion(); break;
				case 0: break;
				default: System.out.println("opcion no valida");
				
				}
			}catch (InputMismatchException e ){
				System.out.println("opcion no v�lida");
				teclado.nextLine();
			}
		}while ( opcion != 0);
	}
	private void verPorPosicion() {
		Figura [] lista= listaFiguras.getListaOrdenadaPorPosicion();
		for(Figura figura: lista){
			System.out.println(figura);
		}
		
	}
	private void verPorArea() {
		Figura [] lista= listaFiguras.getListaOrdenadaPorArea();
		for(Figura figura: lista){
			System.out.println(figura);
		}
	}
	public static void main(String[] args) {
		Principal ejercicio = new Principal();
		ejercicio.menu();
	}

}
