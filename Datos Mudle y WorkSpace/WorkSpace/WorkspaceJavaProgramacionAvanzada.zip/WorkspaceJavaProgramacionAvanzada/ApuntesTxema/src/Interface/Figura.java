package edu.mondragon.pa.figuras;

import java.util.List;


public abstract  class Figura {

	
	Punto punto;
	public Figura (Punto p){
		punto = p;
	}
	
	
	public Punto getPosicion() {
		
		return punto;
	}
	public abstract String[] getListaDatos();
	public abstract void setValores(List<Integer> datos);
	public abstract double area(); 
	
	
}
