package edu.mondragon.pa.figuras;

import java.util.List;

public class Rectangulo extends Figura {
	
	final String [] PARAMETROS = {"lado1","lado2"};
	int lado1,lado2;
	
	public Rectangulo(Punto p) {
		super(p);
		
	}


	@Override
	public void setValores(List<Integer> datos) {
		lado1 = datos.get(0);
		lado2 = datos.get(1);
	}


	@Override
	public double area() {
		
		return (double) lado1*lado2;
	}
	
	@Override
	public String toString() {
		
		return "Rect�ngulo, posici�n: "+punto + " lado1: "+ lado1 +" lado2: "+ lado2+" area: "+ area();
	}


	@Override
	public String[] getListaDatos() {
		return PARAMETROS;
	}
	
}
