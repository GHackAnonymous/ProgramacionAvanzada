package edu.mondragon.pa.figuras;

import java.util.List;

public class Circulo extends Figura {
	final String [] PARAMETROS = {"radio"};
	
	int radio;
	public Circulo(Punto p) {
		super(p);
	
		
	}


	@Override
	public String[] getListaDatos() {
		
		return PARAMETROS;
	}


	@Override
	public void setValores(List<Integer> datos) {
		radio = datos.get(0);
		
	}


	@Override
	public double area() {
		
		return Math.PI*Math.pow(radio,2);
	}

	@Override
	public String toString() {
		
		return "Circulo, posicion: "+punto + " radio: "+ radio + " area: "+ area();
	}
}
