package edu.mondragon.pa.figuras;

public class DimensionErroneaException extends Exception {
	public DimensionErroneaException(String msg){
		super (msg);
	}
}
