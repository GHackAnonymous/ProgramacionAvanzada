package edu.mondragon.pa.figuras;

import java.util.Comparator;

public class FabricaComparadoresFigura {
	
	public static Comparator<Figura> getComparadorArea(){
		return new ComparadorArea();
	}
	public static Comparator<Figura> getComparadorPosicion(){
		return new ComparadorPosicion();
	}
	
	public static class ComparadorArea implements Comparator<Figura> {

		
		@Override
		public int compare(Figura a, Figura b) {
			
			if (a.area()<b.area()) return -1;
			if (a.area()>b.area()) return 1;
			return 0;
		}

	}
	public static class ComparadorPosicion implements Comparator <Figura>{

		@Override
		public int compare(Figura a, Figura b) {
			
			if (a.getPosicion().getY()<b.getPosicion().getY()) return -1;
			if (a.getPosicion().getY()>b.getPosicion().getY()) return 1;
			
			return 0;
		}

	}
}
