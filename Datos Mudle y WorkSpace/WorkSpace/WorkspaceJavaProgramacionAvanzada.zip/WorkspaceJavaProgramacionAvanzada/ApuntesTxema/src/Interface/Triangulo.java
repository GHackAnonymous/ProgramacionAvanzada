package edu.mondragon.pa.figuras;

import java.util.List;

public class Triangulo extends Figura {
	final String [] PARAMETROS = {"base","altura"};
	
	int base, altura;
	
	public Triangulo(Punto p) {
		super(p);
		
	}


	@Override
	public void setValores(List<Integer> datos) {
		base = datos.get(0);
		altura = datos.get(1);
		
	}


	@Override
	public double area() {
		
		return base*altura/2;
	}

	@Override
	public String toString() {
		
		return "Triangulo, posicion: "+punto + " base: "+ base + " altura: "+ altura+ " area: "+ area();
	}


	@Override
	public String[] getListaDatos() {
		
		return PARAMETROS;
	}
}
