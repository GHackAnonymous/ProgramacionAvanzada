package edu.mondragon.pa.figuras;

public class Punto {
	private int x ;
	private int y = 0;
	
	
	
	public Punto(int x, int y){
		this.x = x;
		this.y =  y;
		
	}

	public int getY() {
		return y;
	}

	@Override
	public String toString() {
		
		return "("+x+","+y+")";
	}
	
}
