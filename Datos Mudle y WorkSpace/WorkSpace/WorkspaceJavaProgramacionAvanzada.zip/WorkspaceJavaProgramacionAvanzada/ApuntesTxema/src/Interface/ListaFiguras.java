package edu.mondragon.pa.figuras;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class ListaFiguras {
	private List<Figura> lista;
	
	public ListaFiguras(){
		lista = new ArrayList<>();
	}
	public void add (Figura f){
		lista.add(f);
	}
	
	public Figura[]  getListaOrdenadaPorArea(){
		Collections.sort(lista,FabricaComparadoresFigura.getComparadorArea());
		return lista.toArray(new Figura[0]);
	}
	
	public Figura[] getListaOrdenadaPorPosicion(){
		Collections.sort(lista,FabricaComparadoresFigura.getComparadorPosicion());
		return lista.toArray(new Figura[0]);
	}
}
