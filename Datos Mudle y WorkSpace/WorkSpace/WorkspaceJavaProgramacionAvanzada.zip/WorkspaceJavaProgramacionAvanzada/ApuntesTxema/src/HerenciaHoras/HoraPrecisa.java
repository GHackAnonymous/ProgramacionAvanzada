package edu.mondragon.progavanzada.horas;

public class HoraPrecisa extends Hora {
	int segundos;

	public HoraPrecisa(int hora, int minutos, int segundos) {
		super(hora, minutos);
		this.segundos = segundos;
		
	}

	public int getSegundos() {
		return segundos;
	}

	@Override
	public int compareTo(Hora h) {
		int valor = super.compareTo(h);
		if (valor!=0) return valor;
		
		if (! (h instanceof HoraPrecisa))
			return (this.segundos>0)? -1 : 0;
		
		HoraPrecisa hp = (HoraPrecisa)h;
		return (hp.segundos-this.segundos<0)? 1 : ((hp.segundos-this.segundos)>0)? -1 : 0;
	}

	@Override
	public String toString() {
		
		return super.toString()+":"+segundos;
	}
	
}
