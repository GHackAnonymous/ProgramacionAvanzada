package edu.mondragon.progavanzada.horas;

public class Hora implements Comparable<Hora>{

	private static final int MINUTOSHORA = 60;
	int hora;
	int minutos;
	
	public Hora (int hora, int minutos){
		this.hora = hora;
		this.minutos = minutos;
	}

	public int getHora() {
		return hora;
	}

	public int getMinutos() {
		return minutos;
	}
	public int compareTo( Hora h){
		int valor1 = h.hora*MINUTOSHORA + h.minutos;
		int valor2 = this.hora*MINUTOSHORA + this.minutos;
		return (valor2-valor1<0)? 1 : (valor2-valor1>0)? -1 : 0;
	}

	
	@Override
	public String toString() {
		
		return this.hora+":"+this.minutos;
	}

	
}
