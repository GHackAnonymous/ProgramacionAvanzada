package edu.mondragon.progavanzada.horas;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

public class ListaHoras {
	ArrayList<Hora> lista;
	
	public ListaHoras(){
		lista = new ArrayList<>();
	}

	public void add(Hora hora) {
		lista.add(hora);
		
	}

	public void mostrarHoras(){
		for (Hora h : lista){
			System.out.print(h+"  ");
		}
		System.out.println();
	}
	public Hora getMenor() {
		
		Hora menor = lista.get(0);
		for (Hora h : lista){
			if (h.compareTo(menor)==1){
				menor = h;
			}
		}
		return menor;
	}
}
