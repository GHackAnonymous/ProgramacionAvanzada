package edu.mondragon.progavanzada.horas;

import java.util.Scanner;

public class Principal {
	
	ListaHoras lista;
	Scanner teclado;
	
	public Principal (){
		lista = new ListaHoras();
		teclado = new Scanner(System.in);
	}
	public Hora leerHora(){
		int hora, minutos;
		System.out.print("Hora (hh mm): ");
		hora = teclado.nextInt();
		minutos = teclado.nextInt();
		teclado.nextLine();
		return new Hora(hora,minutos); 
		
	}
	private void mostrarMenor() {
		lista.mostrarHoras();
		Hora h = lista.getMenor();
		System.out.println("la menor es " + h);
		
	}

	private void leerHoras() {
		String opcion;
		do{
			
			lista.add(this.leerHora());
			System.out.println("Mas (s/n)?: ");
			opcion = teclado.nextLine();
		}while (opcion.toLowerCase().equals("s"));
		
	}
	public static void main(String[] args) {
		Principal ejercicio = new Principal();
		ejercicio.leerHoras();
		ejercicio.mostrarMenor();

	}

	

}
