package coleccionobject;

public class Principal {
	final int LIMITE = 10;

	Pila pilaEnteros;
	Pila pilaPalabras;
	Pila pilaAlumnos;
	
	public Principal(){
		pilaEnteros = new Pila();
		pilaPalabras = new Pila();
		pilaAlumnos = new Pila();
	}
	public void inicializarEnteros(){
		for (int i = 0; i< LIMITE; i++){
			pilaEnteros.put(i);
		}
	}
	public void inicializarPalabras(){
		pilaPalabras.put("En");
		pilaPalabras.put("un");
		pilaPalabras.put("lugar");
		pilaPalabras.put("de");
		pilaPalabras.put("la");
		pilaPalabras.put("mancha");
		pilaPalabras.put("de");
		pilaPalabras.put("cuyo");
		
	}
	public void inicializarAlumnos(){
		pilaAlumnos.put((Object) new Alumno (1,"Txema","Perez"));
		pilaAlumnos.put((Object)new Alumno (2,"Miren","Illarramendi"));
		pilaAlumnos.put((Object)new Alumno (3,"Xabi","Elkoro"));
		
	}
	public void verEnteros (){
		while (!pilaEnteros.vacia()){
			System.out.println(pilaEnteros.get());
		}
	}
	public void verPalabras(){
		while (!pilaPalabras.vacia()){
			System.out.println(pilaPalabras.get());
		}
	}
	public void verAlumnos(){
		while (!pilaAlumnos.vacia()){
			System.out.println(pilaAlumnos.get());
		}
	}
	public static void main(String[] args) {
		Principal programa = new Principal();
		programa.inicializarEnteros();
		programa.verEnteros();
		programa.inicializarPalabras();
		programa.verPalabras();
		programa.inicializarAlumnos();
		programa.verAlumnos();

	}

}
