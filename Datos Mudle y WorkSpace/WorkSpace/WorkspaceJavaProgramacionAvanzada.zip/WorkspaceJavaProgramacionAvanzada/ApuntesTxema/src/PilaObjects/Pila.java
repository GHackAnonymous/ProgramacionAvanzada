package coleccionobject;

import coleccion.Alumno;
import coleccion.NodoAlumno;

public class Pila {
	Nodo head;
	
	public Pila(){
		head = null;
	}
	public void put (Object valor){
		Nodo nodo = new Nodo();
		nodo.setValor(valor);
		nodo.setSiguiente(head);
		head = nodo;
	}
	public Object get (){
		Object valor = head.getValor();
		head = head.getSiguiente();
		return valor;
	}
	public boolean vacia(){
		return head==null;
	}

}
