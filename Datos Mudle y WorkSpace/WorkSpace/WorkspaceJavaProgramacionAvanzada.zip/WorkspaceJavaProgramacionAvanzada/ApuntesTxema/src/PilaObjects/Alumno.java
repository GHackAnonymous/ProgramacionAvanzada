package coleccionobject;

public class Alumno {
	int idal;
	String nombre;
	String apellido;
	double nota;
	
	

	public Alumno(int idal, String nombre, String apellido){
		this.idal = idal;
		this.nombre = nombre;
		this.apellido = apellido;
		this.nota = 0.0;
		
		
	}
	@Override
	public String toString() {
		return "Idal: "+ this.idal +"\n" +
		        "Nombre: " + this.nombre+" "+ this.apellido+"\n"+
				"Nota: " + this.nota;
	}
	public double getNota() {
		return nota;
	}

	public void setNota(double nota) {
		this.nota = nota;
	}

	public int getIdal() {
		return idal;
	}

	public String getNombre() {
		return nombre;
	}

	public String getApellido() {
		return apellido;
	}
	
}
