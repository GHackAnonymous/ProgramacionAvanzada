package cuentaclicks;

import java.util.Observable;

public class Modelo extends Observable{
	

	int contador;
	
	public Modelo(){
		contador = 0;
	}
	public int getContador() {
		return contador;
	}
	public void incrementar(){
		contador++;
		this.setChanged();
		this.notifyObservers();
	}
	public void decrementar(){
		contador--;
		this.setChanged();
		this.notifyObservers();
	}
}
