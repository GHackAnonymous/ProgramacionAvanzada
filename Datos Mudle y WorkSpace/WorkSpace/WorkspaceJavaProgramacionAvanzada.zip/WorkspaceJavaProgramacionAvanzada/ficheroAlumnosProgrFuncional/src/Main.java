

import java.io.BufferedReader;
import java.io.EOFException;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.stream.DoubleStream;


public class Main {
	static List<Alumno> lista = new ArrayList<>();
	//static List<Alumno> listaA;

	public static void main(String[] args) {
		// Map<String,List<Alumno>> indice = new HashMap<>();

		mostrarDatosFichero("fichero/Alumnos.txt");
		
		/*double media = 0.0;
		int cuantos = 0;
		
		for (Alumno a: lista){
			listaA = new ArrayList<>();
			String poblacion = a.getPoblacion();
			for (Alumno e: lista){
				if(e.getPoblacion().equalsIgnoreCase(poblacion)){
					listaA.add(e);
				}
			}
			indice.put(poblacion, listaA);
			listaA =  null;
		}*/


		
		Map<String,Double> indice = new HashMap<>();
		indice.put(lista.stream().map(alumno -> alumno.getPoblacion()),
				lista.stream().mapToDouble(alumno -> Double.parseDouble(alumno.getNota())*lista.stream().filter(alumno2 -> alumno2.getPoblacion().equalsIgnoreCase(alumno.getPoblacion())).count())); 
		
		
		
		
		/*
		Set<Entry<String,List<Alumno>>> pares = indice.entrySet();
		for (Entry<String,List<Alumno>> par : pares){
			System.out.print(par.getKey()+"-> ");
			
			List<Alumno> listaAA = par.getValue();
			for (Alumno e: listaAA){
				media += Double.parseDouble(e.getNota());
				cuantos++;
			}
			double result = media / cuantos;
			System.out.println(result);
			for (Alumno e: listaAA){
				System.out.println(e);
			}
			
		}*/
		
	}
	/*public void getAlumno(Alumno a){
		listaA.add(a);
	}*/
	
	public static void mostrarDatosFichero(String nombreFichero){
		BufferedReader in  = null;
		try {
			in = new BufferedReader(new FileReader(nombreFichero));
			String s;
			while ((s = in.readLine())!=null){
				String[] linea = s.split("[$]");
				lista.add(new Alumno(linea[0], linea[1], linea[2], linea[3], linea[4], linea[5]));
			}
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}catch (EOFException e){
			
		}catch (IOException e) {
			e.printStackTrace();
		}finally{
			if (in!= null){
				try { in.close(); } catch (IOException e) {}
			}
		}
	}
}
