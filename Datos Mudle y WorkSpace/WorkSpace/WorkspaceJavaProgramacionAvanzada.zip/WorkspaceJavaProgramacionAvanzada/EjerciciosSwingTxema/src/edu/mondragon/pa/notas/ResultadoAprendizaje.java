package edu.mondragon.pa.notas;

public class ResultadoAprendizaje {
	

	String codigo;
	String texto;
	float nota;
	
	public ResultadoAprendizaje (String codigo, String texto){
		this.codigo = codigo;
		this.texto = texto;
		this.nota = 0.0f;
	}

	public float getNota() {
		return nota;
	}

	public void setNota(float nota) {
		this.nota = nota;
	}

	public String getCodigo() {
		return codigo;
	}

	public String getTexto() {
		return texto;
	}
	@Override
	public String toString() {
		
		return codigo+":   "+nota;
	}
}
