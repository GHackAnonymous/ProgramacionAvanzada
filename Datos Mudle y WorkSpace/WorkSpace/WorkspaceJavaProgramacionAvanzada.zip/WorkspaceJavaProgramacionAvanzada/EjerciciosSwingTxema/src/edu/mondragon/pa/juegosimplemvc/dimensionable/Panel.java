package edu.mondragon.pa.juegosimplemvc.dimensionable;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;

import javax.swing.JPanel;

public class Panel extends JPanel {
	
 	private final static int ANCHO = 512;

    private final static int ALTO = 384;

    Pelota pelota;
   
    
    public Panel(Pelota pelota){
    	 super();
    	 
    	 //setPreferredSize(new Dimension(ANCHO, ALTO));
    	 this.pelota = pelota;
    	 // pelota.setLimites(ANCHO,ALTO);
    	 pelota.setLimites(this.getWidth(), this.getHeight());
    }
    
    public void paint(Graphics g) {
    	Graphics2D gr = (Graphics2D) g;
        gr.setColor(Color.WHITE);
        gr.fillRect(0, 0, this.getWidth(), this.getHeight());
        pelota.dibujar(g);
    }
	public void setNewDimension() {
		pelota.setLimites(this.getWidth(), this.getHeight());
		
	}

}
