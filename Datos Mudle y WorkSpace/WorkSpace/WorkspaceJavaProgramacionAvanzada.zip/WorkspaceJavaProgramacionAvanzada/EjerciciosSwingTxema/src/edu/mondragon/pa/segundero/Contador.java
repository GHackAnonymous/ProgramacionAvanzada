package edu.mondragon.pa.segundero;

import java.util.Observable;

public class Contador extends Observable{
	int contador;
	
	public Contador(){
		contador = 0;
	}
	public int getContador(){
		return contador;
	}
	public void incrementar (){
		contador++;
		this.setChanged();
		this.notifyObservers();
	}
	public void reiniciar() {
		contador = 0;
	}
}
