package edu.mondragon.pa.segundero;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Container;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.util.Observable;
import java.util.Observer;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.Timer;
import javax.swing.UIManager;

import edu.mondragon.pa.segundero.Segundero.MiTarea;


	
public class SegunderoBueno implements ActionListener, Observer{
		JFrame ventana;
		JLabel lValor;
		JButton bStart, bStop;
		Contador contador;
		Timer timer= null;
		MiTarea miTarea;
		boolean fin= false;
		
		public SegunderoBueno(){
			ventana = new JFrame ("Segundero");
			contador = new Contador();
			contador.addObserver(this);
			ventana.setSize (300,400);
			ventana.setLocation (100,100);
			ventana.setContentPane (crearPanelVentana());
			ventana.setVisible (true);
			timer = new Timer (1000,this);
			timer.setActionCommand("timer");
			ventana.addWindowListener(new WindowAdapter(){

				@Override
				public void windowClosing(WindowEvent arg0) {
					timer.stop();
					System.exit(0);
				}
				
			});
			
			
		}
		
		private Container crearPanelVentana() {
			JPanel panel = new JPanel (new BorderLayout());
			panel.setBorder(BorderFactory.createEmptyBorder(20,10,20,10));
			
			lValor = new JLabel (String.valueOf(contador.getContador()));
			lValor.setFont ( new Font("arial",Font.BOLD,67));
			lValor.setForeground(Color.red);
			lValor.setHorizontalAlignment(JLabel.CENTER);
			
			panel.add (lValor, BorderLayout.CENTER);
			panel.add (crearPanelBotones(),BorderLayout.SOUTH);
			return panel;
		}

		private Component crearPanelBotones() {
			JPanel panel = new JPanel (new GridLayout(1,2,20,0));
			panel.setBorder(BorderFactory.createEmptyBorder(0,10,0,10));
			
			bStart = new JButton ("Start");
			bStart.addActionListener(this);
			bStart.setActionCommand("start");
			
			bStop = new JButton ("Stop");
			bStop.addActionListener(this);
			bStop.setActionCommand("stop");
			
			panel.add(bStart);
			panel.add(bStop);
			
			return panel;
		}

		@Override
		public void actionPerformed(ActionEvent e) {
			
			if (e.getSource()==bStart){
				
				if (!timer.isRunning()){
					timer.restart(); 
					
				}else{
					JOptionPane.showMessageDialog(ventana, "El cronometro ya esta activo",
							"Error Activar",JOptionPane.ERROR_MESSAGE);
				}
				
			}
			if (e.getActionCommand().equals("stop")){
		
				if (timer.isRunning()){
					timer.stop();
				}else{
					JOptionPane.showMessageDialog(ventana, "El cronometro no esta activo",
							"Error Parar",JOptionPane.ERROR_MESSAGE);
				}
			}
			if (e.getActionCommand().equals("timer")){
				contador.incrementar();
			}
			
		}


		public static void main(String[] args) {
			
			try {
				UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
			} catch (Exception e) {
				
				e.printStackTrace();
			} 
			
			SegunderoBueno ejercicio = new SegunderoBueno();
		}

		@Override
		public void update(Observable arg0, Object arg1) {
			
			lValor.setText(String.valueOf(contador.getContador()));
		}
	
}
