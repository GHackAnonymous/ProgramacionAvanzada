package edu.mondragon.pa.puzzle;

import java.awt.Container;
import java.awt.GridLayout;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Random;

import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;

public class Puzzle extends JFrame implements ActionListener{
	
	final int LINEAS = 4;
	final int COLUMNAS = 3;
	final int NUMPIEZAS = 12;
	int huecoX,huecoY;
	int piezas[][]; 
	JPanel panel; 
	public Puzzle(){
		super ("Puzzle tigre");
		this.setLocation(100,100);
		this.setSize(420,300);
		piezas = new int [LINEAS] [COLUMNAS];
		colocarPiezas();
		
		this.setContentPane(crearPanelVentana());
		
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setVisible(true);
	}
	private void colocarPiezas() {
		Random generador = new Random();
		for (int i = 0; i < LINEAS; i++){
			for (int j = 0; j < COLUMNAS; ){
				int pieza = generador.nextInt(11)+1;
				if (!incluida(pieza)){
					piezas[i][j]= pieza;
					j++;
				}
				if (i==LINEAS-1&& j==COLUMNAS-1){
					piezas[i][j]=0;
					huecoX = i;
					huecoY = j;
					return;
				}
			}
		}
	}
	private boolean incluida(int pieza) {
		for (int i = 0; i < LINEAS; i++){
			for (int j = 0; j < COLUMNAS; j++){
				if (piezas[i][j]== pieza){
					return true;
				}
			}
		}
		return false;
	}
	private Container crearPanelVentana() {
		panel = new JPanel (new GridLayout (LINEAS,COLUMNAS,5,5));
		JButton boton;
		for (int i = 0; i < LINEAS; i++){
			for (int j = 0; j < COLUMNAS; j++){
				String nombre = "tigre"+piezas[i][j]+".png";
				ImageIcon imagen = new ImageIcon ("imagenes/"+nombre);
				boton = new JButton(imagen);
				boton.addActionListener(this);
				boton.setActionCommand(i+" "+j);
				panel.add(boton );
			}
		}
		return panel;
	}
	public static void main(String[] args) {
		Puzzle ejercicio = new Puzzle();

	}
	@Override
	public void actionPerformed(ActionEvent e) {
		int mov;
		String comando = e.getActionCommand();
		int i = Integer.valueOf(comando.substring(0, comando.indexOf(' '))).intValue();
		int j = Integer.valueOf(comando.substring(comando.indexOf(' ')+1)).intValue();
		if ((mov = valido(i,j))!=0){
			JButton boton =(JButton)e.getSource(); 
			Icon imagen = boton.getIcon();
			
			((JButton)panel.getComponent(huecoX * COLUMNAS + huecoY)).setIcon(imagen);
			boton.setIcon(null);
			huecoX= i;
			huecoY = j;
		}else{
			Toolkit.getDefaultToolkit().beep();
		}
		
	}
	private int valido(int i, int j) {
		
		if (((i-1)==huecoX)&&(j == huecoY)) return 1;
		
		if ((i== huecoX)&&((j-1)==huecoY)) return 2;
		
		if (((i+1)==huecoX) && (j==huecoY))  return 3;
		
		if ((i== huecoX) && ((j+1)== huecoY)) return 4;
		
		return 0;
	}

}
