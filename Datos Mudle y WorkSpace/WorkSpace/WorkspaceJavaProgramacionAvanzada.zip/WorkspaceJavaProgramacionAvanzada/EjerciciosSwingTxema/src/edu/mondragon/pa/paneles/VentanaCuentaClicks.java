package edu.mondragon.pa.paneles;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Container;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JInternalFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;


public class VentanaCuentaClicks extends JInternalFrame implements ActionListener{
     int xOffset,yOffset; 
    
 	JLabel lValor;
 	JButton bInc, bDec;
 	int contador;
     public VentanaCuentaClicks(int x, int y) {
    	 
    	super("Cuenta Clicks" ,
    			false, //resizable
    			false, //closable
    			false, //maximizable
    			false);//iconifiable
    	        
    	setSize(300,300);           
    	this.xOffset = x;
    	this.yOffset = y;
    	setLocation(xOffset, yOffset);
    	setFrameIcon (new ImageIcon("iconos/ic_clicks.png"));
    	this.setContentPane(crearPanelVentana());
    }
     
 	private Container crearPanelVentana() {
		JPanel panel = new JPanel (new BorderLayout());
		panel.setBorder(BorderFactory.createEmptyBorder(20,10,20,10));
		
		lValor = new JLabel (String.valueOf(contador));
		lValor.setFont ( new Font("arial",Font.BOLD,67));
		lValor.setForeground(Color.red);
		lValor.setHorizontalAlignment(JLabel.CENTER);
		
		panel.add (lValor, BorderLayout.CENTER);
		panel.add (crearPanelBotones(),BorderLayout.SOUTH);
		return panel;
	}

	private Component crearPanelBotones() {
		JPanel panel = new JPanel (new GridLayout(1,2,20,0));
		panel.setBorder(BorderFactory.createEmptyBorder(0,10,0,10));
		
		bInc = new JButton ("Incrementar");
		bInc.addActionListener(this);
		bInc.setActionCommand("inc");
		
		bDec = new JButton ("Decrementar");
		bDec.addActionListener(this);
		bDec.setActionCommand("dec");
		
		panel.add(bInc);
		panel.add(bDec);
		
		return panel;
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		
		if (e.getSource()==bInc){
			lValor.setText(String.valueOf(++contador));
		}
		if (e.getActionCommand().equals("dec")){
			lValor.setText(String.valueOf(--contador));
		}
	}

}
