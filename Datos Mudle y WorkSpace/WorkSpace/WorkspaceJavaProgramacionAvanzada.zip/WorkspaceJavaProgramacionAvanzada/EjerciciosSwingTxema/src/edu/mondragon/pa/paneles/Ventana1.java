package edu.mondragon.pa.paneles;

import java.awt.GridLayout;
import java.awt.Image;
import java.awt.Toolkit;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;


public class Ventana1 extends JFrame{
	
	public Ventana1 (){
		int anchoPantalla, altoPantalla;
		Image fondo;
		Toolkit toolkit = Toolkit.getDefaultToolkit();
		
		this.setLocation (0,0);
		
		this.setUndecorated(true);
		
		fondo = toolkit.createImage("iconos/fondo.jpeg");
		
		//anchoPantalla = (int)Toolkit.getDefaultToolkit().getScreenSize().getWidth();
		//altoPantalla = (int)Toolkit.getDefaultToolkit().getScreenSize().getHeight();
		//anchoPantalla = GraphicsEnvironment.getLocalGraphicsEnvironment().getDefaultScreenDevice().getDisplayMode().getWidth();
		//altoPantalla = GraphicsEnvironment.getLocalGraphicsEnvironment().getDefaultScreenDevice().getDisplayMode().getHeight();
		//anchoPantalla = 600;
		//altoPantalla = 400;
		//this.setSize(anchoPantalla,altoPantalla);
		this.setExtendedState(JFrame.MAXIMIZED_BOTH);
		this.getContentPane().add(new JLabel(new ImageIcon(fondo)));
		this.setIconImage(new ImageIcon("iconos/logo.png").getImage());
		this.setTitle("Buscando a nemo");
		this.setVisible(true);
		
		this.setDefaultCloseOperation (JFrame.EXIT_ON_CLOSE);
	}
	public static void main(String[] args) {
		Ventana1 ventana = new Ventana1();

	}

}
