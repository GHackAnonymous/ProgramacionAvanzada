package edu.mondragon.pa.figuras;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;

import javax.swing.BorderFactory;
import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JTextField;


public class DialogoFigura extends JDialog implements ItemListener,ActionListener{
	
	
	private static final long serialVersionUID = 1L;
	Figura figura = null;
	JRadioButton rbCirculo,rbRectangulo;
	ButtonGroup grupo;
	JPanel panelDescripcion,panelPosX, panelPosY,panel1,panel2;
	JLabel lbDescripcion,lbPosX,lbPosY,lbDato1,lbDato2;
	JTextField txDescripcion,txPosX,txPosY,txDato1,txDato2;
	JButton bOK,bCancel;
	Dimension dimensionBoton;
	
	public DialogoFigura(JFrame ventana) {
		super (ventana, "Definici�n de figura",true);
		dimensionBoton = new Dimension(100,30);
		
		this.setSize(460,460);
		this.setLocation(260,180);
		this.setContentPane(crearPanelVentana());
		this.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
		this.setVisible(true);
	}

	private Container crearPanelVentana() {
		JPanel panel = new JPanel(new BorderLayout(0,10));
		panel.setBorder(BorderFactory.createEmptyBorder(20,10,20,10));
		
		panel.add(crearPanelDatos(),BorderLayout.CENTER);
		panel.add(crearPanelBotones(),BorderLayout.SOUTH);
		panel.add(crearPanelButtonGroup(), BorderLayout.NORTH);
		
		return panel;
	}

	private Component crearPanelButtonGroup() {
		JPanel panel = new JPanel();
		panel.setBackground (Color.WHITE);
		grupo = new ButtonGroup();
		rbCirculo = new JRadioButton("Circulo");
		rbCirculo.addItemListener(this);
		
		rbCirculo.setBackground(Color.WHITE);
		panel.add(rbCirculo);
		grupo.add(rbCirculo);
		
		rbRectangulo = new JRadioButton("Rect�ngulo");
		rbRectangulo.addItemListener(this);
		rbRectangulo.setBackground(Color.WHITE);
		panel.add(rbRectangulo);
		grupo.add(rbRectangulo);
		
		rbCirculo.setSelected(true);
		return panel;
	}

	private Component crearPanelDatos() {
		JPanel panel = new JPanel(new GridLayout(5,1,0,25));
		
		
		panel.add(crearPanelDescripcion());
		panel.add(crearPanelPosX());
		panel.add(crearPanelPosY());
		panel.add(crearPanelDatos1());
		panel.add(crearPanelDatos2());
		
		panel.setBorder(BorderFactory.createCompoundBorder(
				BorderFactory.createTitledBorder(BorderFactory.createLineBorder(Color.BLACK),
						"Panel datos"),
				BorderFactory.createEmptyBorder(20, 20, 20, 20)));
		lbDato1.setText("Radio: ");
		panel1.setVisible(true);
		panel2.setVisible(false);
		return panel;
	}

	private JPanel crearPanelPosY() {
		panelPosY = new JPanel(new GridLayout(1,2,20,25));
		lbPosY= new JLabel("Posicion Y: ");
		txPosY = new JTextField (10);
		txDescripcion.setBorder(BorderFactory.createLoweredBevelBorder());
		panelPosY.add(lbPosY);
		panelPosY.add(txPosY);
		return panelPosY;
	}

	private JPanel crearPanelPosX() {
		panelPosX = new JPanel(new GridLayout(1,2,20,25));
		lbPosX= new JLabel("Posicion X: ");
		txPosX = new JTextField (10);
		txDescripcion.setBorder(BorderFactory.createLoweredBevelBorder());
		panelPosX.add(lbPosX);
		panelPosX.add(txPosX);
		return panelPosX;
	}

	private JPanel crearPanelDescripcion() {
		panelDescripcion = new JPanel(new GridLayout(1,2,20,25));
		lbDescripcion= new JLabel("Descripcion: ");
		txDescripcion = new JTextField (10);
		txDescripcion.setBorder(BorderFactory.createLoweredBevelBorder());
		panelDescripcion.add(lbDescripcion);
		panelDescripcion.add(txDescripcion);
		return panelDescripcion;
	}

	private JPanel crearPanelDatos1() {
		panel1 = new JPanel(new GridLayout(1,2,20,25));
		
		lbDato1= new JLabel();
		txDato1 = new JTextField (10);
		txDato1.setBorder(BorderFactory.createLoweredBevelBorder());
		panel1.add(lbDato1);
		panel1.add(txDato1);
		return panel1;
	}
	private JPanel crearPanelDatos2() {
		panel2 = new JPanel(new GridLayout(1,2,20,25));
		lbDato2= new JLabel();
		txDato2 = new JTextField (10);
		txDato2.setBorder(BorderFactory.createLoweredBevelBorder());
		panel2.add(lbDato2);
		panel2.add(txDato2);
		return panel2;
	}

	private Component crearPanelBotones() {
		JPanel panel = new JPanel();
		
		panel.setLayout(new FlowLayout(FlowLayout.CENTER,30,0));
		panel.setAlignmentX(0.f);
		bOK = new JButton ("  Ok  ");
		bOK.addActionListener(this);
		bOK.setPreferredSize(dimensionBoton);
		bOK.setMinimumSize(dimensionBoton);
		bOK.setMaximumSize(dimensionBoton);
		bCancel = new JButton ("Cancel");
		bCancel.addActionListener(this);
		bCancel.setPreferredSize(dimensionBoton);
		bCancel.setMinimumSize(dimensionBoton);
		bCancel.setMaximumSize(dimensionBoton);
		
		panel.add(bOK);
		//panel.add(Box.createRigidArea(new Dimension (20,0)));
		panel.add(bCancel);
		return panel;
	}

	public Figura getFigura() {
		
		return figura ;
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		String descripcion;
		int posX, posY;
		int valor1, valor2;
		if (e.getSource()==bOK){
			descripcion = txDescripcion.getText();
			posX = Integer.parseInt(txPosX.getText());
			posY = Integer.parseInt(txPosY.getText());
			if(rbCirculo.isSelected()){
				
				valor1 = Integer.parseInt(txDato1.getText());
				figura = new Circulo(descripcion,posX,posY,valor1);
			}
			if(rbRectangulo.isSelected()){
				
				valor1 = Integer.parseInt(txDato1.getText());
				valor2 = Integer.parseInt(txDato2.getText());
				figura = new Rectangulo(descripcion,posX,posY,valor1,valor2);
			}
			
			
		}
		if (e.getSource()==bCancel){
			
			figura = null;
		}
		this.dispose();
		
	}

	@Override
	public void itemStateChanged(ItemEvent arg0) {
		
		if(rbCirculo.isSelected()){
			lbDato1.setText("Radio: ");
			panel2.setVisible(false);
			
		}
		if(rbRectangulo.isSelected()){
			lbDato1.setText("Lado 1: ");
			lbDato2.setText("Lado 2: ");
			panel2.setVisible(true);
		}
		
	}

	

}
