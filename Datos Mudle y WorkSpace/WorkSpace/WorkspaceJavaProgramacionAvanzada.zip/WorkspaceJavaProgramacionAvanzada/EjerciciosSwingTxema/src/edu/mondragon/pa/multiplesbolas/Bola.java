package edu.mondragon.pa.multiplesbolas;

import java.awt.Color;
import java.awt.Graphics;



public class Bola extends Figura {
	
	final int DIAMETRO = 20;
	
	public Bola (float x, float y, float vx, float vy){
		super (x,y,vx,vy);
		forma = Forma.CIRCULO;
		color = Color.blue;
	}

	@Override
	public void detectarColisionConMarco(int ancho, int alto) {
		if (vx < 0 && x <= 0 || vx > 0 && x + DIAMETRO >= ancho)
            vx = -vx;
        if (vy < 0 && y < 0 || vy > 0 && y + DIAMETRO >= alto)
            vy = -vy;
	}

	@Override
	public boolean detectarColision(Figura figura) {
		boolean colision = false;
		float limX, limY;
		limX= figura.getLimX();
		limY = figura.getLimY();
		if (((x>figura.x && x<limX)||((x+DIAMETRO)>figura.x && (x+DIAMETRO)<limX)) &&
			((y>figura.y && y<limY)||((y+DIAMETRO)>figura.y && (y+DIAMETRO)<limY))){
			
			colision = true;
		}
		return colision;	
	}

	@Override
	public float getLimX() {
		
		return x+DIAMETRO;
	}

	@Override
	public float getLimY() {
		
		return y+DIAMETRO;
	}

	@Override
	public void paint(Graphics g) {
		g.setColor(color);
		g.fillOval((int)x, (int) y, DIAMETRO, DIAMETRO);
		
	}

	@Override
	public void inc(int i) {
		// TODO Auto-generated method stub
		
	}
}
