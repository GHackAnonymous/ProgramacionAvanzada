package edu.mondragon.pa.juegosimpleboton;

import java.util.ArrayList;
import java.util.List;
import java.util.Observable;

public class ElementosMoviles extends Observable{
	List<Movil> lista;
	
	public ElementosMoviles(){
		lista = new ArrayList<>();
	}
	
	public void add(Movil v){
		lista.add(v);
	}
	public void mover (float dt){
		for (Movil m : lista){
			m.mover(dt);
		}
		this.setChanged();
		this.notifyObservers();
	}
}
