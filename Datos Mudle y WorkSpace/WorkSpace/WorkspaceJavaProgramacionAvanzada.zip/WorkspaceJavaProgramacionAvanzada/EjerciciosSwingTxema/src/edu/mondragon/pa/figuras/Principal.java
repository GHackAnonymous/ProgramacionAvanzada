package edu.mondragon.pa.figuras;

import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.Container;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.KeyEvent;

import javax.swing.AbstractAction;
import javax.swing.Action;
import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JSplitPane;
import javax.swing.JTextField;
import javax.swing.JToolBar;

public class Principal extends JFrame implements Observer{
	
	private static final long serialVersionUID = 1L;
	JList<Figura> lista;
	ListaFiguras modelo;
	MiAccion a�adir, borrar, salir;
	JTextField txTotal;
	
	public Principal(){
		super("Lista figuras");
		modelo = new ListaFiguras();
		modelo.addObserver(this);
		this.setLocation (240,100);
		this.setSize(680,460);
		this.crearAcciones();
		this.setJMenuBar(crearMenu());
		this.setContentPane(crearPanelVentana());
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setVisible(true);
	}
	private void crearAcciones() {
		a�adir = new MiAccion ("A�adir",new ImageIcon("iconos/edit_add.png"),"a�ade una nueva figura",
				new Integer(KeyEvent.VK_A));
		borrar = new MiAccion ("Borrar",new ImageIcon("iconos/edit_remove.png"),"borra la figura seleccionada",
				new Integer(KeyEvent.VK_B));
		salir = new MiAccion ("Salir",new ImageIcon("iconos/exit.png"),"Cierra la aplicacion",
				new Integer(KeyEvent.VK_S));
	}
	private Container crearPanelVentana() {
		JSplitPane panel = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT,true,crearPanelLista(),crearPanelDibujo());
		
		return panel;
	}
	private Component crearPanelDibujo() {
		MiPanel panel = new MiPanel(modelo);
		return panel;
	}
	private Component crearPanelLista() {
		JPanel panel = new JPanel (new BorderLayout(0,10));
		panel.add(panelBarraBotones(), BorderLayout.NORTH);
		panel.add(panelLista(),BorderLayout.CENTER);
		panel.add(panelTotal(),BorderLayout.SOUTH);
		return panel;
	}
	private Component panelBarraBotones() {
		JToolBar toolBar = new JToolBar();
		
		JButton boton;
		boton =(JButton) toolBar.add(a�adir);
		boton =(JButton) toolBar.add(borrar);
		toolBar.add(Box.createHorizontalGlue());
		boton =(JButton) toolBar.add(salir);
		return toolBar;
	}
	private Component panelLista() {
		JScrollPane panel = new JScrollPane(JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED,JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
		lista = new JList<Figura>();
		
		lista.setModel(modelo);
		panel.setViewportView(lista);
		return panel;
	}
	private Component panelTotal() {
		JPanel panel = new JPanel(new FlowLayout(FlowLayout.CENTER));
		JLabel lTotal = new JLabel ("Superficie Total");
		txTotal = new JTextField (10);
		txTotal.setBorder(BorderFactory.createLoweredBevelBorder());
		panel.add(lTotal);
		panel.add(txTotal);
		return panel;
	}
	private JMenuBar crearMenu() {
		JMenuBar barra = new JMenuBar();
		barra.add (crearMenuEditar());
		
		barra.add (crearMenuSalir());
		
		return barra;
	}
	private JMenu crearMenuEditar() {
		JMenu menuEditar = new JMenu ("Editar");
		menuEditar.setMnemonic(new Integer(KeyEvent.VK_E));
		JMenuItem opcionMenu = new JMenuItem (a�adir);
		menuEditar.add(opcionMenu);
		opcionMenu = new JMenuItem (borrar);
		menuEditar.add(opcionMenu);
		
		return menuEditar;
	}
	private JMenu crearMenuSalir() {
		JMenuItem op;
		JMenu menuSalir = new JMenu ("Salir");
		menuSalir.setMnemonic(new Integer(KeyEvent.VK_S));
		op=menuSalir.add(salir);
		
		
		return menuSalir;
	}
	private class MiAccion extends AbstractAction {
		String texto;
		public MiAccion (String texto, Icon imagen, String descrip, Integer nemonic){
			super(texto,imagen);
			this.texto = texto;
			this.putValue( Action.SHORT_DESCRIPTION ,descrip);
			this.putValue(Action.MNEMONIC_KEY, nemonic);
		}

		@Override
		public void actionPerformed(ActionEvent e) {
			
			if (texto.equals("A�adir")){
				DialogoFigura dialogo = new DialogoFigura (Principal.this);
				Figura figura = dialogo.getFigura();
				if (figura!=null){
					modelo.addElement(figura);
				}
				
			}
			if (texto.equals("Borrar")){
				int indice;
				if ((indice = Principal.this.lista.getSelectedIndex())==-1){
					JOptionPane.showMessageDialog(Principal.this, "Debe seleccionar una figura de la lista",
							"Error de seleccion",JOptionPane.ERROR_MESSAGE);
				}else{
					modelo.remove(indice);
				}
			}
			if (texto.equals("Salir")){
				Principal.this.dispose();
			}
		}

		
	}
	private void ajustarTotal() {
		double total = 0;
		
		for (int i = 0; i<modelo.getSize(); i++){
			total +=((Figura) modelo.getElementAt(i)).calcularSuperficie();
		}
		txTotal.setText(String.format("%.2f",total));
	}
	public static void main(String[] args) {
		Principal ejercicio = new Principal();

	}
	
	@Override
	public void update(Observable ob) {
		this.ajustarTotal();
		this.repaint();
	}
	
	
}
