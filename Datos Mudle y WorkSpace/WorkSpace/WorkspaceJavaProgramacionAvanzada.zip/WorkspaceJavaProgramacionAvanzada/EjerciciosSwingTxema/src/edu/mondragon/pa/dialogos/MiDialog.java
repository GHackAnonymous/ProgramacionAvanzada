package edu.mondragon.pa.dialogos;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Container;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;


public class MiDialog extends JDialog implements WindowListener {
	JTextField text;
	String valor;
	JLabel lMensaje;
	String msgError = "debes introducir un valor o cancelar";
	
	public MiDialog (JFrame ventana,String titulo, boolean modo,String valor) {
		super(ventana,titulo,modo);
		
		this.valor = valor;
		
		this.setSize(320,240);
		this.setLocation (100,100);
		this.setContentPane(crearPanelDialogo());
		this.setDefaultCloseOperation(JDialog.DO_NOTHING_ON_CLOSE);
		this.addWindowListener(this);  //son equivalentes
		/*
		this.addWindowListener(new WindowAdapter(){
			@Override
			public void windowClosing(WindowEvent e) {
				System.out.println("Cerrando... ");
				String texto =  text.getText();
				if ((texto.length()!=0 && !texto.equals(MiDialog.this.valor))){
					//MiDialog.this.setDefaultCloseOperation(JDialog.EXIT_ON_CLOSE);
					MiDialog.this.valor = texto;
					MiDialog.this.dispose();
				}else{
					lMensaje.setText(msgError);
					
				}
			
			}
		});
		*/
		this.setVisible(true);
		
	}

	private Container crearPanelDialogo() {
		JPanel panel = new JPanel (new BorderLayout(0,20));
		panel.setBorder(BorderFactory.createEmptyBorder(20,20,20,20));
		panel.add(crearPanelCentral(), BorderLayout.CENTER);
		panel.add(crearPanelMensajes(),BorderLayout.SOUTH);
		return panel;
	}

	private Component crearPanelMensajes() {
		JPanel panel = new JPanel (new GridLayout(1,1));
		lMensaje = new JLabel("  ");
		lMensaje.setBorder(BorderFactory.createLoweredBevelBorder());
		panel.add(lMensaje);
		return panel;
	}

	private Container crearPanelCentral() {
		JPanel panel = new JPanel (new BorderLayout(0,20));
		panel.setBorder(BorderFactory.createEmptyBorder(0,20,0,20));
		panel.add(crearPanelTexto(), BorderLayout.CENTER);
		panel.add(crearPanelBotones(),BorderLayout.SOUTH);
		return panel;
	}

	private Component crearPanelBotones() {
		JPanel panel = new JPanel(new GridLayout(1,2,20,0));
		panel.setBorder(BorderFactory.createEmptyBorder(20, 10, 10, 10));
		JButton boton1 = new JButton ("OK");
		
	
		boton1.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent arg0) {
				String texto =  text.getText();
				if (texto.length()!=0&& !texto.equals(valor)){
					MiDialog.this.valor = texto;
					MiDialog.this.dispose();
					
				}else{
					lMensaje.setText(msgError);
				}
				
				
			}
		});
	
		JButton boton2 = new JButton ("Cancel");
		boton2.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent arg0) {
				MiDialog.this.dispose();
			}
		});
		panel.add(boton1);
		panel.add(boton2);
		return panel;
	}

	
	private Component crearPanelTexto() {
		JPanel panel = new JPanel (new GridLayout(1,1));
		panel.setBorder(BorderFactory.createCompoundBorder(BorderFactory.createLineBorder(Color.cyan),BorderFactory.createEmptyBorder(10, 10, 10, 10)));
		text = new JTextField (valor);
		panel.add (text);
		return panel;
	}

	String getText(){
		return valor;
	}

	@Override
	public void windowActivated(WindowEvent e) {}

	@Override
	public void windowClosed(WindowEvent e) {}

	@Override
	public void windowClosing(WindowEvent e) {
		System.out.println("Cerrando... ");
		String texto =  text.getText();
		if ((texto.length()!=0 && !texto.equals(valor))){
			this.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
			this.valor = texto;
			this.dispose();
		}else{
			lMensaje.setText(msgError);
			
		}
	
	}

	@Override
	public void windowDeactivated(WindowEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void windowDeiconified(WindowEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void windowIconified(WindowEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void windowOpened(WindowEvent e) {
		// TODO Auto-generated method stub
		
	}
}
