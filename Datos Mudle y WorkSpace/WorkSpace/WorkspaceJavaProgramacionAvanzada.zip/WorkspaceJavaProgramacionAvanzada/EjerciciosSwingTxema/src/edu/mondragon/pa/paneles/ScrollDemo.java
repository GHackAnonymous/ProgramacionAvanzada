package edu.mondragon.pa.paneles;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class ScrollDemo implements ItemListener{
	JFrame ventana;
	JSplitPane pVentana;
	
	JLabel imagen;
	JComboBox<String> opciones;
	
	
	String lista []= {"bisonte","burro","cebra","delfin",
			"gaviota","leon","mono","panda","pinguino","tigre"};
	
	public ScrollDemo(){
		ventana = new JFrame ("Visor Fauna");
		ventana.setSize (800,600);
		ventana.setLocation (100,100);
		
		
		
		pVentana = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, false,
				crearPanelOpciones(),crearPanelImagen());
		
		ventana.setContentPane(pVentana);
		ventana.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		ventana.setVisible (true);
	}
	private JPanel crearPanelOpciones() {
		
		
		JPanel pOpciones = new JPanel (new BorderLayout());
		
		opciones= new JComboBox<>(lista);
		opciones.addItemListener (this);
		
		pOpciones.add(opciones,BorderLayout.NORTH);
		
		return pOpciones;
	}
	private JScrollPane crearPanelImagen() {
		JScrollPane pImagen;
		
		imagen = new JLabel();
		imagen.setHorizontalAlignment(JLabel.CENTER);
		imagen.setIcon (new ImageIcon("iconos/"+opciones.getSelectedItem()+".jpg"));
		
		pImagen =  new JScrollPane( JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED,
				JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
		
		pImagen.setViewportView(imagen);
		
		return pImagen;
	}
	public static void main(String[] args) {
		
		ScrollDemo ejercicio = new ScrollDemo();
	}
	@Override
	public void itemStateChanged(ItemEvent arg0) {
	
		imagen.setIcon (new ImageIcon("iconos/"+opciones.getSelectedItem()+".jpg"));		
		
	}

}
