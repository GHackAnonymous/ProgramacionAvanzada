package edu.mondragon.pa.juegopala;

import java.awt.Color;
import java.awt.Graphics;

public class Pala implements Dibujable,Movil{
	 public final static int ANCHOPALA = 60;
	 private final static int GROSORPALA = 20;
	    
    private final static int POSINIPALAY = 344;
    private final static int POSINIPALAX = 240;
    
   
    private int px,py,incX;

    
    int ancho;
    
    public Pala (int ancho){
    	this.ancho = ancho;
    	incX = 0;
    	this.px= POSINIPALAX;
    	this.py= POSINIPALAY;
    }
    public int getX(){
    	return px;
    }
    public int getY(){
    	return py;
    }
	@Override
	public void mover(float dt) {
	    if (incX<0){
        	px = ((px+incX)<0 )? 0 : px+incX;
        }
        if (incX>0){
        	px = ((px+incX+ANCHOPALA)>ancho)?ancho-ANCHOPALA : px+incX;
        }
	}

	@Override
	public void draw(Graphics g) {
		g.setColor(Color.GREEN);
        g.fillRect(px,py,ANCHOPALA,GROSORPALA);
	}

	public void setIncX(int i) {
		this.incX = i;
		
	}
}
