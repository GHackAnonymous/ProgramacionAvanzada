package edu.mondragon.pa.juegosimpleboton;

import java.awt.Graphics;
import java.util.ArrayList;
import java.util.List;

public class ElementosDibujables {
	List<Dibujable> lista;
	
	public ElementosDibujables(){
		lista = new ArrayList<>();
	}
	
	public void add(Dibujable d){
		lista.add(d);
	}
	public void draw (Graphics g){
		for (Dibujable d : lista){
			d.draw(g);
		}

	}
}
