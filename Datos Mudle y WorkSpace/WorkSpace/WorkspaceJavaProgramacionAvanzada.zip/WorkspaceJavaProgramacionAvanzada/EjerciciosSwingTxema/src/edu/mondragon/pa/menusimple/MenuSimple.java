package edu.mondragon.pa.menusimple;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;

import javax.swing.Box;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;

public class MenuSimple  implements ActionListener{

	JFrame ventana;
	JMenuBar barra;
	JMenu	menuFile, menuEdit, menuSalir;
	JMenuItem opcionMenu;
	JMenu subMenu;
	
	
	public MenuSimple(){
		
		ventana = new JFrame ("Mensajes");
		
		ventana.setJMenuBar(crearBarraMenu());
		ventana.setLocation(200,200);
		ventana.setSize(600,400);
		ventana.setVisible(true);
		ventana.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
	
	
	private JMenuBar crearBarraMenu() {
		barra = new JMenuBar();
		barra.add (crearMenuFile());
		
		barra.add (crearMenuEdit());
		barra.add(Box.createHorizontalGlue());
		barra.add (crearMenuSalir());
		
		return barra;
		
	}

	private JMenu crearMenuSalir() {
		JMenuItem op;
		menuSalir = new JMenu ("Salir");
		
		op=menuSalir.add("Salir");
		op.setIcon(new ImageIcon("iconos/shutdown.png"));
		op.addActionListener(new ActionListener() {
			public void actionPerformed (ActionEvent e){
				ventana.dispose();
			}
		});
		return menuSalir;
	}

	private JMenu crearMenuEdit() {
		
		menuEdit = new JMenu ("Edit");
		menuEdit.setMnemonic(KeyEvent.VK_E);

		opcionMenu = menuEdit.add ("Cut");
		opcionMenu.addActionListener (this);
		opcionMenu.setMnemonic(KeyEvent.VK_C);
		opcionMenu.setIcon(new ImageIcon("iconos/editcut.png"));
		menuEdit.add(opcionMenu);
		
		opcionMenu = new JMenuItem ("Copy");
		opcionMenu.addActionListener (this);
		opcionMenu.setMnemonic(KeyEvent.VK_P);
		opcionMenu.setIcon(new ImageIcon("iconos/editcopy.png"));
		
		menuEdit.add(opcionMenu);
		
		opcionMenu = new JMenuItem ("Paste");
		opcionMenu.addActionListener (this);
		opcionMenu.setMnemonic(KeyEvent.VK_T);
		opcionMenu.setIcon(new ImageIcon("iconos/editpaste.png"));
		menuEdit.add(opcionMenu);
		
		menuEdit.addSeparator();
		
		opcionMenu = new JMenuItem ("Delete");
		opcionMenu.addActionListener (this);
		opcionMenu.setMnemonic(KeyEvent.VK_D);
		opcionMenu.setIcon(new ImageIcon("iconos/editdelete.png"));
		menuEdit.add(opcionMenu);
		
		menuEdit.addSeparator();
		
		
		
		menuEdit.add(crearSubmenuContentAssist());
		
		return menuEdit;
		
	}

	private JMenu crearMenuFile() {
		
		
		menuFile = new JMenu("File");
		menuFile.setMnemonic(KeyEvent.VK_F);
		
		opcionMenu = new JMenuItem ("Open");
		opcionMenu.addActionListener (this);
		opcionMenu.setMnemonic(KeyEvent.VK_O);
		opcionMenu.setIcon(new ImageIcon("iconos/window_new.png"));
		menuFile.add(opcionMenu);
		
		opcionMenu = new JMenuItem ("Close");
		opcionMenu.addActionListener (this);
		opcionMenu.setIcon(new ImageIcon("iconos/kgpg.png"));
		opcionMenu.setMnemonic(KeyEvent.VK_K);
		menuFile.add(opcionMenu);
		
		menuFile.addSeparator();
		
		opcionMenu = new JMenuItem ("Move");
		opcionMenu.addActionListener (this);
		opcionMenu.setIcon(new ImageIcon("icons/agt_internet.png"));
		opcionMenu.setMnemonic(KeyEvent.VK_E);
		menuFile.add(opcionMenu);
		
		opcionMenu = new JMenuItem ("Rename");
		opcionMenu.addActionListener (this);
		opcionMenu.setMnemonic(KeyEvent.VK_Q);
		menuFile.add(opcionMenu);
		
		menuFile.addSeparator();
		
		
		
		menuFile.add(crearSubmenuConvert());
		return menuFile;
	}

private JMenu crearSubmenuContentAssist() {
		
		subMenu = new JMenu("Content Assist");
		
		opcionMenu = new JMenuItem ("Java Type Proposals");
		opcionMenu.addActionListener (this);
		
		opcionMenu.setMnemonic(KeyEvent.VK_P);
		subMenu.add(opcionMenu);
		
		opcionMenu = new JMenuItem ("Java Proposals");
		opcionMenu.addActionListener (this);
		opcionMenu.setMnemonic(KeyEvent.VK_C);
		
		subMenu.add(opcionMenu);
		
		return subMenu;
	}
 
 private JMenu crearSubmenuConvert() {
	
	subMenu = new JMenu("Convert Line Delimiters To");
	
	opcionMenu = new JMenuItem ("Unix");
	opcionMenu.addActionListener (this);
	opcionMenu.setIcon(new ImageIcon("iconos/tux.png"));
	subMenu.add(opcionMenu);
	
	opcionMenu = new JMenuItem ("Windows");
	opcionMenu.addActionListener (this);
	
	subMenu.add(opcionMenu);
	return subMenu;
}

	@Override
	public void actionPerformed(ActionEvent e) {
		JMenuItem opcion;
		String textoMsg;
		
		opcion = (JMenuItem) e.getSource();
		textoMsg= opcion.getText();
		JOptionPane.showMessageDialog (ventana,textoMsg,"mensaje",JOptionPane.INFORMATION_MESSAGE );
		
	}

	public static void main(String[] args) {
		try {
			//UIManager.setLookAndFeel(UIManager.getCrossPlatformLookAndFeelClassName());
			UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (InstantiationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IllegalAccessException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (UnsupportedLookAndFeelException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		MenuSimple ejercicio = new MenuSimple ();
	}
}
