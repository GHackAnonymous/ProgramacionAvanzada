package edu.mondragon.pa.dialogos;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Container;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;

import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JColorChooser;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;


public class Principal extends JFrame implements ActionListener{

	JTextField text1,text2;
	
	public Principal(String titulo){
		super(titulo);
		this.setSize(600,260);
		this.setLocation(100,100);
		
		this.setContentPane(crearPanelVentana());
		this.setVisible(true);
		this.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
	}
	
	private Container crearPanelVentana() {
		JPanel panel = new JPanel (new BorderLayout());
		panel.add(crearPanelTextos(), BorderLayout.CENTER);
		panel.add(crearPanelBotones(),BorderLayout.SOUTH);
		return panel;
	}

	private Component crearPanelBotones() {
		JPanel panel = new JPanel(new GridLayout(1,7,10,0));
		panel.setBorder(BorderFactory.createEmptyBorder(10,10,10,10));
		panel.add(crearBoton("Uno"));
		panel.add(crearBoton("Dos"));
		panel.add(crearBoton("Tres"));
		panel.add(crearBoton("Cuatro"));
		panel.add(crearBoton("Cinco"));
		panel.add(crearBoton("Seis"));
		panel.add(crearBoton("Siete"));
		
		return panel;
	}

	private Component crearBoton(String titulo) {
		JButton boton;
		boton = new JButton (titulo);
		boton.setActionCommand(titulo);
		boton.addActionListener(this);
		return boton;
	}

	private Component crearPanelTextos() {
		JPanel panel = new JPanel (new GridLayout(2,1,0,20));
		
		panel.setBorder(BorderFactory.createCompoundBorder(
				BorderFactory.createTitledBorder(BorderFactory.createLoweredBevelBorder(), "Datos Personales"),
				BorderFactory.createEmptyBorder(20, 20, 20, 20)));
		text1 = new JTextField (20);
		text2 = new JTextField (20);
		panel.add(text1);
		panel.add(text2);
		return panel;
	}
	@Override
	public void actionPerformed(ActionEvent e) {
		int opcion;
		
		if (e.getActionCommand().equals("Uno")){
			JOptionPane.showMessageDialog(this,"Esto es increible", "Aviso",JOptionPane.ERROR_MESSAGE);
		}
		if (e.getActionCommand().equals("Dos")){
			opcion = JOptionPane.showConfirmDialog(this, "Que sorpresa", "Titulo del mensaje",
					JOptionPane.YES_NO_CANCEL_OPTION,JOptionPane.WARNING_MESSAGE);
			
			switch (opcion){
			case JOptionPane.CANCEL_OPTION: 
				 text1.setText("ha elegido cancelar");
				 break;
			case JOptionPane.YES_OPTION:
				 text1.setText("ha elegido Si");
				 break;
			case JOptionPane.NO_OPTION:
				 text1.setText("ha elegido no");
				 break;
			 default:
				 text2.setText("No ha elegido nada"); 
			}
		}
		if (e.getActionCommand().equals("Tres")){
			String opciones[] = {"playa","monta�a","casa","ciudad"};
			opcion =JOptionPane.showOptionDialog(this,"Donde vamos de vacaciones?", "Trip",
					JOptionPane.YES_NO_CANCEL_OPTION,JOptionPane.PLAIN_MESSAGE, 
					new ImageIcon("soffice.png"), opciones, opciones[2]);
			
			if ( opcion>=0){
				text1.setText(opciones[opcion]);
			}
		}
		if (e.getActionCommand().equals("Cuatro")){
			String opciones [] = {"carne","pescado","verdura","fruta","marisco","pasta"};
			String respuesta = (String) JOptionPane.showInputDialog(this, "Que quieres comer?", "menu",
					JOptionPane.QUESTION_MESSAGE,new ImageIcon("cookie.png"), opciones, opciones[2]);
			
			text1.setText(respuesta);
			
		}
		if (e.getActionCommand().equals("Cinco")){
			JFileChooser chooser = new JFileChooser();
		    
		    int returnVal= chooser.showOpenDialog(this);
		    
			if(returnVal == JFileChooser.APPROVE_OPTION) {
					File f =chooser.getSelectedFile() ;
		            text1.setText(f.getName());
			}

		}
		if (e.getActionCommand().equals("Seis")){
		    
		    Color returnVal= JColorChooser.showDialog(this, "EligeColor", Color.black);
		    
			text1.setBackground(returnVal);
		}
		if (e.getActionCommand().equals("Siete")){
		    
		    MiDialog dialogo = new MiDialog (this,"Dialogo personalizado",true,text1.getText());
		    System.out.println("he pasado por aqui");
		    text2.setText(dialogo.getText());
		}
		
	}


	public static void main(String[] args) {
		
			try {
				UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
			} catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				JOptionPane.showMessageDialog(null, "No se encuentra el look&Feel");
			} catch (InstantiationException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IllegalAccessException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (UnsupportedLookAndFeelException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	
		Principal ejercicio = new Principal("Prueba Dialogos");

	}

}