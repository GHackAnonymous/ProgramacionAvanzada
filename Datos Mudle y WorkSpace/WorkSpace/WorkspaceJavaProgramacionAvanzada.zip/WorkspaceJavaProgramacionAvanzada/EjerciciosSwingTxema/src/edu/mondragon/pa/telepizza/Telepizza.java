package edu.mondragon.pa.telepizza;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;

import javax.swing.BorderFactory;
import javax.swing.ButtonGroup;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JTextField;

public class Telepizza implements ActionListener,ItemListener{

	JFrame ventana;
	JPanel pVentana,pCombo,pIngredientes,pSur,pDireccion,pBoton;
	JComboBox<String> cTama�o,cTipo;
	JCheckBox cJamon,cCebolla,cAlcaparras,cPimiento,cCarne,cAceitunas;
	
	ButtonGroup puntoRecogida;
	JRadioButton rRecoger,rLlevar;
	JTextField tDireccion;
	JButton bConfirmar;
	
	public Telepizza(){
		ventana = new JFrame("Pedidos Telepizza");
		ventana.setSize(500,400);
		ventana.setLocation(100,100);
		
		crearPanelVentana();
		
		ventana.setContentPane(pVentana);
		ventana.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		ventana.setVisible(true);
	}
	
	private void crearPanelVentana() {
		pVentana = new JPanel (new BorderLayout(0,10));
		pVentana.setBorder(BorderFactory.createEmptyBorder(10,20,10,20));
		
		crearPanelCombo();
		crearPanelIngredientes();
		crearPanelSur();
		
		pVentana.add(pCombo,BorderLayout.NORTH);
		pVentana.add(pIngredientes,BorderLayout.CENTER);
		pVentana.add(pSur,BorderLayout.SOUTH);
		
	}

	private void crearPanelSur() {
		pSur = new JPanel (new GridLayout(2,1));
		
		crearPanelDireccion();
		crearPanelBoton();
		
		pSur.add(pDireccion);
		pSur.add(pBoton);
		
	}

	private void crearPanelBoton() {
		pBoton = new JPanel();
		pBoton.setBorder(BorderFactory.createEmptyBorder(0,30,0,30));
		
		bConfirmar = new JButton ("CONFIRMAR");
		bConfirmar.setIcon(new ImageIcon("iconos/success.png"));
		bConfirmar.addActionListener(this);
		
		pBoton.add(bConfirmar);
	}

	private void crearPanelDireccion() {
		pDireccion = new JPanel(new GridLayout (1,3,10,0));
		
		puntoRecogida = new ButtonGroup();
		rRecoger = new JRadioButton ("Recoger en local");
		rRecoger.setSelected(true);
		rRecoger.addItemListener(this);
		
		rLlevar = new JRadioButton ("Llevar a: ");
		rLlevar.setSelected(false);
		rLlevar.addItemListener (this);
		
		puntoRecogida.add(rRecoger);
		puntoRecogida.add(rLlevar);
		
		tDireccion = new JTextField();
		tDireccion.addActionListener(this);
		tDireccion.setEditable(false);
		
		pDireccion.add(rRecoger);
		pDireccion.add(rLlevar);
		pDireccion.add(tDireccion);
	}

	private void crearPanelIngredientes() {
		pIngredientes = new JPanel (new GridLayout(3,2,10,10));
		pIngredientes.setBorder(BorderFactory.createLineBorder(Color.blue));
		
		cJamon= new JCheckBox("Jamon");
		cCebolla = new JCheckBox("Cebolla");
		cAlcaparras= new JCheckBox("Alcaparras");
		cPimiento= new JCheckBox("Pimiento");
		cCarne = new JCheckBox("Carne");
		cAceitunas = new JCheckBox("Aceitunas");
		
		pIngredientes.add (cJamon);
		pIngredientes.add (cCebolla);
		pIngredientes.add (cAlcaparras);
		pIngredientes.add (cPimiento);
		pIngredientes.add (cCarne);
		pIngredientes.add (cAceitunas);
	}

	private void crearPanelCombo() {
		String opTama�o []={"Peque�a","Mediana","Familiar"};
		String opTipo [] = {"Normal","Extra Queso","Pasta Fina"};
		
		pCombo = new JPanel(new GridLayout(1,2,10,0));
		
		cTama�o = new JComboBox<>(opTama�o);
		cTipo = new JComboBox <>(opTipo);
		
		pCombo.add(cTama�o);
		pCombo.add(cTipo);
		
	}

	
	public void actionPerformed(ActionEvent e) {
		String pedido = "";
		pedido = "Pizza " + cTama�o.getSelectedItem();
		pedido = pedido + " Tipo :" + cTipo.getSelectedItem()+ "\n";
		pedido = pedido + "Ingredientes : ";
		if (cJamon.isSelected())
			pedido = pedido + " "+cJamon.getText();
		if (cPimiento.isSelected())
			pedido = pedido + " "+cPimiento.getText();
		if (cCebolla.isSelected())
			pedido = pedido + " "+cCebolla.getText();
		if (cAlcaparras.isSelected())
			pedido = pedido + " "+cAlcaparras.getText();
		if (cAceitunas.isSelected())
			pedido = pedido + " "+cAceitunas.getText();
		if (cCarne.isSelected())
			pedido = pedido + " "+cCarne.getText();
		
		if (rLlevar.isSelected()){
			if (tDireccion.getText().length()!=0){
		
				pedido = pedido + "\n" + "Llevar a: " + tDireccion.getText();
				JOptionPane.showConfirmDialog(ventana, pedido,"Confirmar Pedido",
		 				JOptionPane.OK_CANCEL_OPTION);
				
			} else{
				JOptionPane.showMessageDialog(ventana, "Debes introducir la direccion","Error",JOptionPane.ERROR_MESSAGE);
			}
		}else{
		
			JOptionPane.showConfirmDialog(ventana, pedido,"Confirmar Pedido",
	 				JOptionPane.OK_CANCEL_OPTION);
			
		}
		
	}
	
	public void itemStateChanged(ItemEvent e) {
		
		if (e.getStateChange()==ItemEvent.SELECTED){
			if ((JRadioButton)e.getSource()==rLlevar){
				tDireccion.setEditable(true);
			}else{
				tDireccion.setEditable(false);
				tDireccion.setText("");
			}
		}
	
	}
	public static void main(String[] args) {
		Telepizza pedidos = new Telepizza();

	}
}
