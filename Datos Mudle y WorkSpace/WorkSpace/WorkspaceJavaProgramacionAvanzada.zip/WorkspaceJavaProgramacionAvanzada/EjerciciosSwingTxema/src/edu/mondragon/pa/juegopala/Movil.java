package edu.mondragon.pa.juegopala;

public interface Movil {
	public void mover(float dt);
}
