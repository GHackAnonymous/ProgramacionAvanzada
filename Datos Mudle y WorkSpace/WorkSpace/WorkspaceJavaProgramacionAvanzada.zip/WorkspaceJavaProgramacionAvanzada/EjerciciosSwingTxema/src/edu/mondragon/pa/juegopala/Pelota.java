package edu.mondragon.pa.juegopala;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.util.Observable;

public class Pelota implements Movil,Dibujable {
	 private final static int DIAMETRO = 20;
	 
	 private float x, y;
	 private float vx, vy;
	 int ancho,alto;
	 
	 public Pelota(int ancho, int alto){
		this.alto = alto;
		this.ancho = ancho;
	 	x = 10;
        y = 20;
        vx = 300;
        vy = 400;
	 }
	 public void mover(float dt) {
	        x += vx * dt;
	        y += vy * dt;

	        if (vx < 0 && x <= 0 || vx > 0 && x + DIAMETRO >= ancho)
	            vx = -vx;
	        
	        if (vy < 0 && y < 0 || vy > 0 && y + DIAMETRO >= alto)
	            vy = -vy;
	        
	        if (vx < 0 && x <= 0 || vx > 0 && x + DIAMETRO >= ancho)
	            vx = -vx;
	        if (vy < 0 && y < 0 || vy > 0 && y + DIAMETRO >= alto)
	            vy = -vy;
	  }
	 
	
	public void setLimites(int ancho, int alto) {
		this.alto = alto;
		this.ancho = ancho;
		
	}
	@Override
	public void draw(Graphics g) {
		 Graphics2D gr = (Graphics2D) g;
		 gr.setColor(Color.red);
		 gr.fillOval(Math.round(x), Math.round(y), DIAMETRO, DIAMETRO);
	}
	public void detectarColisionConPala(Pala pala) {
		if ( vy>0 && (y+DIAMETRO>=pala.getY()&&
				(x>pala.getX()&&x<(pala.getX()+Pala.ANCHOPALA)))){
			vy=-vy;
		}
		
	}
}
