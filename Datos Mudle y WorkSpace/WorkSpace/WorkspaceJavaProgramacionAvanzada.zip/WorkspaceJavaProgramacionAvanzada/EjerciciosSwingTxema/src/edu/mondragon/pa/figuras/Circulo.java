package edu.mondragon.pa.figuras;

import java.awt.Color;
import java.awt.Graphics;

public class Circulo extends Figura {

	int radio;
	
	
	public Circulo(String descripcion, int posX, int posY, int valor1) {
		super(descripcion,posX,posY);
		this.radio = valor1;
	}

	@Override
	double calcularSuperficie() {
		
		return Math.PI*radio*radio;
	}
	public String toString (){
		return "Circulo: " + nombre;
	}
	public void paint(Graphics g){
		g.setColor(Color.BLUE);
		g.fillOval(posX,posY, radio, radio);
	}

}
