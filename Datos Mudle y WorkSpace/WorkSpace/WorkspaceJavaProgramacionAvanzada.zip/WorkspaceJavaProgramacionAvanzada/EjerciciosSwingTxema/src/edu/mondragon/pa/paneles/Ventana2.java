package edu.mondragon.pa.paneles;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Container;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;


public class Ventana2 extends JFrame implements ActionListener{
	JLabel lValor;
	JButton bInc, bDec;
	int contador;
	Image fondo;
	public Ventana2 (){
		MiPanel panel;
		
		Toolkit toolkit = Toolkit.getDefaultToolkit();

		this.setLocation (100,100);
		this.setSize (600,400);
		fondo = toolkit.createImage("iconos/fondo.jpeg");
		this.setContentPane(crearPanelVentana());
		this.setIconImage(new ImageIcon("iconos/logo.png").getImage());
		this.setTitle("Buscando a nemo");
		this.setVisible(true);
		
		this.setDefaultCloseOperation (JFrame.EXIT_ON_CLOSE);
	}
	private Container crearPanelVentana() {
		JPanel panel = new MiPanel (fondo);
		panel.setLayout(new BorderLayout());
		panel.setBorder(BorderFactory.createEmptyBorder(20,10,20,10));
		
		lValor = new JLabel (String.valueOf(contador));
		lValor.setFont ( new Font("arial",Font.BOLD,67));
		lValor.setForeground(Color.red);
		lValor.setHorizontalAlignment(JLabel.CENTER);
		
		panel.add (lValor, BorderLayout.CENTER);
		panel.add (crearPanelBotones(),BorderLayout.SOUTH);
		panel.setOpaque(false);
		return panel;
	}

	private Component crearPanelBotones() {
		
		JPanel panel = new JPanel();
		panel.setOpaque(false);
		//panel.setLayout(new FlowLayout());
		panel.setLayout(new GridLayout(1,2,20,0));
		panel.setBorder(BorderFactory.createEmptyBorder(0,10,0,10));
		
		bInc = new JButton ("Incrementar");
		bInc.addActionListener(this);
		bInc.setActionCommand("inc");
		
		bDec = new JButton ("Decrementar");
		bDec.addActionListener(this);
		bDec.setActionCommand("dec");
		
		panel.add(bInc);
		panel.add(bDec);
		
		return panel;
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		
		if (e.getSource()==bInc){
			lValor.setText(String.valueOf(++contador));
		}
		if (e.getActionCommand().equals("dec")){
			lValor.setText(String.valueOf(--contador));
		}
	}

	public static void main(String[] args) {
		Ventana2 ejercicio = new Ventana2();

	}

}
