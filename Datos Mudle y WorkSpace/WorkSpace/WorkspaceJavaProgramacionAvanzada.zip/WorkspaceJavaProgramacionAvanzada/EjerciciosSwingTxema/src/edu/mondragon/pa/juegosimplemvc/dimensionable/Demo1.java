package edu.mondragon.pa.juegosimplemvc.dimensionable;
import java.awt.event.ComponentEvent;
import java.awt.event.ComponentListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.util.Observable;
import java.util.Observer;

import javax.swing.JFrame;

public class Demo1  implements Observer,ComponentListener {
	
	Pelota pelota;
	Panel panel;
	JFrame jf;
	
	public Demo1(){
		jf = new JFrame("Demo1");
		jf.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        jf.setResizable(true);
        jf.setSize(500, 600);
        jf.addComponentListener(this);
        pelota = new Pelota();
        pelota.addObserver(this);
        panel  = new Panel(pelota);
        jf.getContentPane().add(panel);
        jf.setVisible(true);
       
	}
   
	

    public void dinamizar() throws Exception {
        long tiempoViejo = System.nanoTime();
        float dt = 0.01f;
        while (true) {
           /* long tiempoNuevo = System.nanoTime();
            float dt = (tiempoNuevo - tiempoViejo) / 1000000000f;
            tiempoViejo = tiempoNuevo;
            
           */ 
        	Thread.sleep(10);
        	pelota.mover(dt);
           
        }
    }
    @Override
	public void componentHidden(ComponentEvent arg0) {
		// TODO Auto-generated method stub
		
	}



	@Override
	public void componentMoved(ComponentEvent arg0) {
		// TODO Auto-generated method stub
		
	}



	@Override
	public void componentResized(ComponentEvent arg0) {
		panel.setNewDimension();
		
	}



	@Override
	public void componentShown(ComponentEvent arg0) {
		// TODO Auto-generated method stub
		
	}

    @Override
	public void update(Observable o, Object ob) {
		jf.repaint();
		
	}
    public static void main(String[] args) throws Exception {
    	
       Demo1 juego = new Demo1();
       juego.dinamizar();
        
    }



	
	
}
