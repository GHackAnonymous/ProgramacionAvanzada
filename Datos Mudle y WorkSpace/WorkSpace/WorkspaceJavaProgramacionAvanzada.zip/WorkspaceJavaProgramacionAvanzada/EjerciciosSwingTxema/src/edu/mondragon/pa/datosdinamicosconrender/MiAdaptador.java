package edu.mondragon.pa.datosdinamicosconrender;
import java.awt.Color;
import java.awt.Component;
import java.awt.Font;

import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.ListCellRenderer;


public class MiAdaptador  implements ListCellRenderer<Persona> {

	@Override
	public Component getListCellRendererComponent(JList<? extends Persona> list,
				     Persona persona,
				     int index,
				     boolean isSelected,
				     boolean cellHasFocus) {
			
	 JPanel panel = new JPanel();
	 JButton boton = new JButton();
	 JLabel etiqueta = new JLabel();
	 
	 ImageIcon icono = null;
	 
     etiqueta.setText(persona.toString());
     switch (persona.getTipo()){
     case 1: icono = new ImageIcon("iconos/familia.png");break;
     case 2: icono = new ImageIcon("iconos/amigo.png");break;
     case 3: icono = new ImageIcon("iconos/utilities.png");break;
     default:
     }
     boton.setIcon(icono);
     etiqueta.setFont(new Font("Arial",Font.ITALIC,16));
     panel.setBorder(BorderFactory.createLineBorder(Color.red));
     panel.setBackground(isSelected ? Color.RED : Color.white);
     panel.setForeground(isSelected ? Color.WHITE : Color.black);
     panel.add(boton);
     panel.add(etiqueta);
     etiqueta.setOpaque(true);
     
     return panel;
   }
}
