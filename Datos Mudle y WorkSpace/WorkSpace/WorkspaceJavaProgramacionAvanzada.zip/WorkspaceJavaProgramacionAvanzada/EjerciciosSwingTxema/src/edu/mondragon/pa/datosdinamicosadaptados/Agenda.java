package edu.mondragon.pa.datosdinamicosadaptados;

import java.util.ArrayList;
import java.util.List;

import javax.swing.ListModel;
import javax.swing.event.ListDataEvent;
import javax.swing.event.ListDataListener;

public class Agenda implements ListModel<Persona>{
	
	List<Persona> agenda;
	List<ListDataListener> listeners;
	
	public Agenda(){
		agenda = new ArrayList<>();
		listeners = new ArrayList<>();
	}

	@Override
	public void addListDataListener(ListDataListener listener) {
		listeners.add(listener);
	}

	@Override
	public Persona getElementAt(int indice) {
		
		return agenda.get(indice);
	}

	@Override
	public int getSize() {
		
		return agenda.size();
	}

	@Override
	public void removeListDataListener(ListDataListener listener) {
		listeners.remove(listener);
		
	}

	public void add(Persona persona) {
		agenda.add(persona);
		for (ListDataListener listener : listeners){
			listener.contentsChanged(new ListDataEvent(agenda, ListDataEvent.CONTENTS_CHANGED,0, agenda.size() ));
		}
	}

	public void remove(int indice) {
		agenda.remove(indice);
		for (ListDataListener listener : listeners){
			listener.contentsChanged(new ListDataEvent(agenda, ListDataEvent.CONTENTS_CHANGED,indice, indice));
		}
	}
}
