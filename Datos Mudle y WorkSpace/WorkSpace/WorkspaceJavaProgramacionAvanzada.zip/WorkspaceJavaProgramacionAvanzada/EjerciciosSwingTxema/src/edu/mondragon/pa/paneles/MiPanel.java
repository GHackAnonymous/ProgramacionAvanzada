package edu.mondragon.pa.paneles;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;

import javax.swing.JPanel;


public class MiPanel extends JPanel{
	
	Image imagen;
	public MiPanel(Image imagen) {
		if (imagen != null) {
		 this.imagen = imagen;
		}
	}

	

	public void setImagen(Image nuevaImagen) {
		this.imagen = nuevaImagen;

		repaint();
	}

	@Override
	public void paint(Graphics g) {
		Graphics2D gr = (Graphics2D)g;
		
		if (imagen != null) {
			gr.drawImage(imagen, 0, 0, getWidth(), getHeight(),this);
			setOpaque(false);
		} else {
			setOpaque(true);
		}	
		super.paint(gr);
		
	}
}
