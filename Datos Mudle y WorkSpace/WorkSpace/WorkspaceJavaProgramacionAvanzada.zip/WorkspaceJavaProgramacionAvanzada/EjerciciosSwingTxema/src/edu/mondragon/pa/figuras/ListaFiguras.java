package edu.mondragon.pa.figuras;

import java.util.ArrayList;
import java.util.List;

import javax.swing.DefaultListModel;
import javax.swing.event.ListDataListener;

public class ListaFiguras extends DefaultListModel<Figura> implements Observable {
	
	private static final long serialVersionUID = 1L;
	List<Observer> observadores;
	List<Figura> figuras;
	
	List<ListDataListener> listeners;
	
	public ListaFiguras(){
		observadores = new ArrayList<Observer>();
		figuras = new ArrayList<Figura>();
	}
	
	@Override
	public void addObserver(Observer o) {
		observadores.add(o);
	}

	@Override
	public void deleteObserver(Observer o) {
		observadores.remove(o);
	}

	@Override
	public void notifyObservers() {
		
		for (Observer o : observadores){
			o.update(this);
		}
	}

	public void addElement(Figura figura) {
		super.add(0, figura);
		this.notifyObservers();
	
	}
	public Figura remove(int indice) {
		Figura f;
		f = super.remove(indice);
		this.notifyObservers();
		return f;
	}


}
