package edu.mondragon.pa.multiplesbolas;


public enum Forma {
	CIRCULO, CUADRADO
}
