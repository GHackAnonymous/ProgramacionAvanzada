package edu.mondragon.pa.datosestaticos;

import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.Container;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;

import javax.swing.BorderFactory;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JSplitPane;
import javax.swing.ListSelectionModel;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;


public class Principal extends JFrame implements ItemListener, ListSelectionListener{
	JComboBox<String> comboOpciones;
	JLabel texto;
	JScrollPane panelScroll;
	JList<String> lista = null;
	
	String opciones [] = {"peces","insectos","mamiferos","aves"};
	String peces [] = {"merluza","trucha","besugo","bonito","lenguado","lubina","anchoa","chicharro",
						"gallo","salmon","salmonete","bacalao","anguila"};
	String insectos[] = {"mariposa","abeja","mosca","mosquito","gusano"};
	String mamiferos[] = {"perro","vaca","caballo","gato"};
	String aves[] = {"gallina","paloma","jilguero"};

	
	public Principal(){
		super("Visualizador de listas");
		this.setSize(600,300);
		this.setLocation(100,100);
		this.setContentPane(crearPanelVentana());
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setVisible(true);
		
	}

	private Container crearPanelVentana() {
		JPanel panel = new JPanel(new BorderLayout(0,5));
		panel.add(crearPanelCentral(), BorderLayout.CENTER);
		panel.add(crearPanelTexto(),BorderLayout.SOUTH);
		panel.setBorder(BorderFactory.createEmptyBorder(20,10,20,10));
		return panel;
	}

	
	private Component crearPanelCentral() {
		JSplitPane panel = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT,true,crearPanelIzda(),crearPanelDcha());
		panel.setDividerLocation(200);
		panel.setDividerSize(15);
		return panel;
	}
	private Component crearPanelDcha() {
		panelScroll = new JScrollPane(JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED,JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
		lista = new JList<> (peces);
		//lista.setSelectionMode(ListSelectionModel.MULTIPLE_INTERVAL_SELECTION);
		lista.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
		lista.addListSelectionListener(this);
		panelScroll.setViewportView(lista);
		return panelScroll;
	}

	private Component crearPanelIzda() {
		JPanel panel = new JPanel (new BorderLayout());
		comboOpciones = new JComboBox<>(opciones);
		comboOpciones.setSelectedIndex(0);
		comboOpciones.addItemListener(this);
		
		panel.add(comboOpciones,BorderLayout.NORTH);
		return panel;
	}

	private Component crearPanelTexto() {
		JPanel panel = new JPanel(new GridLayout(1,1));
		panel.setBorder(BorderFactory.createLoweredBevelBorder());
		texto = new JLabel(" ");
		
		panel.add(texto);
		return panel;
	}
	
	
	@Override
	public void itemStateChanged(ItemEvent e) {
		if (e.getSource()==comboOpciones){
			
			int seleccion = comboOpciones.getSelectedIndex();
			switch (seleccion){
			case 0:
				lista = new JList<>(peces);break;
			case 1: 
				lista = new JList<>(insectos);break;
			case 2:
				lista = new JList<>(mamiferos);break;
			case 3:
				lista = new JList<>(aves);break;
			default:
			}
			lista.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
			//lista.setSelectionMode(ListSelectionModel.MULTIPLE_INTERVAL_SELECTION);
			lista.addListSelectionListener(this);
			panelScroll.setViewportView(lista);
			texto.setText(" ");
		}
	}
	@Override
	public void valueChanged(ListSelectionEvent e) {
		if (e.getValueIsAdjusting())
			return;
		if (lista.isSelectionEmpty()){
			texto.setText(" ");
		}else{
			texto.setText((String)lista.getSelectedValue());
			
			/*
			String msg = "";
			for (String o : lista.getSelectedValuesList() ){
				msg+= o+" " ;
			}
			texto.setText(msg);
		*/
		}
	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		Principal ejercicio = new Principal();
		

	}

	


	

}
