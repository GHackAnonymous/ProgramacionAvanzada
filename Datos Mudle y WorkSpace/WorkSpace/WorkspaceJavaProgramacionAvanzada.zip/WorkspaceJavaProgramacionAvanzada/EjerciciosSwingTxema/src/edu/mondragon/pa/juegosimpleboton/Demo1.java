package edu.mondragon.pa.juegosimpleboton;
import java.awt.*;
import java.awt.event.*;
import java.util.Observable;
import java.util.Observer;

import javax.swing.*;

public class Demo1  implements Observer, ActionListener {

	JFrame jf;
	ElementosMoviles moviles;
	ElementosDibujables dibujables;
	Panel miPanel;
	
	public Demo1(){
		jf = new JFrame("Demo1");
		jf.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        jf.setResizable(false);
        moviles = new ElementosMoviles();
        dibujables = new ElementosDibujables();
        moviles.addObserver(this);
        
      
        jf.getContentPane().add(crearPanelVentana());
        jf.pack();
        jf.setLocation(100,100);
        jf.setVisible(true);
       
	}
   
	

    private Component crearPanelVentana() {
    	Pelota pelota;
		JPanel panel = new JPanel (new BorderLayout());
		
		
		miPanel = new Panel(dibujables);
		pelota = new Pelota(Panel.ANCHO,Panel.ALTO);
		dibujables.add(pelota);
		moviles.add(pelota);
		panel.add(miPanel,BorderLayout.CENTER);
		panel.add(crearPanelBoton(), BorderLayout.SOUTH);
		
		return panel;
	}



	private Component crearPanelBoton() {
		JPanel panel = new JPanel();
		JButton boton = new JButton ("Mas...");
		boton.addActionListener(this);
		panel.add(boton);
		return panel;
	}



	public void dinamizar() throws Exception {
        long tiempoViejo = System.nanoTime();
        float dt = 0.01f;
        while (true) {
           /* long tiempoNuevo = System.nanoTime();
            float dt = (tiempoNuevo - tiempoViejo) / 1000000000f;
            tiempoViejo = tiempoNuevo;
           */ 
        	Thread.sleep(10);
        	moviles.mover(dt);
           
        }
    }
	@Override
	public void actionPerformed(ActionEvent arg0) {
		Pelota pelota = new Pelota(Panel.ANCHO,Panel.ALTO);
		dibujables.add(pelota);
		moviles.add(pelota);
		
	}

    @Override
	public void update(Observable o, Object ob) {
		jf.repaint();
		
	}
    public static void main(String[] args) throws Exception {
    	
       Demo1 juego = new Demo1();
       juego.dinamizar();
        
    }



	
	
}
