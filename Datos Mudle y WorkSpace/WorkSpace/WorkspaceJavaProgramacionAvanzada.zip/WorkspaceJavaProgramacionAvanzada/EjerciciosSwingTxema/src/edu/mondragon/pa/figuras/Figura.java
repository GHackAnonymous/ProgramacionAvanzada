package edu.mondragon.pa.figuras;

import java.awt.Graphics;

abstract public class Figura {
	
	int posX,posY;
	String nombre;
	
	public Figura (String nombre,int posX, int posY){
		this.posX = posX;
		this.posY = posY;
		this.nombre = nombre;
	}
	
	abstract double calcularSuperficie();
	abstract void paint (Graphics g);
}
