package edu.mondragon.pa.puzzle;
import java.awt.Color;
import java.awt.Graphics;

import javax.swing.*;

public class MiBoton extends JButton{

	@Override
	public void paint(Graphics g) {
		if (this.hasFocus()){
			this.setBorder(BorderFactory.createLineBorder(Color.blue));
		}else{
			this.setBorder(null);
		}
		super.paint(g);
	}

}
