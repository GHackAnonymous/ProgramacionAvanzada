package edu.mondragon.pa.figuras;

import java.awt.Color;
import java.awt.Graphics;

public class Rectangulo extends Figura {
	
	int lado1,lado2;
	
	public Rectangulo ( String nombre,int posX,int posY,int l1,int l2){
		super(nombre,posX,posY);
		this.lado1 = l1;
		this.lado2 = l2;
	}
	@Override
	double calcularSuperficie() {
		
		return lado1*lado2;
	}

	public String toString (){
		return "Rectangulo " + nombre;
	}
	@Override
	void paint(Graphics g) {
		g.setColor(Color.GREEN);
		g.fillRect(posX, posY, lado1, lado2);
		
	}
}
