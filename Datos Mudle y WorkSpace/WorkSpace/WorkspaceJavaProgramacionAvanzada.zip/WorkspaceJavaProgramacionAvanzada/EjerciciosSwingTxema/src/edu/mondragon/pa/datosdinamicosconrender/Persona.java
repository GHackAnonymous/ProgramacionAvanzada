package edu.mondragon.pa.datosdinamicosconrender;
public class Persona {
	String nombre;
	String apellido1;
	String apellido2;
	int tipo; //1- casa 2.- trabajo 3.- amigo
	
	public Persona (String n,String a1,String a2,int tipo){
		this.nombre = n;
		this.apellido1 = a1;
		this.apellido2 = a2;
		this.tipo = tipo;
	}
	public String toString (){
		return nombre +" "+ apellido1+ " "+apellido2;
	}
	public int getTipo() {
		
		return tipo;
	}
}
