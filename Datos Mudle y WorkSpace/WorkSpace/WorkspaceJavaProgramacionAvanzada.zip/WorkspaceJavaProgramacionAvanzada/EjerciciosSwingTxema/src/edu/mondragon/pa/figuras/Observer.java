package edu.mondragon.pa.figuras;

public interface Observer {
	void update(Observable ob);
}
