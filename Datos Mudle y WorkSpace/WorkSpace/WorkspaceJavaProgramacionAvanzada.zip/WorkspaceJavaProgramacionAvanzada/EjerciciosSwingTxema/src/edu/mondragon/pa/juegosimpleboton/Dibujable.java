package edu.mondragon.pa.juegosimpleboton;

import java.awt.Graphics;

public interface Dibujable {
	
	public void draw (Graphics g);

}
