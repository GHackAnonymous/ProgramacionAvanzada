package edu.mondragon.pa.juegopala;
import java.awt.Component;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.util.Observable;
import java.util.Observer;

import javax.swing.JFrame;

public class Demo3 implements Observer, KeyListener {

	JFrame jf;
	ElementosMoviles moviles;
	ElementosDibujables dibujables;
	Panel miPanel;
	Pelota pelota;
	Pala pala;
	
    public Demo3()  {
        jf = new JFrame ("fronton");
       
		jf.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        jf.setResizable(false);
        moviles = new ElementosMoviles();
        dibujables = new ElementosDibujables();
        moviles.addObserver(this);
        
      
        jf.getContentPane().add(crearPanelVentana());
        jf.pack();
        jf.setLocation(100,100);
        jf.setVisible(true);
        
        
    }
    private Component crearPanelVentana() {
    	
		
		miPanel = new Panel(dibujables);
		pelota = new Pelota(Panel.ANCHO,Panel.ALTO);
		pala = new Pala (Panel.ANCHO);
		dibujables.add(pelota);
		dibujables.add(pala);
		moviles.add(pelota);
		moviles.add(pala);
		miPanel.setFocusable(true);
		miPanel.addKeyListener(this);
		return miPanel;
	}
    public void dinamizar() throws Exception {
        long tiempoViejo = System.nanoTime();
        float dt = 0.01f;
        while (true) {
        	Thread.sleep(10);
        	moviles.mover(dt);
        	pelota.detectarColisionConPala(pala);
         }
    }
    

   

    public static void main(String[] args) throws Exception {
       
       Demo3 juego = new Demo3();
       juego.dinamizar();
    }

	@Override
	public void keyPressed(KeyEvent e) {
		
		
		if (e.getKeyCode() == KeyEvent.VK_LEFT)
			pala.setIncX(-20);
		if  (e.getKeyCode() == KeyEvent.VK_RIGHT)
			pala.setIncX(20);
		
	}

	@Override
	public void keyReleased(KeyEvent e) {
		
		if (e.getKeyCode() == KeyEvent.VK_LEFT)
			pala.setIncX(0);
		if  (e.getKeyCode() == KeyEvent.VK_RIGHT)
			pala.setIncX(0);
		
	}

	@Override
	public void keyTyped(KeyEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void update(Observable arg0, Object arg1) {
		jf.repaint();
		
	}
}
