package edu.mondragon.pa.datosdinamicosconrender;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Container;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;

import javax.swing.BorderFactory;
import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JTextField;


public class DialogoInsertarPersona extends JDialog implements ActionListener	{

	JTextField nombre,apellido1,apellido2;
	Persona newPersona = null;
	ButtonGroup grupo;
	JRadioButton  rbFamilia,  rbTrabajo,  rbAmigo;
	public DialogoInsertarPersona(JFrame ventana, String titulo, boolean modo){
		super(ventana,titulo,modo);		
		this.setSize(400,340);
		this.setLocation(200,200);
		this.setContentPane(crearPanelVentana());
		this.setVisible(true);
		this.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
	}

	private Container crearPanelVentana() {
		JPanel panel = new JPanel (new BorderLayout(0,10));
		panel.setBorder(BorderFactory.createEmptyBorder(10,20,10,20));
		panel.add(crearPanelDatos(),BorderLayout.CENTER);
		panel.add(crearPanelBotones(),BorderLayout.SOUTH);
		return panel;
	}

	private Component crearPanelDatos() {
		JPanel panel = new JPanel (new GridLayout(4,1,0,10));
		nombre = new JTextField(20);
		apellido1 = new JTextField(20);
		apellido2 = new JTextField (20);
		panel.add(crearTextField(nombre,"Nombre"));
		panel.add(crearTextField(apellido1,"Primer Apellido"));
		panel.add(crearTextField(apellido2,"Segundo Apellido"));
		panel.add(crearPanelTipo());
		return panel;
	}

	private Component crearPanelTipo() {
		JPanel panel = new JPanel();
		
		grupo = new ButtonGroup();
		rbFamilia = new JRadioButton("Familia");
		panel.add(rbFamilia);
		grupo.add(rbFamilia);
		
		rbTrabajo = new JRadioButton("Trabajo");
		
		//rbTrabajo.setBackground(Color.WHITE);
		panel.add(rbTrabajo);
		grupo.add(rbTrabajo);
		
		rbAmigo = new JRadioButton("Amigo");
		
		
		//rbAmigo.setBackground(Color.WHITE);
		panel.add(rbAmigo);
		grupo.add(rbAmigo);
		rbFamilia.setSelected(true);
		return panel;
	}

	private Component crearTextField(JTextField text, String titulo) {
		JPanel panel = new JPanel(new GridLayout(1,1));
		panel.setBorder(BorderFactory.createTitledBorder(
				BorderFactory.createLineBorder(Color.cyan), titulo));
		
		panel.add(text);
		return panel;
	}

	private Component crearPanelBotones() {
		JPanel panel = new JPanel (new GridLayout(1,2,20,0));
		JButton bOk = new JButton ("OK");
		bOk.setActionCommand("ok");
		bOk.addActionListener(this);
		
		JButton bCancel = new JButton ("Cancelar");
		bCancel.setActionCommand("cancel");
		bCancel.addActionListener(this);
		
		panel.add(bOk);
		panel.add(bCancel);
		return panel;
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		int tipo= 0;
		if (e.getActionCommand().equals("ok")){
			if (rbFamilia.isSelected()) tipo = 1;
			if (rbAmigo.isSelected()) tipo = 2;
			if (rbTrabajo.isSelected()) tipo = 3;
			newPersona = new Persona (nombre.getText(),apellido1.getText(),apellido2.getText(),tipo);
			dispose();
		}
		if (e.getActionCommand().equals("cancel")){
			dispose();
		}
		
	}
	Persona getPersona(){
		return newPersona;
	}

	
}
