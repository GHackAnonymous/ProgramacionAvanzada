package edu.mondragon.pa.juegopala;

import java.awt.Graphics;

public interface Dibujable {
	
	public void draw (Graphics g);

}
