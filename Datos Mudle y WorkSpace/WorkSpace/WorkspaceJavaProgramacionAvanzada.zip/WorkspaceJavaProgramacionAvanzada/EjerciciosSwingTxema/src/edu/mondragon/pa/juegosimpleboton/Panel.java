package edu.mondragon.pa.juegosimpleboton;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.util.ArrayList;

import javax.swing.JPanel;

public class Panel extends JPanel {
	
	final static int ANCHO = 512;

    final static int ALTO = 384;

   // Pelota pelota;
   ElementosDibujables componentes;
    
    public Panel(ElementosDibujables dibujables){
    	 setPreferredSize(new Dimension(ANCHO, ALTO));
    	 componentes= dibujables;
    	 
    }
   
   
    public void paint(Graphics g) {
        g.setColor(Color.WHITE);
        g.fillRect(0, 0, ANCHO, ALTO);
     
        componentes.draw(g);
       
       
    }

}
