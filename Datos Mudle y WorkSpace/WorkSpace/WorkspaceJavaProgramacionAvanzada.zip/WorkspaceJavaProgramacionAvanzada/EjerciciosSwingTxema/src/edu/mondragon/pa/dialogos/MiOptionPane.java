package edu.mondragon.pa.dialogos;

import javax.swing.ImageIcon;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JOptionPane;


public class MiOptionPane extends JDialog {
	JOptionPane panel;
	String opciones [] = {"carne","pescado","verdura","fruta","marisco","pasta"};
	
	public MiOptionPane (JFrame frame, String titulo){
		super( frame,titulo,true);
		
		this.setSize(100,100);
		this.setLocation(100,100);
		
		panel = new JOptionPane( "Que quieres comer?",JOptionPane.QUESTION_MESSAGE,JOptionPane.YES_NO_OPTION,
								new ImageIcon("cookie.png"), opciones);
		this.setContentPane(panel);
		this.setVisible(true);
		this.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
	}
}
