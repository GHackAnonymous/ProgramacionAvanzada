package edu.mondragon.pa.juegosimpleboton;

public interface Movil {
	public void mover(float dt);
}
