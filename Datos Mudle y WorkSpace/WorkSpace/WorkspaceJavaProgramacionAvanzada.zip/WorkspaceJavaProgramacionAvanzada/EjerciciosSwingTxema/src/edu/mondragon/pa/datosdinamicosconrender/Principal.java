package edu.mondragon.pa.datosdinamicosconrender;
import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.Container;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.BorderFactory;
import javax.swing.DefaultListModel;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;


public class Principal extends JFrame implements ActionListener{
	JList<Persona> lista;
	DefaultListModel<Persona> modelo;
	
	public Principal(){
		super ("Lista de clase");
		this.setSize (280,400);
		this.setLocation(200,200);
		this.setContentPane(crearPanelVentana());
		this.setDefaultCloseOperation(EXIT_ON_CLOSE);
		this.setVisible(true);
	}
	private Container crearPanelVentana() {
		JPanel panel = new JPanel(new BorderLayout(0,10));
		panel.add(crearPanelLista(),BorderLayout.CENTER);
		panel.add(crearPanelBotones(),BorderLayout.SOUTH);
		panel.setBorder(BorderFactory.createEmptyBorder(20,10,20,10));
		return panel;
	}
	private Component crearPanelLista() {
		JScrollPane panel = new JScrollPane(JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED,JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
		MiAdaptador adaptador = new MiAdaptador();
		lista = new JList<>();
		modelo = new DefaultListModel<>();
		lista.setModel(modelo);
		lista.setCellRenderer(adaptador);
		panel.setViewportView(lista);
		return panel;
	}
	private Component crearPanelBotones() {
		JPanel panel = new JPanel(new GridLayout(1,2,10,0));
		JButton bAdd = new JButton ("A�adir");
		bAdd.setActionCommand("add");
		bAdd.addActionListener(this);
		
		JButton bDel = new JButton("Borrar");
		bDel.setActionCommand("del");
		bDel.addActionListener(this);
		
		panel.add(bAdd);
		panel.add(bDel);
		return panel;
	}
	@Override
	public void actionPerformed(ActionEvent e) {
		if (e.getActionCommand().equals("add")){
			DialogoInsertarPersona dialogoInsertar = new DialogoInsertarPersona (this,"Datos nueva Persona",true);
			Persona p = dialogoInsertar.getPersona();
			if (p!=null){
				modelo.addElement(p);
			}
			
		}
		if (e.getActionCommand().equals("del")){
			int indice = lista.getSelectedIndex();
			if (indice != -1){
				modelo.remove(indice);
			}
		}
		
	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		
		Principal ejercicio = new Principal();
		
	}
	
}
