package edu.mondragon.pa.figuras;

import java.awt.Color;
import java.awt.Graphics;

import javax.swing.JPanel;

public class MiPanel extends JPanel implements Observer{

	private static final long serialVersionUID = 1L;
	ListaFiguras lista;
	public MiPanel (ListaFiguras lista){
		super();
		this.lista = lista;
		lista.addObserver(this);
	}
	@Override
	public void paint(Graphics g) {
		int width = this.getWidth();
		int height = this.getHeight();
		g.setColor(Color.WHITE);
		g.fillRect(0, 0, width, height);
		for (int i = 0; i<lista.getSize(); i++){
			lista.get(i).paint(g);
		}
		
		
	}
	
	
	@Override
	public void update(Observable lista) {
		if (lista instanceof ListaFiguras){
			this.lista = (ListaFiguras) lista;
			this.repaint();
		}
	}
	
		
	
}
