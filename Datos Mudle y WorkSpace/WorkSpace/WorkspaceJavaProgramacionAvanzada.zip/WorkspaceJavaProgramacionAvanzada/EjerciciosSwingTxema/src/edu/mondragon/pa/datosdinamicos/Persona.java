package edu.mondragon.pa.datosdinamicos;
public class Persona {
	String nombre;
	String apellido1;
	String apellido2;
	
	public Persona (String n,String a1,String a2){
		this.nombre = n;
		this.apellido1 = a1;
		this.apellido2 = a2;
	}
	
	public String toString (){
		return nombre +" "+ apellido1+ " "+apellido2;
	}
	
}
