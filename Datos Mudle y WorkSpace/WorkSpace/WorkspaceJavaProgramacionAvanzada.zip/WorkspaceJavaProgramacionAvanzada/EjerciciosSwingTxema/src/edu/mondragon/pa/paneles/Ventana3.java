package edu.mondragon.pa.paneles;

import java.awt.Dimension;
import java.awt.Image;
import java.awt.Toolkit;
import java.beans.PropertyVetoException;

import javax.swing.ImageIcon;
import javax.swing.JDesktopPane;
import javax.swing.JFrame;
import javax.swing.JLabel;


public class Ventana3 extends JFrame{

	JDesktopPane desktop;
	Image fondo;
	public Ventana3(String titulo){
		super(titulo);
	
	    
	    int margen = 50;
	    Dimension tama�o = Toolkit.getDefaultToolkit().getScreenSize();
	    setBounds(margen, margen,
	              tama�o.width  - margen*2,
	              tama�o.height - margen*2);
	    Toolkit toolkit = Toolkit.getDefaultToolkit();
	    //JFrame.setDefaultLookAndFeelDecorated(true);
		
		fondo = toolkit.createImage("iconos/fondo.jpeg");
	    
	    desktop = new MiDesktopPane(fondo);
	    
	    crearVentanaCuentaClicks(); 
	    setContentPane(desktop);
	    this.setIconImage(new ImageIcon("iconos/logo.png").getImage());
	    this.setVisible(true);
	    this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	    
	   
	}
	
	private void crearVentanaCuentaClicks() {
 
        VentanaCuentaClicks ventana = new VentanaCuentaClicks(30,30);
        VentanaCuentaClicks otraVentana = new VentanaCuentaClicks (400,30);
        ventana.setVisible(true); 
        otraVentana.setVisible(true);
        desktop.add(ventana);
        desktop.add(otraVentana);
  
	}

	public static void main(String[] args) {
		String titulo;
		if (args.length == 0){
			titulo = "buscando a nemo";
		}else{
			titulo = args[0];
		}
		Ventana3 ejercicio = new Ventana3(titulo);
	}

	
}
