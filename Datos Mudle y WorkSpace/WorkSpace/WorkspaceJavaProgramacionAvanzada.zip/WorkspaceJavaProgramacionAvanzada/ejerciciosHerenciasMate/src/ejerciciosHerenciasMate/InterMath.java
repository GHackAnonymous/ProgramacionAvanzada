package ejerciciosHerenciasMate;

public interface InterMath {
	public void capicua();
	public void primo();
	public void suma13();
}
