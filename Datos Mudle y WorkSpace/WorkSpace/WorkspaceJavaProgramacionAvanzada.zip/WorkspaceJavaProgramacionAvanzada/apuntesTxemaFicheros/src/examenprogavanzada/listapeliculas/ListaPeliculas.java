package examenprogavanzada.listapeliculas;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

import javax.swing.DefaultListModel;

public class ListaPeliculas extends DefaultListModel<Pelicula> {
	final String nombreFichero = "files/peliculas.txt";
	
	int maxPeliculas;
	public ListaPeliculas() {
		
		maxPeliculas =this.leerNumPeliculas();
	}
	
	
	public int leerNumPeliculas() {
		int contador = 0;
		BufferedReader in = null;
		String linea = null;
		int indice = 1;
		this.removeAllElements();
		try {
			in = new BufferedReader(new FileReader(nombreFichero));
			
			while (((linea = in.readLine())!=null)){
				
				contador++;
			}
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			if (in!=null){
				try {
					in.close();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
		return contador;
	}
	public void leerPeliculas(int minimo,int maximo) {
		BufferedReader in = null;
		String linea = null;
		int indice = 1;
		this.removeAllElements();
		try {
			in = new BufferedReader(new FileReader(nombreFichero));
			
			while (((linea = in.readLine())!=null)&&(indice<maximo)){
				if (indice >= minimo){
					String valores [] = linea.split("[$]");
					Pelicula p = new Pelicula(valores[0],valores[1],Integer.valueOf(valores[2]),
									valores[3],valores[4],valores[5]);	
					this.addElement(p);
				}
				indice++;
			}
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			if (in!=null){
				try {
					in.close();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
		
	}
	public int getMaxPeliculas() {
		return this.maxPeliculas;
	}
}
