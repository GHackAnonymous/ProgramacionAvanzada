package examenprogavanzada.tablaalumnos;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Container;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.AbstractAction;
import javax.swing.Action;
import javax.swing.BorderFactory;
import javax.swing.ButtonGroup;
import javax.swing.Icon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.JToolBar;



public class Principal extends JFrame implements ActionListener {
	
	JTextField tfValor;
	JRadioButton bPoblacion,bEdad,bNombre,bApellido1;
	ModeloTablaAlumno tabla;
	 
	JTable vTabla;
	TrazadorTablaAlumnos trazador;
	ModeloColumnasTablaAlumnos columnas;
	JScrollPane panelS;
	public Principal(){
		super("Alumnos 2� de grado de inform�tica");
		trazador = new TrazadorTablaAlumnos();
		columnas = new ModeloColumnasTablaAlumnos (trazador);
		tabla = new ModeloTablaAlumno(columnas);
		this.setSize(800,600);
		this.setLocation(100, 100);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setContentPane(crearPanelVentana());
		this.setVisible(true);
	}

	
	private Container crearPanelVentana() {
		
		JPanel panel = new JPanel (new BorderLayout(10,0));
		panel.setBorder(BorderFactory.createEmptyBorder(10,10,10,10));
		panel.add(crearToolBar(),BorderLayout.NORTH);
		panel.add(crearPanelSeleccion(),BorderLayout.WEST);
		panelS = new JScrollPane(JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED,JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
		panel.add(panelS,BorderLayout.CENTER);
		crearTabla();
		return panel;
	}
	private Component crearPanelSeleccion() {
		JPanel panel = new JPanel(new BorderLayout());
		panel.add(crearPanelOpciones(),BorderLayout.NORTH);
		
		
		return panel;
	}


	private Component crearPanelOpciones() {
		JPanel panel = new JPanel (new GridLayout(4,1,0,10));
		panel.setBorder (BorderFactory.createCompoundBorder(
				BorderFactory.createLineBorder(Color.CYAN),
				BorderFactory.createEmptyBorder(5,5,5,5)));
		ButtonGroup grupo = new ButtonGroup();
		
		JPanel panelOpcion = new JPanel(new GridLayout(1,2));
		bPoblacion = new JRadioButton("Poblacion");
		grupo.add(bPoblacion);
		panelOpcion.add(bPoblacion);
		bPoblacion.setSelected(true);
		bEdad = new JRadioButton("Edad");
		grupo.add(bEdad);
		panelOpcion.add(bEdad);
		panel.add(panelOpcion);
		panelOpcion = new JPanel(new GridLayout(1,2));
		bNombre = new JRadioButton("Nombre");
		grupo.add(bNombre);
		panelOpcion.add(bNombre);
		bApellido1 = new JRadioButton("Apellido1");
		grupo.add(bApellido1);
		panelOpcion.add(bApellido1);
		panel.add(panelOpcion);
		
		tfValor = new JTextField();
		panel.add(tfValor);
		
		JButton botonSeleccionar = new JButton("Seleccionar");
		botonSeleccionar.addActionListener(this);
		panel.add(botonSeleccionar);
		return panel;
	}


	private Component crearToolBar() {
		JToolBar barra = new JToolBar();
		
		return barra;
	}


	private void crearTabla() {
		vTabla = new JTable(tabla,columnas);
		vTabla.setFillsViewportHeight(true);
		panelS.setViewportView(vTabla);
	}
	
	private class MiAccion extends AbstractAction {
		String texto;
		public MiAccion (String texto, Icon imagen, String descrip, Integer nemonic){
			super(texto,imagen);
			this.texto = texto;
			this.putValue( Action.SHORT_DESCRIPTION ,descrip);
			this.putValue(Action.MNEMONIC_KEY, nemonic);
		}

		@Override
		public void actionPerformed(ActionEvent arg0) {
			
		
			
			
		}
	}
	public static void main(String[] args) {
		Principal ejercicio = new Principal();

	}

	@Override
	public void actionPerformed(ActionEvent arg0) {
		Selector selector= null;
		String valor = tfValor.getText();
		if (valor.length()!=0){
			if (bPoblacion.isSelected()) selector = FactorySelectores.getSelectorPoblacion();
			if (bNombre.isSelected()) selector = FactorySelectores.getSelectorNombre();
			if (bEdad.isSelected()) selector = FactorySelectores.getSelectorEdad();
			if (bApellido1.isSelected()) selector = FactorySelectores.getSelectorApellido1();
		}
		/*else{
			tabla.guardarEnFicheroObjetos();
		}
		*/
		tabla.leerTablaFichero(selector, valor);
		
	}

}
