package examenprogavanzada.tablaalumnos;

public interface Selector {

	boolean seleccionar (Alumno a, String valor);
}
