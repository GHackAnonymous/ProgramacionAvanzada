package examenprogavanzada.tablaalumnos;

import java.io.EOFException;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.util.ArrayList;

import javax.swing.table.AbstractTableModel;

public class ModeloTablaAlumno extends AbstractTableModel {
	
	final static String NOMBRE_FICHERO = "files/listaclase.dat";
	
	ModeloColumnasTablaAlumnos columnas;
	
	ArrayList<Alumno> listaAlumnos;
	
	public ModeloTablaAlumno(ModeloColumnasTablaAlumnos columnas){
		super();
		leerTablaFichero(null,null);
		
		this.columnas = columnas;
		
	}

	public void leerTablaFichero(Selector selector, String valor){
		listaAlumnos = new ArrayList<>();
		Alumno alumno= null;
		ObjectInputStream in = null;
		
		try {
			in = new ObjectInputStream(new FileInputStream(NOMBRE_FICHERO));
			while ((alumno =(Alumno) in.readObject())!=null){
				if (selector !=null){
					if (selector.seleccionar(alumno, valor)){
						listaAlumnos.add(alumno);
					}
				}else{
					listaAlumnos.add(alumno);
				}
			}
		}catch (EOFException e){
			
		}catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			if (in!=null)
				try { in.close(); } catch (IOException e) {}
		}
		this.fireTableDataChanged();
	}
/*
	public void leerTablaFichero(Selector selector,String valor) {
		String linea = null;
		listaAlumnos = new ArrayList<>();
		Alumno alumno = null;
		BufferedReader in = null;
		
		try {
			in = new BufferedReader(new FileReader(NOMBRE_FICHERO));
			
			while((linea = in.readLine())!=null){
				alumno = leerAlumno(linea);
				if (selector !=null){
					if (selector.seleccionar(alumno, valor)){
						listaAlumnos.add(alumno);
					}
				}else{
					listaAlumnos.add(alumno);
				}
				
			}
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		this.fireTableDataChanged();
		
	}
	
	public void guardarEnFicheroObjetos(){
		ObjectOutputStream out= null;
		try {
			out = new ObjectOutputStream ( new FileOutputStream("files/listaclase.dat"));
			for (Alumno a : listaAlumnos){
				out.writeObject(a);
			}
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			if (out!=null){
				try { out.close(); 	} catch (IOException e) {}
			}
		}
	}
*/	private Alumno leerAlumno(String linea) {
		String [] palabras = linea.split("[$]");
		Alumno alumno = new Alumno (palabras[0],palabras[1],palabras[2],palabras[3],
				Integer.parseInt(palabras[4]));
		alumno.setNota(Double.parseDouble(palabras[5]));
		return alumno;
	}

	@Override
	public int getColumnCount() {
		
		return columnas.getColumnCount();
	}

	@Override
	public int getRowCount() {
		
		return listaAlumnos.size();
	}

	@Override
	public Object getValueAt(int fila, int columna) {
		Alumno a = listaAlumnos.get(fila);
		return a.getFieldAt(columna);
		
	}
		
	@Override
	public boolean isCellEditable(int rowIndex, int columnIndex) {
		if (columnIndex == 3) return true;
		return false;
	}
	@Override
	public Class<?> getColumnClass(int columnIndex) {
		
		return getValueAt(0,columnIndex).getClass();
	}

}
