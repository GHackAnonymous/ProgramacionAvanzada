package properties.properties;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Container;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Properties;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class PantallaPrincipal implements ActionListener{
	final String FICH_PROPIEDADES = "propiedades.txt";
	JLabel lValor;
	int contador;
	JButton bInc;
	JButton bDec;
	Properties propiedades;
	public PantallaPrincipal(){
		JFrame pantalla = new JFrame("Cuenta Clicks");
		try {
			propiedades = new Properties();
			propiedades.load(new FileReader(FICH_PROPIEDADES));
		} catch (FileNotFoundException e) {
			System.out.println("Se utilizar�n las propiedades por defecto");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		contador = 0;
		pantalla.setSize(300, 400);
		pantalla.setLocation(100,100);
		
		pantalla.setContentPane(crearPanelVentana());
		pantalla.setVisible(true);
		pantalla.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}

	private Container crearPanelVentana() {
		JPanel panel = new JPanel(new BorderLayout(0,10));
		panel.setBorder(BorderFactory.createEmptyBorder(10,20,10,20));
		lValor = new JLabel(String.valueOf(contador));
		
		lValor.setFont(new Font(propiedades.getProperty("font","arial"),Font.BOLD,
				Integer.valueOf(propiedades.getProperty("tama�o","146"))));
		lValor.setForeground(obtenerColor(propiedades.getProperty("colornumero", "rojo")));
		lValor.setHorizontalAlignment(JLabel.CENTER);
		lValor.setBackground(obtenerColor(propiedades.getProperty("colorfondo", "blanco")));
		lValor.setOpaque(true);
		panel.add(lValor,BorderLayout.CENTER);
		panel.add(crearPanelBotones(),BorderLayout.SOUTH);
	
		return panel;
	}

	private Color obtenerColor(String nombreColor) {
		Color color = Color.WHITE;
		switch (nombreColor){
		case "rojo": color = Color.RED; break;
		case "blanco": color = Color.WHITE;break;
		case "verde": color = Color.green;break;
		case "amarillo": color = Color.yellow;break;
		case "gris": color = Color.gray;break;
		case "azul": color = Color.blue;break;
		case "negro": color = Color.black;break;
		case "cyan": color = Color.CYAN;break;
 		}
		return color;
	}

	private Component crearPanelBotones() {
		JPanel panel = new JPanel(new GridLayout(1,2,10,0));
		panel.setBorder(BorderFactory.createCompoundBorder(
				BorderFactory.createLineBorder(obtenerColor(propiedades.getProperty("colorbordeBotones", "blanco"))),
				BorderFactory.createEmptyBorder(10,10,10,10)));
		bInc= new JButton ("Inc");
		bDec = new JButton("Dec");
		bInc.addActionListener(new ActionListener(){

			@Override
			public void actionPerformed(ActionEvent e) {
				int limiteSuperior = Integer.parseInt(propiedades.getProperty("limitesuperior","100"));
				if (contador == limiteSuperior){
					Toolkit.getDefaultToolkit().beep();
				}else{
					contador++;
					lValor.setText(String.valueOf(contador));
				}
				
				
			}
			
		});
		bInc.setActionCommand("inc");
		bDec.addActionListener(this);
		bDec.setActionCommand("dec");
		panel.add(bInc);
		panel.add(bDec);
		return panel;
	}

	public static void main(String[] args) {
		PantallaPrincipal programa = new PantallaPrincipal();
		System.out.println("adios");
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		
		switch (e.getActionCommand()){
		case "inc" : int limiteSuperior = Integer.parseInt(propiedades.getProperty("limitesuperior","100"));
					if (contador == limiteSuperior){
						Toolkit.getDefaultToolkit().beep();
					}else{
						contador++;
						lValor.setText(String.valueOf(contador));
					}
					break;
		case "dec" :int limiteInferior = Integer.parseInt(propiedades.getProperty("limiteinferior","-25"));
					if (contador == limiteInferior){
						Toolkit.getDefaultToolkit().beep();
					}else{
						contador--;
						lValor.setText(String.valueOf(contador));
					} 
					break;
		default: System.out.println("error");
		}
		lValor.setText(String.valueOf(contador));
	}

	
}
