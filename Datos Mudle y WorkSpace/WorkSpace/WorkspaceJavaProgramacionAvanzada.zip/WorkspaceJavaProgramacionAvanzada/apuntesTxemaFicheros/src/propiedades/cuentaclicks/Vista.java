package propiedades.cuentaclicks;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Container;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Observable;
import java.util.Observer;
import java.util.Properties;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.Timer;

public class Vista implements Observer,ActionListener{
	static final String FICH_PROPIEDADES = "propiedades.properties";
	
	Properties propiedades;
	
	JFrame ventana;
	JLabel texto;
	JButton botonInc,botonDec;
	
	static int numIntervalo = 0;
	Modelo modelo;
	Controlador controlador;
	
	int fontSize;
	int delay;
	int numIntervalos;
	Timer timer;
	
	public Vista(Modelo modelo,int posX,int posY){
		leerPropiedades();
		numIntervalos =Integer.valueOf( propiedades.getProperty("numIntervalos","1"));
		ventana = new JFrame("CuentaClicks");
		
		this.modelo = modelo;
		modelo.addObserver(this);
		
		controlador = new Controlador(this,modelo);
		ventana.setLocation(posX,posY);
		ventana.setSize(300, 400);
		
		ventana.setContentPane(crearPanelVentana());
		ventana.setVisible(true);
		ventana.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		
	}

	private void leerPropiedades() {
		try {
			propiedades = new Properties();
			propiedades.load(new FileReader(FICH_PROPIEDADES));
		} catch (FileNotFoundException e) {
			System.out.println("Se utilizar�n las propiedades por defecto");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

	private Container crearPanelVentana() {
		Color colorFondo;
		Color colorTexto;
		colorFondo =new Color(Integer.decode(propiedades.getProperty("backGroundColor", "0x000000")));
		colorTexto =new Color(Integer.decode(propiedades.getProperty("foreGroundColor", "0xFFFFFF")));
		fontSize = Integer.valueOf(propiedades.getProperty("fontSize", "10"));
		
		JPanel panel  = new JPanel(new BorderLayout(10,20));
		panel.setBorder(BorderFactory.createEmptyBorder(10,20,10,20));
		texto = new JLabel (String.valueOf(modelo.getContador()));
		texto.setFont(new Font ("Arial", Font.BOLD, fontSize));
		texto.setHorizontalAlignment(JLabel.CENTER);
		texto.setForeground(colorTexto);
		texto.setBackground(colorFondo);
		texto.setOpaque(true);
		texto.setBorder(BorderFactory.createCompoundBorder(
				BorderFactory.createTitledBorder("Contador"),
				BorderFactory.createLineBorder(Color.red)));
		
		panel.add(texto, BorderLayout.CENTER);
		panel.add(crearPanelBotones(),BorderLayout.SOUTH);
		
		return panel;
	}
	
	private Component crearPanelBotones() {
		JPanel panel = new JPanel(new GridLayout(1,2,20,0));
		botonInc = new JButton ("Incrementar");
		botonInc.addActionListener(controlador);
		botonInc.setActionCommand("Incrementar");
		botonDec = new JButton ("Decrementar");
		botonDec.addActionListener(controlador);
		botonDec.setActionCommand("Decrementar");
		panel.add(botonInc);
		panel.add(botonDec);
		
		return panel;
	}

	@Override
	public void update(Observable modelo, Object objeto) {
		if (modelo instanceof Modelo){
			Modelo contador = (Modelo) modelo;
			numIntervalo = 0;
			if (timer != null){
				timer.stop();
				timer = null;
			}
			delay = Integer.valueOf(propiedades.getProperty("delay","1000"));
			timer = new Timer(delay,this);
			timer.start();
		}
		
	}

	public static void main(String[] args) {
		Modelo modelo = new Modelo();
		Vista programa = new Vista(modelo,100,100);
		
	}

	

	@Override
	public void actionPerformed(ActionEvent arg0) {
		
		texto.setFont(new Font ("Arial", Font.BOLD, (fontSize/numIntervalos)*numIntervalo));
		texto.setText (String.valueOf(modelo.getContador()));
		if (numIntervalo++ >= numIntervalos){
			timer.stop();
			timer = null;
		};
	}

	
	

}
