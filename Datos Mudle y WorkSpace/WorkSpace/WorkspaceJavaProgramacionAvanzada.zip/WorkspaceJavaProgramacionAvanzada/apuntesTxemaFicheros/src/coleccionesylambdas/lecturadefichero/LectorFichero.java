package coleccionesylambdas.lecturadefichero;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.stream.Stream;

public class LectorFichero {
	String path = "./files";
	String file = "alumnos.txt";
	Clase clase;
	public LectorFichero(){
		clase = new Clase();
	}
/*	public void leerClaseFichero(){
		
		String patron = "[$]";
		try (Stream<String> lineas = Files.lines(Paths.get(path,file))){
			lineas.forEach(linea -> {
				String [] valores = linea.split(patron);
				Alumno alumno = new Alumno(Integer.valueOf(valores[0]),valores[1],valores[2],
						valores[3],valores[4],Double.valueOf(valores[5]));
				
				clase.a�adir(alumno);
			});
			
		}catch (IOException e){
			System.out.println("No se encuentra el fichero de alumnos");
		}catch (IndexOutOfBoundsException e){
			System.out.println("Los datos del fichero no son correctos");
		}
		
	}
*/
public void leerClaseFichero(){
		
		String patron = "[$]";
		try (Stream<String> lineas = Files.lines(Paths.get(path,file))){
			lineas.forEach(linea -> clase.a�adir(new Alumno(linea.split(patron))));
		}catch (IOException e){
			System.err.println("No se encuentra el fichero de alumnos");
		}catch (IndexOutOfBoundsException | NumberFormatException e){
			System.err.println("Los datos del fichero no son correctos");
		}
		
	}
	
	
	public void verClase(){
		clase.getListaAlumnos().stream()
		.forEach(System.out::println);
	}
	public static void main(String[] args) {
		LectorFichero lector = new LectorFichero();
		lector.leerClaseFichero();
		lector.verClase();
	}

}
