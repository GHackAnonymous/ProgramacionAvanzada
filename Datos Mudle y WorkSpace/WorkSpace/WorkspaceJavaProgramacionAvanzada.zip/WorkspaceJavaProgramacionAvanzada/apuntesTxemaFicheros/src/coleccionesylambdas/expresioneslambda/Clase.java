package coleccionesylambdas.expresioneslambda;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;

public class Clase {
	
	String nombre;
	List<Alumno> listaAlumnos;
	Iterator<Alumno> iterator;
	
	public Clase (String nombre, int maxAlumnos){
		this.nombre = nombre;
		listaAlumnos = new ArrayList<>();
	}
	
	public boolean a�adir (Alumno alumno){
		listaAlumnos.add(alumno);
		return true;
	}
	
	
	public Alumno [] getAlumnos(){
		
		return listaAlumnos.toArray(new Alumno[0]);
	}

	public void getOrdenados(Comparator<Alumno> comparador) {
		Collections.sort(listaAlumnos,comparador);
		
	}

	public boolean vacia() {
		
		return listaAlumnos.isEmpty();
	}

	public void irPrimero() {
		iterator = listaAlumnos.listIterator();
		
	}

	public Alumno getAlumno() {
		
		return iterator.next();
	}

	public void irSS() {
		
		
	}

	public boolean fin() {
		
		return !iterator.hasNext();
	}
}
