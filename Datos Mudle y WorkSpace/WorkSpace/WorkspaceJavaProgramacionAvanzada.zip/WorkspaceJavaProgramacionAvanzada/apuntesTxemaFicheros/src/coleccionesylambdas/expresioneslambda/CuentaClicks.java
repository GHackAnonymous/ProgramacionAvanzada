package coleccionesylambdas.expresioneslambda;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;

public class CuentaClicks {
	
	JFrame ventana;
	JButton boton;
	JLabel texto;
	int contador;
	
	public CuentaClicks(){
		contador = 0;
		ventana = new JFrame("Cuenta cliks");
		ventana.setLocation (100,100);
		ventana.setSize(200, 400);
		
		texto = new JLabel(String.valueOf(contador));
		texto.setFont(new Font("Arial",Font.BOLD, 70));
		texto.setForeground(Color.RED);
		texto.setHorizontalAlignment(JLabel.CENTER);
		boton = new JButton("Clickame");
		boton.addActionListener(e -> {
				contador++;
				texto.setText(String.valueOf(contador));
		});
		ventana.add (texto);
		ventana.add (boton, BorderLayout.SOUTH);
		
		ventana.setVisible(true);
		ventana.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}

	public static void main(String[] args) {
		CuentaClicks programa = new CuentaClicks();
	
		try {
			UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
		} catch (UnsupportedLookAndFeelException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (InstantiationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IllegalAccessException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}
