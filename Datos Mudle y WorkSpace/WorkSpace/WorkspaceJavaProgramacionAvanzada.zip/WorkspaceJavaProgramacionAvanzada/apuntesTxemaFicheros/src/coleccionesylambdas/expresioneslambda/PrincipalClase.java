package coleccionesylambdas.expresioneslambda;


import java.util.Comparator;
import java.util.Scanner;

public class PrincipalClase {
	final String NOMBRECLASE = "2� INFOR + TELECOS";
	final int NUMALUMNOS = 50;
	Clase clase;
	Scanner teclado;
	
	public PrincipalClase(){
		clase = new Clase(NOMBRECLASE,NUMALUMNOS);
		teclado = new Scanner (System.in);
	}
	public int menu (){
		int opcion;
		System.out.println("1.- A�adir alumno");
		System.out.println("2.- Meter notas");
		System.out.println("3.- Ver lista alumnos");
		System.out.println("4.- Ordenar por nombre");
		System.out.println("5.- Ordenar por apellido");
		System.out.println("6.- Ordenar por nota");
		
		System.out.println("0.- Salir");
		System.out.print("Seleccione opci�n: ");
		
		opcion = teclado.nextInt();	
		return opcion;
	}
	
	public void gestionarNotas(){
		int opcion;
		Comparator<Alumno> porNombre = (a,b)->a.getNombre().compareTo(b.getNombre());
		Comparator<Alumno> porApellido = (a,b)->a.getApellido().compareTo(b.getApellido());
		Comparator<Alumno> porNota = (a,b)->(int) (a.getNota()-b.getNota());
		
		do{
			opcion = menu();
			switch (opcion){
			case 1: anadirAlumno(); break;
			case 2: meterNotas(); break;
			case 3: verLista(); break;
			case 4: clase.getOrdenados(porNombre);break;
			case 5: clase.getOrdenados(porApellido); break;
			case 6: clase.getOrdenados(porNota);
			case 0: break;
			default: System.out.println("Opcion no valida");
			}

		}while (opcion != 0);
/*		
		do{
			opcion = menu();
			switch (opcion){
			case 1: anadirAlumno(); break;
			case 2: meterNotas(); break;
			case 3: verLista(); break;
			case 4: clase.getOrdenados((a,b)->a.getNombre().compareTo(b.getNombre()));break;
			case 5: clase.getOrdenados((a,b)->a.getApellido().compareTo(b.getApellido())); break;
			case 6: clase.getOrdenados((a,b)->(int) (a.getNota()-b.getNota()));
			case 0: break;
			default: System.out.println("Opcion no valida");
			}

		}while (opcion != 0);
*/	
	}

	
	private void verLista() {
		Alumno [] lista = clase.getAlumnos();
		for (Alumno alumno: lista){
			System.out.println();
			System.out.println(alumno);
			System.out.println();
		}
		
	}
	private void meterNotas() {
		if (clase.vacia()){
			System.out.println("No hay alumnos en la clase");
			return;
		}
		clase.irPrimero();
		do{
			Alumno alumno = clase.getAlumno();
			meterNotaAlumno(alumno);
			clase.irSS();
			
		}while (!clase.fin());
		
	}
	private void meterNotaAlumno(Alumno alumno) {
		double nota;
		System.out.println();
		System.out.print("Nota del alumno " + alumno.getNombre()+" "+ alumno.getApellido());
		nota = teclado.nextDouble();
		alumno.setNota(nota);
	}
	private void anadirAlumno() {
		Alumno alumno = leerAlumno();
		if ( !clase.a�adir(alumno)){
			System.out.println("La clase esta llena");
		}
	}
	private Alumno leerAlumno() {
		int idal;
		String nombre, apellido;
		Alumno alumno;
		
		System.out.println();
		System.out.print("Idal: ");
		idal = teclado.nextInt(); teclado.nextLine();
		System.out.print("Nombre: ");
		nombre = teclado.nextLine();
		System.out.print("Apellido: ");
		apellido = teclado.nextLine();
		
		alumno = new Alumno (idal, nombre, apellido);
		return alumno;
	}
	public static void main(String[] args) {
		PrincipalClase programa = new PrincipalClase();
		programa.gestionarNotas();

	}

}
