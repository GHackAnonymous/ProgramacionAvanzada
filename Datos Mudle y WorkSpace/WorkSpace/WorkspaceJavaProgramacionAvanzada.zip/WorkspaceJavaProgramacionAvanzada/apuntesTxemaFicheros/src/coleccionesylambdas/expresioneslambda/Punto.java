package coleccionesylambdas.expresioneslambda;

public class Punto {
  double coordenadaX;
  double coordenadaY;

  static int numPuntos = 0;
  
  public Punto(){
	  coordenadaX= 0.0;
	  coordenadaY = 0.0;
	  numPuntos++;
  }
  public Punto (double valorX, double valorY){
	  coordenadaX = valorX;
	  coordenadaY = valorY;
  }
  
  public Punto(int valorX,int valorY){
	  coordenadaX = (double)valorX;
	  coordenadaY = (double) valorY;
	  numPuntos++;
  }
  public double getCoordenadaX() {
	return coordenadaX;
}
public void setCoordenadaX(double coordenadaX) {
	this.coordenadaX = coordenadaX;
}
public double getCoordenadaY() {
	return coordenadaY;
}
public void setCoordenadaY(double coordenadaY) {
	this.coordenadaY = coordenadaY;
}
  public void mover (Punto p){
	  coordenadaX = p.coordenadaX;
	  coordenadaY = p.coordenadaY;
  }
  
  public double distancia (Punto p){
	 return Math.sqrt(Math.pow((this.coordenadaX-p.coordenadaX), 2.0)+Math.pow(this.coordenadaY-p.coordenadaY, 2.0));
  }
  static int getNumPuntos(){
	  return numPuntos;
  }
  public void mover (double newX, double newY){
	  coordenadaX = newX;
	  coordenadaY = newY;
  }
  public void mover (int newX,int newY){
	 coordenadaX = (double) newX;
	 coordenadaY = (double) newY;
  }
  @Override
  public String toString(){
	  return "("+coordenadaX+","+coordenadaY+")";
  }
}
