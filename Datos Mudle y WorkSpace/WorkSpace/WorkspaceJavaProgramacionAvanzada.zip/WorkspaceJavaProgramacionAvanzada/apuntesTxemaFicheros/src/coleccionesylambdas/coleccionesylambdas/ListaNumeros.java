package coleccionesylambdas.coleccionesylambdas;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Random;
import java.util.stream.Collectors;

public class ListaNumeros {
	final int NUMNUMEROS = 10;
	List<Integer> lista = new ArrayList<>();
	Random generador = new Random();
	List<String> nombres = Arrays.asList("Ander","Aitor","Borja");
	
	public void inicializar(){
		for (int i= 0; i<NUMNUMEROS; i++){
			lista.add(generador.nextInt(100));
		}
	}
	public void verLista(){
		lista.forEach(System.out::println);
		System.out.println();
	}
	public void filtrarImpares(){
		lista.stream().
		filter(num -> (num%2 != 0))
		.forEach(num->System.out.println(num));
	}
	public void sumarPares(){
		System.out.println("La suma de los n�meros pares es: " +
	    lista.stream()
		.filter(num -> (num%2 == 0))
		.mapToInt(num -> num)
		.sum());
	}
	public void anadir(String nombre){
		nombres.add(nombre);
	}
	public List<String> filtrarNombres(String letra){
		return nombres.stream()
		.filter(nombre -> nombre.startsWith(letra))
		.collect(Collectors.toList());
	}
	public void escribirNombres(){
		System.out.println(String.join(",",nombres));
	}
	public static void main(String[] args) {
		ListaNumeros programa = new ListaNumeros();
		programa.inicializar();
		programa.verLista();
		programa.filtrarImpares();
		programa.sumarPares();
		
		List<String> lista = programa.filtrarNombres("A");
		lista.forEach(System.out::println);
		programa.escribirNombres();
	}

}
