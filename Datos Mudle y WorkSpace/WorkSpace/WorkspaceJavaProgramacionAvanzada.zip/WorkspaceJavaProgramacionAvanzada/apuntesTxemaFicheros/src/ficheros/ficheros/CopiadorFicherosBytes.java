package ficheros.ficheros;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

public class CopiadorFicherosBytes {
	static final String ORIGEN = "origen/delfin.jpg";
	static final String DESTINO = "destino/copiadelfin.jpg";
	
	public static void main(String[] args) {
		int b;
		
		try (FileInputStream in = new FileInputStream (ORIGEN);
			 FileOutputStream out= new FileOutputStream (DESTINO)){
			
			while ((b=in.read())!=-1){
				out.write(b);
			}
		} catch (FileNotFoundException e) {
			
			System.out.println("No existe el fichero "+ ORIGEN);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}
}
