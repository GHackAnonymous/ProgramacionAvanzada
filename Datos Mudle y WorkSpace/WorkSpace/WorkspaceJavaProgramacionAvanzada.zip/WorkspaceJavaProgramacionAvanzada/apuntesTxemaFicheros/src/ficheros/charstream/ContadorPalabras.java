package ficheros.charstream;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

public class ContadorPalabras {
   
   Map <String, Integer> diccionario = new HashMap<>();
   File texto;
   public 	ContadorPalabras(File texto) {
	  
		this.texto = texto;;
   }
   public Map<String, Integer> contarPalabras(){
	   
		String linea;
		try (BufferedReader in = new BufferedReader (new FileReader(texto))) {
			
			while ((linea = in.readLine())!=null){
				String [] palabras = linea.toLowerCase().split("[^a-z^�^�^�^�^�]");
				
				for (String palabra: palabras){
					if (palabra.length()>0){
						contarPalabra(palabra);
					}
				}
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
		return diccionario;
   }

	private void contarPalabra(String palabra) {
		
		Integer numVeces = diccionario.get(palabra);
        diccionario.put(palabra, (numVeces == null) ? 1 : numVeces + 1);
	}
}
