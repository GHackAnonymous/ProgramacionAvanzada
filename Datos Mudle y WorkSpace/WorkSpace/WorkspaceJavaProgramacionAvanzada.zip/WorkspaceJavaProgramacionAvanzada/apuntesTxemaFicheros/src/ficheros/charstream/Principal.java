package ficheros.charstream;

import java.io.File;
import java.io.IOException;

public class Principal {

	public static void main(String[] args) {
		File origen = new File ("origen/texto.txt");
		File destino = new File ("destino/copia.txt");
		try {
			CopiadorFicherosTexto copiador = new CopiadorFicherosTexto (origen,destino);
			System.out.println ("N�mero de caracteres copiados: "+copiador.copiar());
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
