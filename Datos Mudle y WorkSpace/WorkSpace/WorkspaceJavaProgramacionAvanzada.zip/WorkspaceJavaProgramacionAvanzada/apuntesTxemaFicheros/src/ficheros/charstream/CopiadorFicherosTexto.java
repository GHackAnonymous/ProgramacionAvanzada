package ficheros.charstream;

import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class CopiadorFicherosTexto {
	FileReader in;
	FileWriter out;
	
	public CopiadorFicherosTexto (File ficheroOrigen, File ficheroDestino) throws IOException{
		in = new FileReader (ficheroOrigen);
		out = new FileWriter (ficheroDestino);
	}
	
	public int copiar(){
		int c;
		int contador= 0;
		try {
			while ((c = in.read())!=-1){
				out.write(c);
				contador++;
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			try{
				if (in!=null) in.close();
				if (out!=null) out.close();
			}catch (IOException e){}
		}
		return contador;
	}
}
