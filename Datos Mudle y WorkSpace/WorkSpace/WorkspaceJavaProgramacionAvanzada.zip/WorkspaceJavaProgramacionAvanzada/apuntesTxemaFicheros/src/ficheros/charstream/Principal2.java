package ficheros.charstream;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

public class Principal2 {

	
	public static void main(String[] args) {
		File texto = new File ("origen/texto.txt");
		

			ContadorPalabras contador = new ContadorPalabras (texto);
			
			Map<String,Integer> diccionario = contador.contarPalabras();
			Set<Map.Entry<String,Integer>> setPalabras = diccionario.entrySet();
			List<Map.Entry<String,Integer>> listaPalabras = new ArrayList<>(setPalabras);
			Collections.sort(listaPalabras, new Comparator<Map.Entry<String,Integer>>(){

				@Override
				public int compare(Entry<String, Integer> e1,
						Entry<String, Integer> e2) {
					
					return e1.getKey().compareTo(e2.getKey());
				}
				
			});
			for (Map.Entry<String, Integer> palabra : listaPalabras)
			    System.out.println(palabra.getKey() + ": " + palabra.getValue());
		
	}

}
