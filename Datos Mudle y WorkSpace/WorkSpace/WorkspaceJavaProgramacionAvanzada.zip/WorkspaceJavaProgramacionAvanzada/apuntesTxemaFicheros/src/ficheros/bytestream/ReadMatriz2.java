package ficheros.bytestream;


/* 
 * Programa que lee una matriz como un stream de bytes utilizando la clase
 * DataInputStream envolviendo un FileInputStream
 */
import java.io.*;

public class ReadMatriz2 {
	static double matriz [][];

	public static void main(String[] args) {

		String nombreFichero = "matriz2.dat";
		int filas; 
		int columnas; 
		DataInputStream in = null;
	
		try{
			in = new DataInputStream(
					new FileInputStream(nombreFichero));
			filas = in.readInt();
			System.out.println("filas = "+ filas);
			columnas = in.readInt();
			System.out.println("columnas = "+columnas);
		
			matriz = new double [filas][columnas];
		
			for (int i=0; i<filas; i++){
				for(int j=0; j<columnas; j++){
					matriz[i][j]=in.readDouble();
					System.out.println("matriz["+i+"] ["+j+"] = "+ matriz[i][j]);
				}
			}
			
		
		}catch (IOException e ){
			
			System.out.println("Error leyendo el fichero "+nombreFichero);
			System.out.println("Erro: "+e.getMessage());
		}finally{
			if (in!=null){
				try {
					in.close();
				} catch (IOException e) {
					System.out.println("No se ha podido cerrar el fichero");
				}
			} 
		}

	}

}

