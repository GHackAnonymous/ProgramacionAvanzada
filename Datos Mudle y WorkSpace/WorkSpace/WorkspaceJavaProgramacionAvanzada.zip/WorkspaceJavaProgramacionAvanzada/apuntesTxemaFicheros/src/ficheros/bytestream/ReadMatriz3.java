package ficheros.bytestream;

/*
 * programa que lee una matriz de un stream de bytes utilizando la clase
 * DataInputStream sobre un BufferedInputStream
 */
import java.io.*;


public class ReadMatriz3 {
	static double matriz [][];

	public static void main(String[] args) {

		String nombreFichero = "matriz3.dat";
		int filas; 
		int columnas; 
	
	
		try(DataInputStream in = new DataInputStream(
				new FileInputStream(nombreFichero))){
			
			
			filas = in.readInt();
			System.out.println("filas = "+ filas);
			columnas = in.readInt();
			System.out.println("columnas = "+columnas);
		
			matriz = new double [filas][columnas];
		
			for (int i=0; i<filas; i++){
				for(int j=0; j<columnas; j++){
					matriz[i][j]=in.readDouble();
					System.out.println("matriz["+i+"] ["+j+"] = "+ matriz[i][j]);
				}
			}
		}catch (IOException e ){} 

	}


}
