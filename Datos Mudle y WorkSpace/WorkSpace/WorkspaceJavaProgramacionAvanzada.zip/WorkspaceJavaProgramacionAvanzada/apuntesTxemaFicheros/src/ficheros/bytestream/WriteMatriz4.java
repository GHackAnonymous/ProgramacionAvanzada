package ficheros.bytestream;

/*
 * programa que escribe una matriz utilizando un ObjectOutputStream que recubre
 * un FileOuputStream
 * 
 */
import java.io.*;

public class WriteMatriz4 {
	static double [][] matriz = {
		{Math.exp(2.0),Math.exp(3.0),Math.exp(4.0)},
		{Math.exp(-2.0),Math.exp(-3.0),Math.exp(-4.0)}
	};

	public static void main(String[] args) {
		String nombreFichero = "matriz4.dat";
		int filas = matriz.length;
		int columnas = matriz[0].length;

		int i,j;
		for (i=0; i<filas; i++){
			for(j=0; j<columnas; j++){
					System.out.println("matriz["+i+"] ["+j+"] = "+ matriz[i][j]);
			}
		}
		try(ObjectOutputStream out = new ObjectOutputStream(
				new FileOutputStream(nombreFichero))){
			
			
			
			/* no necesario porque no hace falta conocer la dimension
			 * 
			* out.writeInt (filas);
			* out.writeInt (columnas);
			*/
			out.writeObject( matriz);
			
			
	
		}catch (IOException e ){} 
	}


}
