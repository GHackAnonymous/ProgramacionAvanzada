package ficheros.bytestream;

/*
 * Programa que lee una Matriz como un Stream de bytes utilizando un
 * FileInputStream.
 * Crea dos funciones propias leerDouble y leerInt para transformar
 * el array de bytes leido en los tipos b�sicos double e int
 * 
 */
import java.io.*;

public class ReadMatriz1 {

	static double matriz [][];
	public static void main(String[] args) {
		String nombreFichero = "matriz1.dat";
		int filas; 
		int columnas; 
		FileInputStream in = null;
		
		try{
			in = new FileInputStream(nombreFichero);
			filas = leerInt (in);
			System.out.println("filas = "+ filas);
			columnas = leerInt (in);
			System.out.println("columnas = "+columnas);
			
			matriz = new double [filas][columnas];
			
			for (int i=0; i<filas; i++){
				for(int j=0; j<columnas; j++){
					 matriz[i][j]=leerDouble(in);
					 System.out.println("matriz["+i+"] ["+j+"] = "+ matriz[i][j]);
				}
			}
			
			
		}catch (IOException e ){
			
			System.out.println("Error leyendo el fichero "+nombreFichero);
			System.out.println("Erro: "+e.getMessage());
		}finally{
			if (in!=null){
				try {
					in.close();
				} catch (IOException e) {
					System.out.println("No se ha podido cerrar el fichero");
				}
			}
		}

		

	}
	private static double leerDouble(FileInputStream in)
	throws IOException {
		byte[] buff = new byte [8];
		in.read (buff);
		long l = 0;
		for (int k = 0; k<8; k++){
			l <<= 8;
			l +=(((int) buff[k]&0xFF));
		}
		return Double.longBitsToDouble(l);
		

	}
	private static int leerInt(FileInputStream in) 
		throws IOException {
		
			byte[] buff = new byte [4];
			in.read (buff);
			int i = 0;
			for (int k = 0; k<4; k++){
				i <<= 8;
				i +=(((int) buff[k]&0xFF));
			}
			return i;
	}

}
