package ficheros.bytestream;

/*
 * Programa que lee una matriz utilizando un ObjectInputStream que recubre
 * un FileOutpuStream
 */
import java.io.*;

public class ReadMatriz4 {
	static double matriz [][];

	public static void main(String[] args) {

		String nombreFichero = "matriz4.dat";
		int filas; 
		int columnas; 
		ObjectInputStream in = null;
	
		try{
			in = new ObjectInputStream(
						new FileInputStream(nombreFichero));
			
			matriz = (double [][])in.readObject();
			
			filas = matriz.length;
			System.out.println("filas = "+ filas);
			columnas = matriz[0].length;
			System.out.println("columnas = "+columnas);
		
			for (int i=0; i<filas; i++){
				for(int j=0; j<columnas; j++){
					System.out.println("matriz["+i+"] ["+j+"] = "+ matriz[i][j]);
				}
			}
			
		
		}catch (ClassNotFoundException e){
			System.out.println("No se puede hacer casting a double [][]");
		}catch (IOException e ){
			
			System.out.println("Error leyendo el fichero "+nombreFichero);
			System.out.println("Erro: "+e.getMessage());
		}finally{
			if (in!=null){
				try {
					in.close();
				} catch (IOException e) {
					System.out.println("No se ha podido cerrar el fichero");
				}
			} 
		}

	}
}
