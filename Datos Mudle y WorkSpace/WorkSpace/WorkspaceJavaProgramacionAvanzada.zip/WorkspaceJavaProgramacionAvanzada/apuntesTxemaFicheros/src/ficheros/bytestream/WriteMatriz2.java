package ficheros.bytestream;

/* 
 * Programa que escribe una matriz como un stream de bytes utilizando la clase
 * DataOutputStream envolviendo un FileOuputStream
 */
import java.io.*;

public class WriteMatriz2 {
	static double [][] matriz = {
		{Math.exp(2.0),Math.exp(3.0),Math.exp(4.0)},
		{Math.exp(-2.0),Math.exp(-3.0),Math.exp(-4.0)}
	};

	public static void main(String[] args) {
		String nombreFichero = "matriz2.dat";
		int filas = matriz.length;
		int columnas = matriz[0].length;

		int i,j;
		for (i=0; i<filas; i++){
			for(j=0; j<columnas; j++){
					System.out.println("matriz["+i+"] ["+j+"] = "+ matriz[i][j]);
			}
		}
		try (DataOutputStream out = new DataOutputStream(
				new FileOutputStream(nombreFichero))){
			
			
			
			out.writeInt (filas);
			out.writeInt (columnas);
			for (i=0; i<filas; i++){
				for(j=0; j<columnas; j++){
					out.writeDouble( matriz[i][j]);
				}
			}
		}catch (IOException e ){}
		
	}

}
