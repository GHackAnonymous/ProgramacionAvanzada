package ficheros.bytestream;

/*
 * Programa que escribe una Matriz como un Stream de bytes utilizando un
 * FileOutputStream.
 * Crea dos funciones propias escribirDouble y escribirInt para transformar
 * el tipo b�sico int y double en un array de bytes a escribir
 */
import java.io.*;

public class WriteMatriz1 {
	
	static double [][] matriz = {
		{Math.exp(2.0),Math.exp(3.0),Math.exp(4.0)},
		{Math.exp(-2.0),Math.exp(-3.0),Math.exp(-4.0)}
};

public static void main(String[] args) {
String nombreFichero = "matriz1.dat";
int filas = matriz.length;
int columnas = matriz[0].length;

int i,j;
FileOutputStream out= null;

for (i=0; i<filas; i++){
	for(j=0; j<columnas; j++){
		System.out.println("matriz["+i+"] ["+j+"] = "+ matriz[i][j]);
	}
}
try{
	out = new FileOutputStream(nombreFichero);
	escribirInt (filas,out);
	escribirInt (columnas,out);
	for (i=0; i<filas; i++){
		for(j=0; j<columnas; j++){
			escribirDouble( matriz[i][j],out);
		}
	}
	
	
}catch (IOException e ){
	e.printStackTrace();
} finally{
	if (out!= null)
		try {
			out.close();
		} catch (IOException e) {}
}
}

	private static void escribirDouble(double d, FileOutputStream out) 
		throws IOException{
			
		byte[] buff = new byte [8];
		long l = Double.doubleToLongBits(d);
		for (int k = 7; k>=0; k--){
			buff[k]= (byte)  l;//(l&0xFF);
			l>>>= 8;                      //unsigned shift right
		}
		out.write(buff);
		
	}

	private static void escribirInt(int i, FileOutputStream out)
throws IOException{
		
		byte[] buff = new byte [4];
		for (int k = 3; k>=0; k--){
			buff[k]= (byte) i;// (i&0xFF);
			i>>>= 8;
		}
		out.write(buff);
	}

}
