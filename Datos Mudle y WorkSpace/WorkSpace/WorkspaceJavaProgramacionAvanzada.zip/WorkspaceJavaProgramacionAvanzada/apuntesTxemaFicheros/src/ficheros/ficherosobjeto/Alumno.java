package ficheros.ficherosobjeto;

import java.io.Serializable;

public class Alumno implements Serializable{

	
	int id;
	String nombre;
	String apellido1;
	String apellido2;
	String poblacion;
	double nota;
	
	public Alumno (int id,String nombre, String apellido1, String apellido2,String poblacion){
		this.id = id;
		this.nombre = nombre;
		this.apellido1 = apellido1;
		this.apellido2 = apellido2;
		this.poblacion = poblacion;
		this.nota = 0.0;
	}

	public int getId() {
		return id;
	}

	public String getNombre() {
		return nombre;
	}

	public String getApellido1() {
		return apellido1;
	}

	public String getApellido2() {
		return apellido2;
	}

	public String getPoblacion() {
		return poblacion;
	}

	public double getNota() {
		return nota;
	}

	public void setNota(double nota) {
		this.nota = nota;
	}
	@Override
	public String toString() {
		
		return id + " "+ nombre+ " "+ apellido1+" "+ apellido2+" "+poblacion;
	}

}
