package ficheros.ficherosobjeto;

import java.io.EOFException;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.Random;

public class GestorFichero {
	final int MAXALUMNOS = 50;
	public final String nombres [] = {"Txema","Ane","Marta", "Asier","Andoni","Ines","Jon","Alberto","Joanes","Luis"};
	public final String apellidos[] = {"Perez", "Iturrioz", "Apaolaza","Rivas","Huertos","Lombardo", "Era�a", "Ruiz","Iturbe","Igartua"};
	public final String poblaciones[] = {"Arrasate","Bergara","Donosti","Bilbo","Vitoria","Aretxabaleta","Eskoriatza","O�ati","Durango","Basauri"};
	
	
	public void crearFicheroConDatos(String nombreFichero){
		ObjectOutputStream out = null;
		Random generador = new Random();
		try {
			out = new ObjectOutputStream ( new FileOutputStream("files/"+nombreFichero));
			for (int i = 0; i< MAXALUMNOS; i++){
				Alumno a = new Alumno (i+1,nombres[generador.nextInt(10)],apellidos[generador.nextInt(10)],
						apellidos[generador.nextInt(10)],poblaciones[generador.nextInt(10)]);
				a.setNota(generador.nextDouble()*10);
				out.writeObject(a);
			}
			
		} catch (FileNotFoundException e) {
			
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			if (out!=null){
				try { out.close(); } catch (IOException e) {}
			}
		}
	}
	
	public void mostrarDatosFichero(String nombreFichero){
		ObjectInputStream in  = null;
		Alumno alumno;
		try {
			in = new ObjectInputStream(new FileInputStream("files/"+nombreFichero));
			
			while ((alumno = (Alumno)in.readObject())!=null){
				System.out.println(alumno);
			}
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}catch (EOFException e){
			
		}catch (IOException e) {
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}finally{
			if (in!= null){
				try { in.close(); } catch (IOException e) {}
			}
		}
	}
	public ArrayList<Alumno> buscarAlumnosPoblacion (String nombreFichero, String poblacion){
		ArrayList<Alumno> lista = new ArrayList<>();
		ObjectInputStream in  = null;
		Alumno alumno;
		try {
			in = new ObjectInputStream(new FileInputStream("files/"+nombreFichero));
			
			while ((alumno = (Alumno)in.readObject())!=null){
				if (alumno.getPoblacion().equals(poblacion)){
					lista.add(alumno);
				}
			}
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (EOFException e){
			
		}catch (IOException e) {
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}finally{
			if (in!= null){
				try { in.close(); } catch (IOException e) {}
			}
		}
		return lista;
	}
}
