package ficheros.ficherosobjeto;

import java.util.ArrayList;

public class Principal {

	public static void main(String[] args) {
		GestorFichero gestor = new GestorFichero();
		gestor.crearFicheroConDatos("alumnos.dat");
		gestor.mostrarDatosFichero("alumnos.dat");
		System.out.println();
		ArrayList<Alumno> lista = gestor.buscarAlumnosPoblacion("alumnos.dat", "Basauri");
		for (Alumno a: lista){
			System.out.println(a);
		}
	
	}

}
