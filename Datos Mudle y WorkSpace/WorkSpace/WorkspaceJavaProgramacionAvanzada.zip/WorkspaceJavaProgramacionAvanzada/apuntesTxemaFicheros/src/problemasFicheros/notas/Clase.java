package problemasFicheros.notas;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

import javax.swing.DefaultListModel;

public class Clase extends DefaultListModel<Alumno>{

	final String FICH_ALUMNOS = "alumnos.txt";
	final String SEPARADORDATOSALUMNO = "$";
	final String SEPARADORDATOSRESULTADOS = "&";
	String nombre;
	
	
	public Clase (String nombre){
		super();
		this.nombre = nombre;
		
	}


	public void inicializar() {
		BufferedReader in = null;
		String linea = null;
		String valoresAlumno [] = null;
		String valoresResultado[] = null;
		
		try {
			in = new BufferedReader (new FileReader(FICH_ALUMNOS));
			while ((linea = in.readLine())!=null){
				valoresAlumno = linea.split("["+this.SEPARADORDATOSALUMNO+"]");
				ListaResultadosAprendizaje resultados = new ListaResultadosAprendizaje();
				Alumno alumno = new Alumno(Integer.parseInt(valoresAlumno[0]), valoresAlumno[1],
						valoresAlumno[2],valoresAlumno[3],resultados);
				valoresResultado = valoresAlumno[4].split(this.SEPARADORDATOSRESULTADOS);
				
				for (int i = 0; i<valoresResultado.length; i++){
					alumno.getNotas().get(i).setNota(Float.parseFloat(valoresResultado[i]));
					
				}
				this.addElement(alumno);
			}
		} catch (FileNotFoundException e) {
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			if (in!= null){
				try { in.close();} catch (IOException e) {}
			}
		}
	}


	public void guardarEnFichero() {
		PrintWriter out = null;
		try {
			out = new PrintWriter(new FileWriter(FICH_ALUMNOS));
			for (int i = 0; i< this.getSize(); i++){
				out.println(this.getElementAt(i).escribir(this.SEPARADORDATOSALUMNO,this.SEPARADORDATOSRESULTADOS));
			}
				
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			if (out!=null){
				out.close();
			}
		}
		
		
	}
}
