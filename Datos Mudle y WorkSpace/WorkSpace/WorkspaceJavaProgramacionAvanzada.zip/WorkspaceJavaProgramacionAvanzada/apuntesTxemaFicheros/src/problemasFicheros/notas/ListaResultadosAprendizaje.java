package problemasFicheros.notas;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

import javax.swing.DefaultListModel;

public class ListaResultadosAprendizaje extends DefaultListModel<ResultadoAprendizaje>{
	final String FICH_RESULTADOS = "resultados.txt";
	
	
	public ListaResultadosAprendizaje(){
		super();
		inicializarListaResultados();
	}
	private void inicializarListaResultados() {
		String linea = null;
		String valores[] = null;
		BufferedReader in =null;
		try {
			
			in = new BufferedReader(new FileReader(FICH_RESULTADOS));
			while ((linea=in.readLine())!=null){
				valores = linea.split("[$]");
				this.addElement(new ResultadoAprendizaje(valores[0],valores[1]));
			}
		} catch (FileNotFoundException e) {
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			if (in!=null){
				try { in.close(); } catch (IOException e) {}
			}
		}
		
	}
	public String escribir(String separadorResultados) {
		String linea;
		linea = String.valueOf(this.getElementAt(0).getNota());
		for (int i= 1; i<this.getSize();i++){
			linea += separadorResultados+String.valueOf(this.getElementAt(i).getNota());
		}
		return linea;
	}
}
