public class Modelo{
	

	private final int CERVEZA = 3;
	private final int PINTXO = 2;
	private final int VINO = 1;
	
	public Modelo(){
	}

	public int getCERVEZA() {
		return CERVEZA;
	}

	public int getPINTXO() {
		return PINTXO;
	}

	public int getVINO() {
		return VINO;
	}
	
}
