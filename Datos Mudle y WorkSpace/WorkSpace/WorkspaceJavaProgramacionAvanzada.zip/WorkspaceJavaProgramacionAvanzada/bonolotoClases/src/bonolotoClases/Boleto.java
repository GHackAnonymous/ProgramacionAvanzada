package bonolotoClases;

public class Boleto {
	
	int[] boleto;
	
	public Boleto(){}
	public Boleto(int[] boleto){
		this.boleto = boleto;
	}

	public int[] getBoleto() {
		return boleto;
	}

	public void setBoleto(int[] boleto) {
		this.boleto = boleto;
	}
}
