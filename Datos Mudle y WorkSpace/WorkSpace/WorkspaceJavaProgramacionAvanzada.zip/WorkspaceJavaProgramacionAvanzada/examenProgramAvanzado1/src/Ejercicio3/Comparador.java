package Ejercicio3;

public interface Comparador {
	boolean comparar (Alumno a,String valor);
}
