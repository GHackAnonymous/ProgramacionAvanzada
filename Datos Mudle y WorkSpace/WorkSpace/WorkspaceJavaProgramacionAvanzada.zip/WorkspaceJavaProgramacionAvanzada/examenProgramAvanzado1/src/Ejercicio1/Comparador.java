package Ejercicio1;

public interface Comparador {
	boolean comparar (Alumno a,String valor);
}
