package Ejercicio1;


public class GenericException extends Exception {
	
  public GenericException(String mensage){
	  super(mensage);
  }
}
