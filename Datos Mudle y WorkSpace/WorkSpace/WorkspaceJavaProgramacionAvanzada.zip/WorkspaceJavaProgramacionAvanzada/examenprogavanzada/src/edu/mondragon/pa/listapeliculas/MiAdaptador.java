package edu.mondragon.pa.listapeliculas;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Font;
import java.awt.GridLayout;

import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.ListCellRenderer;


public class MiAdaptador  implements ListCellRenderer<Pelicula> {

	@Override
	public Component getListCellRendererComponent(JList<? extends Pelicula> list,
	         Pelicula p,
	         int index,
	         boolean isSelected,
	         boolean cellHasFocus)
	     {
			JPanel panel = new JPanel(new BorderLayout(10,10));
			
			panel.add(crearCaratula(p), BorderLayout.WEST);
			panel.add(crearDatos(p), BorderLayout.CENTER);
			
	        
	        panel.setBorder(BorderFactory.createCompoundBorder(BorderFactory.createEmptyBorder(10,10,10,10),
	        		BorderFactory.createLineBorder(Color.red)));
	        panel.setBackground(isSelected ? Color.BLUE : Color.white);
	       
	         panel.setOpaque(true);
	       
	         return panel;
	     }

	private Component crearDatos(Pelicula p) {
		JPanel panel = new JPanel(new GridLayout(5,1));
		panel.add(crearTitulo(p.getTitulo()));
		panel.add(crearA�o(p.getA�o()));
		panel.add(crearDirector(p.getDirector()));
		panel.add(crearNacionalidad(p.getNacionalidad()));
		panel.add(crearGenero(p.getGenero()));
		
		return panel;
	}

	private Component crearGenero(String genero) {
		JLabel lGenero = new JLabel (genero);
		lGenero. setFont(new Font("Arial",Font.BOLD,14));
		lGenero.setForeground (Color.RED);
		return lGenero;
	}

	private Component crearNacionalidad(String nacionalidad) {
		JLabel lNacionalidad = new JLabel (nacionalidad);
		lNacionalidad. setFont(new Font("Arial",Font.PLAIN,11));
		lNacionalidad.setForeground (Color.BLACK);
		return lNacionalidad;
	}

	private Component crearDirector(String director) {
		JLabel lDirector = new JLabel (director);
		lDirector. setFont(new Font("Arial",Font.ITALIC,11));
		lDirector.setForeground (Color.BLACK);
		return lDirector;
	}

	private Component crearA�o(int a�o) {
		JLabel lA�o = new JLabel (String.valueOf(a�o));
		lA�o. setFont(new Font("Arial",Font.PLAIN,11));
		lA�o.setForeground (Color.BLACK);
		return lA�o;
	}

	private Component crearTitulo(String titulo) {
		JLabel lTitulo = new JLabel (titulo);
		lTitulo. setFont(new Font("Arial",Font.ITALIC,16));
		lTitulo.setForeground (Color.MAGENTA);
		return lTitulo;
	}

	private Component crearCaratula(Pelicula p) {
		JLabel label = new JLabel (new ImageIcon("caratulas/"+p.getCaratula()));
		return label;
	}

	

	

}
