package edu.mondragon.pa.tablaalumnos;

public class FactorySelectores {
	
	public static Selector getSelectorApellido1(){
		return new SelectorApellido1();
	}
	public static Selector getSelectorNombre(){
		return new SelectorNombre();
	}
	public static Selector getSelectorEdad(){
		return new SelectorEdad();
	}
	public static Selector getSelectorPoblacion(){
		return new SelectorPoblacion();
	}
	public static class SelectorApellido1 implements Selector{

		@Override
		public boolean seleccionar(Alumno a, String valor) {
			
			return a.getApellido1().equals(valor);
		}
		
	}
	public static class SelectorNombre implements Selector{

		@Override
		public boolean seleccionar(Alumno a, String valor) {
			
			return a.getNombre().equals(valor);
		}
		
	}
	public static class SelectorEdad implements Selector{

		@Override
		public boolean seleccionar(Alumno a, String valor) {
			
			return a.getEdad() == Integer.valueOf(valor);
		}
		
	}
	public static class SelectorPoblacion implements Selector{

		@Override
		public boolean seleccionar(Alumno a, String valor) {
			
			return a.getPoblacion().equals(valor);
		}
		
	}
}
