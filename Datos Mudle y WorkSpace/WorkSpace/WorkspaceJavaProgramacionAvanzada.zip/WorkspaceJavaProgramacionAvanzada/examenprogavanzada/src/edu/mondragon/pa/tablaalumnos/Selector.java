package edu.mondragon.pa.tablaalumnos;

public interface Selector {

	boolean seleccionar (Alumno a, String valor);
}
