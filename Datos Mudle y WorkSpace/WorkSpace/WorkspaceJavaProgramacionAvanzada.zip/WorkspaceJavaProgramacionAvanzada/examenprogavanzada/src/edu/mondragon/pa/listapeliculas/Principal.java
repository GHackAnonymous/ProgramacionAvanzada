package edu.mondragon.pa.listapeliculas;
import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.Container;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JToolBar;


public class Principal extends JFrame implements ActionListener{
	JList<Pelicula> lista;
	ListaPeliculas modelo;
	JLabel indice;
	JButton bIzda;
	JButton bDcha;
	int minimo, incremento;
	
	public Principal(){
		super ("Lista peliculas");
		minimo = 1;
		incremento = 5;
		
		this.setSize (420,600);
		this.setLocation(200,100);
		
		this.setContentPane(crearPanelVentana());
		this.setDefaultCloseOperation(EXIT_ON_CLOSE);
		this.setVisible(true);
	}
	private Container crearPanelVentana() {
		JPanel panel = new JPanel(new BorderLayout(0,10));
		panel.add(crearPanelLista(),BorderLayout.CENTER);
		panel.add(crearPanelBotones(),BorderLayout.NORTH);
		panel.setBorder(BorderFactory.createEmptyBorder(20,10,20,10));
		return panel;
	}
	private Component crearPanelLista() {
		JScrollPane panel = new JScrollPane(JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED,JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
		MiAdaptador adaptador = new MiAdaptador();
		lista = new JList<>();
		modelo = new ListaPeliculas();
		modelo.leerPeliculas(minimo,minimo+incremento);
		lista.setModel(modelo);
		lista.setCellRenderer(adaptador);
		panel.setViewportView(lista);
		return panel;
	}
	private Component crearPanelBotones() {
		JToolBar barra = new JToolBar();
		
		bIzda = new JButton (new ImageIcon("iconos/1leftarrow.png"));
		bIzda.setActionCommand("izda");
		bIzda.addActionListener(this);
		bIzda.setEnabled(false);
		
		String strIndice = minimo+" - "+(minimo+incremento);
		indice = new JLabel(strIndice);
		
		bDcha = new JButton(new ImageIcon("iconos/1rightarrow.png"));
		bDcha.setActionCommand("dcha");
		bDcha.addActionListener(this);
		
		barra.add(bIzda);
		barra.add(Box.createHorizontalGlue());
		barra.add(indice);
		barra.add(Box.createHorizontalGlue());
		barra.add(bDcha);
		return barra;
	}
	@Override
	public void actionPerformed(ActionEvent e) {
		
		switch (e.getActionCommand()){
		case "izda": 
			minimo = ((minimo-incremento)<=0)?1:minimo-incremento;
			if (minimo == 1) bIzda.setEnabled(false);
			bDcha.setEnabled(true);
			break;
		case "dcha":
			minimo = minimo+incremento;
			if (minimo+incremento>modelo.getMaxPeliculas()) bDcha.setEnabled(false);
			bIzda.setEnabled(true);
			break;
		}
		String strIndice = minimo+" - "+(((minimo+incremento)>modelo.getMaxPeliculas())?modelo.getMaxPeliculas():(minimo+incremento));
		indice.setText(strIndice);
		modelo.leerPeliculas(minimo, minimo+incremento);
		lista.setModel(modelo);
	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		Principal ejercicio = new Principal();
	}
	
}
