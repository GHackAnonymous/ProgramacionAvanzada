package ejercicioHerenciaBufferAleatorio;

public class ListaException extends Exception{

	public ListaException(String mensage){
		super(mensage);
	}

	
}
