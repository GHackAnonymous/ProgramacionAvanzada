
public class Puerta {
	
	boolean puertaAbierta;
	
	public Puerta(){
		puertaAbierta = false;
	}

	public boolean isPuertaAbierta() {
		return puertaAbierta;
	}

	public void setPuertaAbierta(boolean puertaAbierta) {
		this.puertaAbierta = puertaAbierta;
	}
}
