package ajedrez;

public class Alfil {

}
