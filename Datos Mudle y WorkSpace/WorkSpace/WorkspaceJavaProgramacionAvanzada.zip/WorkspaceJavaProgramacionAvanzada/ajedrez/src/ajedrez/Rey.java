package ajedrez;

public class Rey {

}
