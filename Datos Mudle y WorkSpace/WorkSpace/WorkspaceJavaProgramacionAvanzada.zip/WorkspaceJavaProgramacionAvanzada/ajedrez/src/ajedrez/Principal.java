package ajedrez;

public class Principal {
	
	/*
	 * 
	 * Principal: esta tien la visualizacion 
	 * 	|->Tablero: contiene la posicionde de las figuras
	 * 		|->Fichas: estas validan los movimientos propios
	 * */

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
