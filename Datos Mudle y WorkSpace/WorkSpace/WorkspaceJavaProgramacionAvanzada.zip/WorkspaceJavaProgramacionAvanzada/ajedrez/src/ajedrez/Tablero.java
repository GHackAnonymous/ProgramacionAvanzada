package ajedrez;

public class Tablero {

}
