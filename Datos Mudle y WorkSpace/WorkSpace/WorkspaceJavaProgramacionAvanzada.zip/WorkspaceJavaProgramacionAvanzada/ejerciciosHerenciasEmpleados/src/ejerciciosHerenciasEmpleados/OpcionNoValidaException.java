package ejerciciosHerenciasEmpleados;

public class OpcionNoValidaException extends Exception {
	public OpcionNoValidaException(String mensage){
		super(mensage);
	}
}
