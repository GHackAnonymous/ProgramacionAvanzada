package fechaEnClase;

import java.util.ArrayList;
import java.util.Scanner;

public class Principal {

	private Scanner teclado;
	private Fecha fecha;
	
	public Principal (){
		teclado = new  Scanner(System.in);
	}
	
	
	public void programa(){
		System.out.println("Instroduce na fecha (dd mm aaaa): ");
		String valor = teclado.nextLine();
		
		fecha = new Fecha(valor);
		
		boolean fechaValida = fecha.validarFecha();
		if(fechaValida == true){
			System.out.println(fecha.verFecha());
		}else{
			System.err.println("Fecha No Valida");
		}
	}
	
	public static void main(String[] args) {

		Principal programa = new Principal();
		programa.programa();
	}

}
