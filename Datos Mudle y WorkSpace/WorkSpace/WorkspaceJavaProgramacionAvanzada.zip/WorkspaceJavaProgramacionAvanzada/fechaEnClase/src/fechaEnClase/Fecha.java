package fechaEnClase;

import java.time.DateTimeException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Date;

public class Fecha {

	private int dia;
	private int mes;
	private int ano;
	private LocalDate printfecha;
	private DateTimeFormatter formato;
	private Date fechaFormateada;
	
	public  Fecha(int dia, int mes, int ano){
    	
			this.dia 
	}
	public boolean validarFecha(){
		
		try{
    		
			printfecha = LocalDate.of(valor);
            formato = DateTimeFormatter.ofPattern("dd/MM/yyyy");
            return true;
			
    	}catch (DateTimeException e){
    		return false;	
    	}
		
	}
	public String verFecha(){
		return formato.format(printfecha);
	}
}
