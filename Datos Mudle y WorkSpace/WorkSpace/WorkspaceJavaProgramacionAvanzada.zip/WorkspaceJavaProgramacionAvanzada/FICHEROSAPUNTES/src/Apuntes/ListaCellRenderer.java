package Apuntes;

import java.awt.Color;
import java.awt.Component;
import java.awt.Font;

import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.ListCellRenderer;

public class ListaCellRenderer<T>  implements ListCellRenderer<T> {

	/*
	 * Esta clase que implemeta listCellRenderer define la forma en la que se muestra las etiquetas 
	 * en el JList. como se puede observar en este caso definimos dependiendo del tipo que tenga el objeto
	 * una imagen u otra.
	 * 
	 * OJO!!! NO OLVIDARSE DE PONER ESTA LINEA EN EL LUGAR DONDE SE INICIALIZA EL JLIST
	 * 
	 * lista.setCellRenderer(adaptador);
	 */
	
	
	@Override
	public Component getListCellRendererComponent(JList<? extends T> list,
				     T object,
				     int index,
				     boolean isSelected,
				     boolean cellHasFocus) {
			
	 JPanel panel = new JPanel();
	 JButton boton = new JButton();
	 JLabel etiqueta = new JLabel();
	 
	 ImageIcon icono = null;
	 
     etiqueta.setText(object.toString());
     switch (object.getTipo()){
     case 1: icono = new ImageIcon("iconos/familia.png");break;
     case 2: icono = new ImageIcon("iconos/amigo.png");break;
     case 3: icono = new ImageIcon("iconos/utilities.png");break;
     default:
     }
     boton.setIcon(icono);
     etiqueta.setFont(new Font("Arial",Font.ITALIC,16));
     panel.setBorder(BorderFactory.createLineBorder(Color.red));
     panel.setBackground(isSelected ? Color.RED : Color.white);
     panel.setForeground(isSelected ? Color.WHITE : Color.black);
     panel.add(boton);
     panel.add(etiqueta);
     etiqueta.setOpaque(true);
     
     return panel;
   }
}
