package Apuntes;

import java.util.ArrayList;
import java.util.List;

import javax.swing.ListModel;
import javax.swing.event.ListDataEvent;
import javax.swing.event.ListDataListener;

public class ListaModel<T> implements ListModel<T>{
	
	/*
	 * Esta clase se utiliza para definir que tipo de objetos va a contener la lista que muestra el JList 
	 * en este caso le hemos piesto tipo generico pero en los ejercicios echos en clase comtiene personas.
	 * 
	 * OJO!!!! NO SE NOS OLVIDE PONERLEN EL LUGAR DONDE SE INICIALIZA EL JLIST PONER ESTA LINEA PARA UTILIZAR
	 * NUESTRO MODELO 
	 * 
	 *  lista.setModel(modelo);
	 */
	
	List<T> object;
	List<ListDataListener> listeners;
	
	public ListaModel(){
		object = new ArrayList<>();
		listeners = new ArrayList<>();
	}

	@Override
	public void addListDataListener(ListDataListener listener) {
		listeners.add(listener);
	}

	@Override
	public int getSize(){
		return object.size();
	}

	@Override
	public void removeListDataListener(ListDataListener listener) {
		listeners.remove(listener);
		
	}

	public void add(T newObject) {
		object.add(newObject);
		for (ListDataListener listener : listeners){
			listener.contentsChanged(new ListDataEvent(object, ListDataEvent.CONTENTS_CHANGED,0, object.size() ));
		}
	}

	public void remove(int indice) {
		object.remove(indice);
		for (ListDataListener listener : listeners){
			listener.contentsChanged(new ListDataEvent(object, ListDataEvent.CONTENTS_CHANGED,indice, indice));
		}
	}

	@Override
	public T getElementAt(int indice) {
		return object.get(indice);
	}
}