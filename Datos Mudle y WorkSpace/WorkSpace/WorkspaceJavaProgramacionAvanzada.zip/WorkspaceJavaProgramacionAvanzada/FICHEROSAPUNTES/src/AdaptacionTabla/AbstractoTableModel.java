package AdaptacionTabla;

import java.util.List;
import java.util.stream.Collectors;

import javax.swing.table.AbstractTableModel;

public class AbstractoTableModel<T> extends AbstractTableModel {
	/*
	 * Este clase se utiliza para definir las funciones que va a contener las funciones de la tabla.
	 * 
	 * EDITABLE, MOVIBLE, DEBOLUCION DE DATOS, MULTISELECION...
	 * 
	 */
	
	DefaultTablaColumnaModelo columnas;
	List<T> listaObject;
	List<T> objectFiltrados;
	
	public AbstractoTableModel(DefaultTablaColumnaModelo columnas){
		super();
		this.columnas = columnas;	
	}

	@Override
	public int getColumnCount() {
		return columnas.getColumnCount();
	}

	@Override
	public int getRowCount() {
		return objectFiltrados.size();
	}

	@Override
	public Object getValueAt(int fila, int columna) {
		T objeto = objectFiltrados.get(fila);
		return objeto.getFieldAt(columna);
	}
		
	@Override
	public boolean isCellEditable(int rowIndex, int columnIndex) {
		return false;
	}
	
	@Override
	public Class<?> getColumnClass(int columnIndex) {
		return getValueAt(0,columnIndex).getClass();
	}

	public void filtrarPorPoblacion(String poblacion) {  // filtrado por poblacion en Java funcional
		objectFiltrados.clear();
		objectFiltrados = listaObject.stream()
				.filter(o->o.getPoblacion().equalsIgnoreCase(poblacion))
				.collect(Collectors.toList());	
		this.fireTableDataChanged(); //Esto avisa que a cambiado algo en la tabla
	}

	public void todosLosAlumnos() {
		objectFiltrados.clear();
		for(T ol : listaObject) {
			objectFiltrados.add(ol);
		}
		this.fireTableDataChanged();
	}

	public void filtrarPorEdad(int edad) { // filtrado por edad en Java funcional
		objectFiltrados.clear();
		objectFiltrados = listaObject.stream()
				.filter(o -> o.getEdad() == edad)
				.collect(Collectors.toList());	
		this.fireTableDataChanged(); //Esto avisa que a cambiado algo en la tabla
		
	}

	public void filtrarPorNombre(String nombre) { // filtrado por nombre en Java funcional
		objectFiltrados.clear();
		objectFiltrados = listaObject.stream()
				.filter(o -> o.getNombre().equalsIgnoreCase(nombre))
				.collect(Collectors.toList());	
		this.fireTableDataChanged(); //Esto avisa que a cambiado algo en la tabla
	}
	
	public void filtrarPorApellido(String apellido) {  // filtrado por apellido en Java funcional
		objectFiltrados.clear();
		objectFiltrados = listaObject.stream()
				.filter(o -> o.getApellido1().equalsIgnoreCase(apellido))
				.collect(Collectors.toList());	
		this.fireTableDataChanged(); //Esto avisa que a cambiado algo en la tabla
	}
}
