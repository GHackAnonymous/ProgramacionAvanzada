package Lambdas;

import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

public class FuncionesGenericasLambdas<T> {
	/*
	 * Filtrado por poblacion y guardado en un List<>
	 */
	public List<T> filtradoPorPoblacion(String filtro, List<T> lista){
		
		lista.stream()
		  	.filter(person -> person.getPoblacion() == filtro).collect(Collectors.toList());
	}
	/*
	 * Filtrado por poblacion y pinteado en pantalla terminal
	 */
	public List<T> filtradoPorPoblacionEImpresion(String filtro, List<T> lista){
		
		lista.stream()
		  	.filter(person -> person.getPoblacion() == filtro)
		  	.forEach(System.out::println);
	}
	/*
	 * Filtrado por poblacion y guardado en un List<> los diferentes poblaciones
	 */
	public List<T> filtradoporIguales(String filtro, List<T> lista){
		
		lista.stream()
		  	.filter(person -> person.getPoblacion() == filtro)
		  	.distinct().collect(Collectors.toList());
	}

	/*
	 * Codigo sacado desde el ejercicios de Txema
	 */
	private void verAlumnosAgrupados(Map<String, List<Alumno>> agrupacion) {
		Set<Entry<String,List<Alumno>>> poblaciones = agrupacion.entrySet();
		
		for (Entry<String,List<Alumno>> poblacion: poblaciones){
			List<Alumno> alumnos = poblacion.getValue();
			Optional<Double> notaMediaPoblacion = alumnos.stream().map(Alumno::getNota).reduce((a,b)->a+b);
			System.out.println("Poblacion: "+poblacion.getKey() +"--> Nota media:" + notaMediaPoblacion.orElse(0.0)/alumnos.size());
			alumnos.stream().forEach(System.out::println);
			System.out.println("-------------------------------");
		}
		
		
	}
	/*
	 * Codigo sacado desde el ejercicios de Txema
	 */
	private Map<String, List<Alumno>> agruparAlumnosPorPoblacion(List<Alumno> alumnos) {
		
		return alumnos.stream()
				.collect (Collectors.groupingBy(Alumno::getPoblacion));
	}
	
	/*
	 * Codigo sacado desde el ejercicio LAMBDA de XABIER
	 */
	public void ordenar(){
		personList.stream()
		   .filter(person -> person.getPoblacion() == "Bergara")
		   .sorted(Comparator.comparing(Person::getName).thenComparing(Person::getSurname).reversed())
		   .forEach(System.out::println);
		
	}
}
