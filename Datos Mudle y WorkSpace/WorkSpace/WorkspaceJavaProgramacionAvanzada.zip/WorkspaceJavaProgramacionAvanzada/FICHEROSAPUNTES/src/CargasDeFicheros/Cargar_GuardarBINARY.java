package CargasDeFicheros;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

import javax.swing.DefaultListModel;

public class Cargar_GuardarBINARY<T> {

/*
*  "implements Serializable"   en el objeto.  Que no sean objetos de Swing.
*  Guarda cualquier objeto, excepto objetos de Swing, mientras que este sea serializable.
*/
	
	public void escribirObjetosEnFicheroBinario(String path, T objetoTratar) {
		try(ObjectOutputStream out = new ObjectOutputStream(new FileOutputStream(path))){
			out.writeObject(objetoTratar);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	public Object cargarObjetosFicheroBinario(String path) {
		try(ObjectInputStream out = new ObjectInputStream(new FileInputStream(path))){
			return out.readObject();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
		}
		return null;
	}
		
}

