package notasclase;

import java.util.Scanner;

public class PrincipalPbl {
	final String NOMBRECLASE = "2� INFOR + TELECOS";
	final int NUMALUMNOS = 50;
	Clase clase;
	Scanner teclado;
	
	public PrincipalPbl(){
		clase = new Clase(NOMBRECLASE,NUMALUMNOS);
		teclado = new Scanner (System.in);
	}
	public int menu (){
		int opcion;
		System.out.println("1.- A�adir alumno");
		System.out.println("2.- Meter notas");
		System.out.println("3.- Ver lista alumnos");
		System.out.println("0.- Salir");
		System.out.print("Seleccione opci�n: ");
		
		opcion = teclado.nextInt();	
		return opcion;
	}
	
	public void gestionarNotas(){
		int opcion;
		do{
			opcion = menu();
			switch (opcion){
			case 1: anadirAlumno(); break;
			case 2: meterNotas(); break;
			case 3: verLista(); break;
			case 0: break;
			default: System.out.println("Opcion no valida");
			}
		}while (opcion != 0);
		
	}

	private void verLista() {
		Alumno [] lista = clase.getAlumnos();
		for (Alumno alumno: lista){
			System.out.println();
			System.out.println(alumno);
			System.out.println();
		}
		
	}
	private void meterNotas() {
		if (clase.vacia()){
			System.out.println("No hay alumnos en la clase");
			return;
		}
		clase.irPrimero();
		do{
			Alumno alumno = clase.getAlumno();
			meterNotaAlumno(alumno);
			clase.irSS();
			
		}while (!clase.fin());
		
	}
	private void meterNotaAlumno(Alumno alumno) {
		double nota,notaPbl;
		System.out.println();
		System.out.print("Nota del alumno " + alumno.getNombre()+" "+ alumno.getApellido());
		nota = teclado.nextDouble();
		alumno.setNota(nota);
		if (alumno instanceof AlumnoPbl){
			System.out.print("Nota del Pbl: " );
			notaPbl = teclado.nextDouble();
			((AlumnoPbl)alumno).setNotaPbl(notaPbl);
		}
	}
	private void anadirAlumno() {
		Alumno alumno = leerAlumno();
		if ( !clase.a�adir(alumno)){
			System.out.println("La clase esta llena");
		}
	}
	private Alumno leerAlumno() {
		int idal;
		String nombre, apellido;
		Alumno alumno;
		String opcion;
		
		System.out.println();
		System.out.print("Idal: ");
		idal = teclado.nextInt(); teclado.nextLine();
		System.out.print("Nombre: ");
		nombre = teclado.nextLine();
		System.out.print("Apellido: ");
		apellido = teclado.nextLine();
		System.out.print("Es una alumno pbl (S/N)?: ");
		opcion = teclado.nextLine();
		if (opcion.toLowerCase().equals("s")){
			alumno = new AlumnoPbl(idal,nombre,apellido);
		}else{
			alumno = new Alumno (idal, nombre, apellido);
		}
	
		return alumno;
	}
	public static void main(String[] args) {
		PrincipalPbl programa = new PrincipalPbl();
		programa.gestionarNotas();

	}

}
