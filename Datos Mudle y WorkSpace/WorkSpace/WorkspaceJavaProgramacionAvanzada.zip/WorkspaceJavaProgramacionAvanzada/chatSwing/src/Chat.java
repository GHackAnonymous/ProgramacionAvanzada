import javax.swing.DefaultListModel;

public class Chat extends DefaultListModel<Texto>{
	
	public Chat(){
		super();
	}
	
	
}
