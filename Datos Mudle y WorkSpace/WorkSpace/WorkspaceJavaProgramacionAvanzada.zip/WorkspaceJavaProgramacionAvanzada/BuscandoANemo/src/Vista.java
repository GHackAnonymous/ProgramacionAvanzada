import java.awt.BorderLayout;
import java.awt.Container;
import java.awt.Image;
import java.awt.Toolkit;

import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class Vista{
	
	JFrame ventana;
	JLabel imagen;

	
	public Vista(){
		ventana = new JFrame("buscando a Nemo");

		ventana.setLocation(500,200);
		ventana.setExtendedState(JFrame.MAXIMIZED_BOTH);
		
		ventana.setContentPane(crearPanelVentana());
		ventana.setIconImage(new ImageIcon("iconos/ico.jpg").getImage());
		ventana.setVisible(true);
		ventana.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}

	private Container crearPanelVentana() {
		JPanel panelPrincipal  = new JPanel(new BorderLayout(10,10));
		//panelPrincipal.setBorder(BorderFactory.createEmptyBorder(10,10,10,10));
		
		imagen = new JLabel ();
		imagen.setIcon(new ImageIcon("iconos/w.jpg"));
		imagen.setHorizontalAlignment(JLabel.CENTER);
		
		panelPrincipal.add(imagen,BorderLayout.CENTER);
		
		return panelPrincipal;
	}
	public static void main(String[] args) {
		Vista programa = new Vista();
	}

}
