package lecturadefichero;

public class Alumno {
	int idal;
	String nombre;
	String apellido;
	String poblacion;
	String sexo; // M-masculino F-femenino
	double nota;
	
	

	public Alumno(int idal, String nombre, String apellido,String poblacion, String sexo, double nota){
		this.idal = idal;
		this.nombre = nombre;
		this.apellido = apellido;
		this.poblacion=poblacion;
		this.sexo = sexo;
		this.nota = nota;
	}
	public Alumno (String ... valores){
		this.idal = Integer.valueOf(valores[0]);
		this.nombre = valores[1];
		this.apellido = valores[2];
		this.poblacion = valores[3];
		this.sexo = valores[4];
		this.nota = Double.valueOf(valores[5]);
	}
	public String getPoblacion() {
		return poblacion;
	}
	public String getSexo() {
		return sexo;
	}
	@Override
	public String toString() {
		return "Idal: "+ this.idal +"Sexo: "+this.sexo+"\n" +
		        "Nombre: " + this.nombre+" "+ this.apellido+"\n"+
				"Poblacion: "+ this.poblacion+"\n"+
				"Nota: " + this.nota;
	}
	public double getNota() {
		return nota;
	}

	public void setNota(double nota) {
		this.nota = nota;
	}

	public int getIdal() {
		return idal;
	}

	public String getNombre() {
		return nombre;
	}

	public String getApellido() {
		return apellido;
	}
	
}
