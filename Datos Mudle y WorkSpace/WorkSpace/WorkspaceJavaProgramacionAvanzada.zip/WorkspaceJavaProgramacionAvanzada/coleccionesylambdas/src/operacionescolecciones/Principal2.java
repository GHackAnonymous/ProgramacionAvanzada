package operacionescolecciones;

import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Scanner;
import java.util.Set;
import java.util.Map.Entry;
import java.util.stream.Collectors;

public class Principal2 {
	Clase clase;
	Scanner teclado;
	
	public Principal2(){
		clase = new Clase();
		teclado = new Scanner (System.in);
		inicializar();
	}
	private void inicializar() {
		clase.a�adir(new Alumno (1,"I�igo","Ayestaran","Vitoria","M",7.0));
		clase.a�adir(new Alumno (2,"Ander","Bolumburu","Arrasate","M",6.2));
		clase.a�adir(new Alumno (3,"Ainhoa","Arruabarrena","Zarauz","F",8.4));
		clase.a�adir(new Alumno (4,"Aritz","Caballero","Zarauz","M",9.1));
		clase.a�adir(new Alumno (5,"Elene","Carlos de Bergara","Arrasate","F",8.8));
		clase.a�adir(new Alumno (6,"Txema","Perez","Vitoria","M",2.3));
		clase.a�adir(new Alumno (7,"Xabi","Elkoro","Arrasate","M",3.2));
		clase.a�adir(new Alumno (8,"Miren","Illarramendi","Bergara","F",4.7));
		clase.a�adir(new Alumno (9,"I�aki","Arenaza","Vitoria","M",3.5));
		clase.a�adir(new Alumno (10,"Aitor","Barreiro","Vitoria","M",7.5));
		clase.a�adir(new Alumno (11,"Julen","Uribarren","Bergara","M",6.5));
		clase.a�adir(new Alumno (12,"Xanti","Leonet","Zarauz","M",8.5));
		
	}
	private void verAlumnosAgrupados(Map<String, List<Alumno>> agrupacion) {
		Set<Entry<String,List<Alumno>>> poblaciones = agrupacion.entrySet();
		
		for (Entry<String,List<Alumno>> poblacion: poblaciones){
			List<Alumno> alumnos = poblacion.getValue();
			Optional<Double> notaMediaPoblacion = alumnos.stream().map(Alumno::getNota).reduce((a,b)->a+b);
			System.out.println("Poblacion: "+poblacion.getKey() +"--> Nota media:" + notaMediaPoblacion.orElse(0.0)/alumnos.size());
			alumnos.stream().forEach(System.out::println);
			System.out.println("-------------------------------");
		}
		
		
	}
	
	private Map<String, List<Alumno>> agruparAlumnosPorPoblacion(List<Alumno> alumnos) {
		
		return alumnos.stream()
				.collect (Collectors.groupingBy(Alumno::getPoblacion));
	}
	
	public static void main(String[] args) {
		Principal programa = new Principal();
		programa.verNotasAprobadosPorPoblacion();
		
	}

}
