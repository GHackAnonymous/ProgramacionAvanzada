package operacionescolecciones;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

class Clase {
	String nombre;
	List<Alumno> listaAlumnos;
	
	public Clase (){
		listaAlumnos = new ArrayList<>();
	}
	
	public void a�adir (Alumno alumno){
		listaAlumnos.add(alumno);
	}
	
	public List<Alumno> getListaAlumnos(){
		List<Alumno> copia = new ArrayList<Alumno>(listaAlumnos);
		Collections.copy(copia, listaAlumnos);
		return copia;
	}
}
