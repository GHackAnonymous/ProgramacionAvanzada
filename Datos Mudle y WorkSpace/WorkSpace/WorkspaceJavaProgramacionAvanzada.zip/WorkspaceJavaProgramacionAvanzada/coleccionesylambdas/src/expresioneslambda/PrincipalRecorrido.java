package expresioneslambda;

import java.util.List;
import java.util.Scanner;

public class PrincipalRecorrido {
	final int MAXPUNTOS = 100;
	Recorrido recorrido;
	Scanner teclado;
	
	public PrincipalRecorrido(){
		recorrido = new Recorrido (MAXPUNTOS);
		teclado = new Scanner (System.in);
	}
	public void introducirPuntos(){
		String opcion;
		do{
			Punto punto = leerPunto();
			if (!recorrido.add(punto)){
				System.out.println("La lista esta llena");
				return;
			}
			System.out.print("Mas puntos (S/N)?: ");
			opcion = teclado.nextLine();
			
		}while (opcion.toLowerCase().equals("s"));
	}
	private Punto leerPunto() {
		Punto punto;
		int coordenadaX,coordenadaY;
		System.out.print("Punto (x y): ");
		coordenadaX = teclado.nextInt();
		coordenadaY = teclado.nextInt();
		teclado.nextLine();
		punto = new Punto (coordenadaX,coordenadaY);
		return punto;
	}
	
	public void verRecorrido(){
		List<Punto> trayectoria = recorrido.getRecorrido();
		System.out.println("Trayecto realizado:");
		trayectoria.stream().forEach(System.out::println);
		
		System.out.println("Distancia recorrida "+ recorrido.distanciaRecorrido());
	}
	public static void main(String[] args) {
		PrincipalRecorrido programa = new PrincipalRecorrido();
		programa.introducirPuntos();
		programa.verRecorrido();

	}

}
