package expresioneslambda;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class Recorrido {
	
	List<Punto> recorrido;
	
	
	public Recorrido(int maxPuntos){
		
		recorrido = new ArrayList<> ();
	
	}
	public boolean add (Punto p){
		recorrido.add(p);
		return true;
	}
	public double distanciaRecorrido (){
		double valor = 0.0;
		for (int i = 0; i<recorrido.size()-1; i++){
			valor += recorrido.get(i).distancia(recorrido.get(i+1));
		}
		return valor;
	}
	public List<Punto> getRecorrido(){
		List<Punto> copia = new ArrayList<>(recorrido);
		Collections.copy(copia, recorrido);
		return copia;
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
