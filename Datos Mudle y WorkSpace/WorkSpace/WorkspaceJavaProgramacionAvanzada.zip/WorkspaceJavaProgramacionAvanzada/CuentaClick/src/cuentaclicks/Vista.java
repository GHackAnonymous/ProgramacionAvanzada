package cuentaclicks;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Container;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Observable;
import java.util.Observer;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class Vista implements Observer{
	
	JFrame ventana;
	JLabel texto;
	JButton botonInc,botonDec;
	Modelo modelo;
	Controlador controlador;
	
	public Vista(Modelo modelo,int posX,int posY){
		ventana = new JFrame("CuentaClicks");
		
		this.modelo = modelo;
		modelo.addObserver(this);
		
		controlador = new Controlador(this,modelo);
		ventana.setLocation(posX,posY);
		ventana.setSize(300, 400);
		
		ventana.setContentPane(crearPanelVentana());
		ventana.setVisible(true);
		ventana.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		ventana.addWindowListener(controlador);
	}

	private Container crearPanelVentana() {
		JPanel panel  = new JPanel(new BorderLayout(10,20));
		panel.setBorder(BorderFactory.createEmptyBorder(10,20,10,20));
		texto = new JLabel (String.valueOf(modelo.getContador()));
		texto.setFont(new Font ("Arial", Font.BOLD, 165));
		texto.setHorizontalAlignment(JLabel.CENTER);
		texto.setForeground(Color.red);
		texto.setBackground(Color.green);
		texto.setOpaque(true);
		texto.setBorder(BorderFactory.createCompoundBorder(
				BorderFactory.createTitledBorder("Contador"),
				BorderFactory.createLineBorder(Color.red)));
		
		panel.add(texto, BorderLayout.CENTER);
		panel.add(crearPanelBotones(),BorderLayout.SOUTH);
		
		return panel;
	}
	
	private Component crearPanelBotones() {
		JPanel panel = new JPanel(new GridLayout(1,2,20,0));
		botonInc = new JButton ("Incrementar");
		botonInc.addActionListener(controlador);
		botonInc.setActionCommand("Incrementar");
		botonDec = new JButton ("Decrementar");
		botonDec.addActionListener(controlador);
		botonDec.setActionCommand("Decrementar");
		panel.add(botonInc);
		panel.add(botonDec);
		
		return panel;
	}

	@Override
	public void update(Observable modelo, Object objeto) {
		if (modelo instanceof Modelo){
			Modelo contador = (Modelo) modelo;
			texto.setText(String.valueOf(contador.getContador()));
		}
		
	}

	public static void main(String[] args) {
		Modelo modelo = new Modelo();
		Vista programa = new Vista(modelo,100,100);
	}
}
