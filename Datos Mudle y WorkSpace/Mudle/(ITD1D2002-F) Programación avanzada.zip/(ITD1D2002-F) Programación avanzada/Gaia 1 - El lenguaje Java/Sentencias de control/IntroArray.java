/**
 * Esta clase permite ver el uso de arrays y las sentencias de control de Java.
 * Las sentencias de control son b�sicamente iguales a las utilizadas en C.
 * El array se diferencia en la separaci�n entre declaraci�n y creaci�n en 
 * aquellos casos en los que el array no se inicializa.
 * 
 * @author txperez
 *
 */
public class IntroArray {
	
	int lista1 [];   //declaro el array pero no lo creo
	
	int lista2 [] = {1,2,2,4,5}; //declaro el array, lo creo y lo inicializo
	
	/**
	 * funci�n que sirve para mostrar el comportamiento de las sentencias 
	 * de control y del array en Java.
	 * 
	 */
	public void gestionArray(){
		
		lista1 = new int [10];  //creo un array de 10 enteros
		
		if (lista2[0]>0) {
			System.out.println(" Es positivo");
		}
		if ((lista2[1]%2)==0){
			System.out.println (" Es par");
		
			if ( lista2[1] == 0) {
				System.out.println ("Es cero");
			}
		}else{
				System.out.println (" Es impar ");
		}
			
      switch (lista2[2]){
		case 0: System.out.println ("Cero");break;
		case 1: System.out.println ("Uno");break;
		case 2: System.out.println ("Dos");
		default: System.out.println ("Ni idea");
		}
		

		int i = 0;
		while (i<5){
			System.out.println(lista2[i++]);
		}
		i = 0;
		do{
			System.out.println(lista2[i++]);
		}while (i<5);
		
		for ( int j = 0; j<5; j++){
			System.out.println(lista2[j]);
		}
		//for (;;);  //bucle infinito
		for (int item : lista2){
			System.out.println(item);
		}
		for ( int j = 0; j<5; j++){
			if ( lista2[j]== 4){
				System.out.println("El numero 4 esta en la posicion: "+j);
				continue;
			}
			//sentencias
		}
		
	}
	
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		IntroArray programa = new IntroArray();
		programa.gestionArray();
	}

}
