
import java.util.Scanner;

/**
 * Muestra el uso de la clase {@link Scanner} para leer valores del teclado.
 *  
 * @author txperez
 *
 */

public class UsoTeclado {

	Scanner teclado;  //declaraci�n de la variable que nos da acceso al teclado
	
	public void leerValores (){
		int valor;
		float real;
		teclado = new Scanner (System.in); //conecta la variable con el teclado
		System.out.print ("Introduce un entero: ");
		valor = teclado.nextInt();        //se utilizan las funciones nextTipo para 
										  //convertir el string leido del teclado al Tipo
										  //deseado
		String texto = String.valueOf(valor);
		texto = (texto.length()<2)?"0"+texto:texto;
		System.out.println(texto);
/*		
		System.out.print ("Introduce un float: ");
		real = teclado.nextFloat();
		System.out.println("El valor leido es: "+ valor);
		System.out.println("El float leido es: "+ real);
*/
	}
	
	/**
	 *  Funci�n utilizada para implementar el main con el que creariamos el programa si
	 *  utilizamos Java para programar como se hace en C
	 */
	public void principal(){
		
	}
	
	/**
	 * Llama a la funci�n principal
	 * @param args
	 */
	public static void main(String[] args) {
		UsoTeclado programa = new UsoTeclado();
		programa.leerValores();

	}

}
